# -*- coding: utf-8 -*-
"""
SubtitleStyle -- dosya icindeki (MKV) altyazilari oynatici bilgi cubugu acikken cubugun ustune kaydirir.

Bu altyazilari InfoBarSubtitleSupport'un tam ekran altyazi penceresi (subtitle_window, SubtitleDisplay)
gosterir. Cubuk acilinca pencerenin tamami cubuk yuksekligi kadar yukari tasinir, kapaninca geri gelir
(harici .srt'de SrtCizici bunu zaten yapiyor). Oynatici ekrani = bilgi cubugu (InfoBarShowHide kendisini
gosterir/gizler), bu yuzden onShow/onHide yeterli.

    from Plugins.SystemPlugins.SubtitleStyle.kaydir import cubukla_kaydir
    cubukla_kaydir(self, 290)        # oynatici __init__'inde, InfoBar*.__init__'lerden sonra
"""
from enigma import ePoint, getDesktop


def _o(px):
    try:
        return px if getDesktop(0).size().width() >= 1920 else int(px * 2 / 3)
    except Exception:  # noqa: BLE001
        return px


class _Kaydirici(object):
    __slots__ = ("oynatici", "kayma")

    def __init__(self, oynatici, kayma):
        self.oynatici = oynatici
        self.kayma = kayma

    def acik(self):
        self._tasi(-self.kayma)

    def kapali(self):
        self._tasi(0)

    def _tasi(self, y):
        pencere = getattr(self.oynatici, "subtitle_window", None)
        e = getattr(pencere, "instance", None)
        if e is None:
            return
        try:
            e.move(ePoint(0, y))
        except Exception as hata:  # noqa: BLE001
            print("[SubtitleStyle] altyazi penceresi tasinamadi: %s" % hata)


# altyazi penceresinde dosya ici altyazinin kendi alt boslugu (FHD, olculdu ~105 px): kaydirmadan dusulur
ALTYAZI_ALT_BOSLUK = 105


def cubukla_kaydir(oynatici, cubuk_h_fhd=290, aralik_fhd=25):
    """oynatici: InfoBarSubtitleSupport + InfoBarShowHide'li ekran. cubuk_h_fhd: cubugun FHD yuksekligi;
    aralik_fhd: altyazi ile cubuk arasinda kalacak bosluk. 1.5'te tam cubuk yuksekligi kaydiriliyordu,
    altyazi cubuktan ~120 px yukarida kaldi (kullanici: 'cok yukarda'); simdi kendi alt boslugu dusulur."""
    k = _Kaydirici(oynatici, _o(max(0, cubuk_h_fhd - ALTYAZI_ALT_BOSLUK + aralik_fhd)))
    oynatici.onShow.append(k.acik)
    oynatici.onHide.append(k.kapali)
    oynatici._substyle_kaydirici = k        # baglanti yasasin
    return k
