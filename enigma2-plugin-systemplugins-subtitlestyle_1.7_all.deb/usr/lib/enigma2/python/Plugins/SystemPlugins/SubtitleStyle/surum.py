# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_subtitlestyle.py); depoda yok.
SURUM = "1.7"
COMMIT = "5e3e5af"
