# -*- coding: utf-8 -*-
"""
SubtitleStyle -- ayar ekrani: harici .srt gorunumu (canli onizleme) + dosya icindeki (MKV) altyazilar.

Kurallar (DREAMOS-PLUGIN-GELISTIRME-NOTLARI.md §2, §35): baslik skin'e gomulmez, setText/setTitle py2'de
bayt ister; ConfigListScreen degisiklik kancasi on_change.
"""
from __future__ import print_function

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import config, getConfigListEntry, configfile

from .ayarlar import cfg, fontconfig_yaz
from .cizici import AltyaziKutusu, _o

try:
    _
except NameError:
    def _(txt):
        return txt

ORNEK = u"Bunu daha önce hiç görmemiştim, Çağrı.\nŞimdi ne yapacağız? Işıklar söndü!"
ZEMIN = "#0a111419"
SECIM = "#00243646"
VURGU = "#003aa0a8"


def _s(metin):
    if isinstance(metin, type(u"")) and str is bytes:
        return metin.encode("utf-8")
    return metin


def _u(metin):
    return metin.decode("utf-8") if isinstance(metin, bytes) else metin


def _skin():
    W, H = _o(1300), _o(730)
    k = _o(40)
    return """
    <screen name="SubtitleStyleAyarlar" position="center,%d" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">
        <widget name="baslik" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" />
        <eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" />
        <widget name="config" position="%d,%d" size="%d,%d" backgroundColor="%s" backgroundColorSelected="%s" foregroundColorSelected="#ffffff" selectionRadius="%d" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="ipucu" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8a94a0" backgroundColor="%s" transparent="1" />
        <widget name="key_red" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#00a84a46" halign="center" valign="center" cornerRadius="%d" />
        <widget name="key_green" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="#003d8a5a" halign="center" valign="center" cornerRadius="%d" />
    </screen>""" % (_o(40), W, H, ZEMIN,
                    k, _o(22), W - 2 * k, _o(50), _o(34), ZEMIN,
                    k, _o(84), W - 2 * k, _o(3), VURGU,
                    k, _o(104), W - 2 * k, _o(480), ZEMIN, SECIM, _o(12),
                    k, _o(592), W - 2 * k, _o(64), _o(22), ZEMIN,
                    k, _o(658), _o(300), _o(54), _o(26), _o(12),
                    k + _o(330), _o(658), _o(300), _o(54), _o(26), _o(12))


def _soru_skin(satir):
    W = _o(1000)
    H = _o(150) + _o(56) * satir + _o(40)
    return """
    <screen name="SubtitleStyleSoru" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">
        <widget name="metin" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" />
        <eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" />
        <widget name="liste" position="%d,%d" size="%d,%d" backgroundColor="%s" foregroundColor="#e6e9ec" backgroundColorSelected="%s" foregroundColorSelected="#ffffff" selectionRadius="%d" scrollbarMode="showNever" transparent="1" />
    </screen>""" % (W, H, ZEMIN,
                    _o(32), _o(20), W - _o(64), _o(96), _o(26), ZEMIN,
                    _o(32), _o(124), W - _o(64), _o(2), VURGU,
                    _o(20), _o(140), W - _o(40), _o(56) * satir, ZEMIN, SECIM, _o(10))


class Soru(Screen):
    """Evet/hayir sorusu: yalnizca OK, Exit, yukari/asagi (renkli tus YOK: Kaydet'e basilan Yesil'in devami
    temanin MessageBox'inda 'alwaysOK' = Evet sayiliyordu, olculdu). close(True/False); varsayilan ilk secenek."""

    def __init__(self, session, metin, secenekler):
        self.skin = _soru_skin(len(secenekler))
        Screen.__init__(self, session)
        self.secenekler = secenekler                  # [(metin, deger)]
        self["metin"] = Label(_s(metin))
        self["liste"] = MenuList([_s(m) for m, _d in secenekler])
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.sec, "cancel": lambda: self.close(False),
            "up": self["liste"].up, "down": self["liste"].down,
        }, -1)

    def sec(self):
        self.close(self.secenekler[self["liste"].getSelectedIndex()][1])


class AltyaziStiliAyarlari(Screen, ConfigListScreen):
    """Ayar degistikce alttaki ornek ayni cizicide (cizici.AltyaziKutusu) yenilenir. Dosya icindeki
    altyazi ayarlari fontconfig'e yazilir; enigma2 yeniden baslayinca gecerli (sorulur)."""

    def __init__(self, session):
        self.skin = _skin()
        Screen.__init__(self, session)
        girdiler = [
            getConfigListEntry(_s(u"Font (tüm altyazılar)"), cfg.font),
            getConfigListEntry(_s(u"Harici (.srt) · Boyut"), cfg.boyut),
            getConfigListEntry(_s(u"Harici (.srt) · Stil"), cfg.stil),
            getConfigListEntry(_s(u"Harici (.srt) · Renk"), cfg.renk),
            getConfigListEntry(_s(u"Harici (.srt) · Dikey konum"), cfg.konum),
            getConfigListEntry(_s(u"Harici (.srt) · Zamanlama (+ geç, − erken)"), cfg.gecikme),
            getConfigListEntry(_s(u"Dosya içi (MKV) · Boyut"), cfg.gomulu_olcek),
        ]
        try:        # enigma2'nin kendi ayarlari: metin altyazi sunumu (siyah kutu / golge) ve kutu saydamligi
            girdiler.append(getConfigListEntry(_s(u"Dosya içi (MKV) · Sunum"), config.usage.text_subtitle_presentation))
            girdiler.append(getConfigListEntry(_s(u"Dosya içi (MKV) · Kutu saydamlığı"), config.usage.text_subtitle_black_box_transparency))
        except AttributeError:
            pass
        ConfigListScreen.__init__(self, girdiler, session=session, on_change=self._degisti)
        self["baslik"] = Label(_s(u"Altyazı stili"))
        self["ipucu"] = Label(_s(u"Sol / Sağ ile değiştir; alttaki örnek anında güncellenir.\n"
                                 u"Dosya içindeki (MKV) altyazıda font ve boyut enigma2 yeniden başlayınca değişir (sorulur)."))
        self["key_red"] = Label(_s(u"İptal"))
        self["key_green"] = Label(_s(u"Kaydet"))
        self["actions"] = ActionMap(["ColorActions", "SetupActions"], {
            "cancel": self.iptal, "red": self.iptal, "green": self.kaydet, "save": self.kaydet,
        }, -1)
        self.onizleme = session.instantiateDialog(AltyaziKutusu)
        self.onizleme.neverAnimate()
        self.onLayoutFinish.append(self._baslat)
        self.onClose.append(self._kapanis)

    def _baslat(self):
        try:
            self["config"].instance.setWrapAround(True)
        except Exception:  # noqa: BLE001
            pass
        self.onizleme.show()
        self.onizleme.stil_uygula()
        self.onizleme.goster(ORNEK, False)

    def _degisti(self):
        if getattr(self, "onizleme", None):
            self.onizleme.stil_uygula()
            self.onizleme.goster(ORNEK, False)

    def _kapanis(self):
        try:
            self.session.deleteDialog(self.onizleme)
        except Exception:  # noqa: BLE001
            pass
        self.onizleme = None

    def kaydet(self):
        for x in self["config"].list:
            x[1].save()
        configfile.save()
        if fontconfig_yaz():
            # soru gecikmeli: Kaydet'e basilan tusun devami yeni kutuya gitmesin (1.1'de sorusuz yeniden basladi)
            from enigma import eTimer
            self._soru_z = eTimer()
            try:
                self._soru_b = self._soru_z.timeout.connect(self._soru_ac)
            except AttributeError:
                self._soru_z.callback.append(self._soru_ac)
            self._soru_z.start(500, True)
            return
        self.close(True)

    def _soru_ac(self):
        self.session.openWithCallback(self._yeniden_baslat, Soru,
                                      u"Dosya içindeki (MKV) altyazıların fontu ve boyutu enigma2 yeniden başlayınca değişir.\n"
                                      u"Şimdi yeniden başlatılsın mı? (Oynayan video durur.)",
                                      [(u"Sonra", False), (u"Şimdi yeniden başlat", True)])

    def _yeniden_baslat(self, evet):
        if evet:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)
            return
        self.close(True)

    def iptal(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close(False)
