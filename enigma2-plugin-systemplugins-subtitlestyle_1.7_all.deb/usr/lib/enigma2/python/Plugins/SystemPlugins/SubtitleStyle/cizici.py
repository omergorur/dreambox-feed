# -*- coding: utf-8 -*-
"""
SubtitleStyle -- harici .srt cizici (GDrive 0.4-0.10'dan tasindi).

Neden oynatici kendisi ciziyor: eServiceReference.setSuburi ile verilen .srt her mutlak sarmadan sonra
sarma noktasi kadar kayiyor (eServiceMP3 hatasi; 1251 sn'den devam -> cubuk 23:29'da altyazi 0:44).

Kullanim (herhangi bir oynatici ekrani):
    from Plugins.SystemPlugins.SubtitleStyle.cizici import SrtCizici
    self.srt = SrtCizici(session, "/tmp/x.srt", self._srt_durum)   # durum() -> (duraklatildi, cubuk_acik)
    self.srt.baslat()                       # oynatma baslarken
    self.srt.ornek(pts // 90)               # konum her okundugunda (ms) -- boru hattina EK SORGU YAPMA
    self.srt.sifirla()                      # her mutlak sarmada (doSeek)
    self.srt.degistir()                     # ac/kapat (True: acik)
    self.srt.kapat()                        # oynatici kapanirken

Zamanlama: son konum orneginden duvar saatiyle kestirim (en fazla 1,5 s; duraklatmada durur), 200 ms'de bir.
Kontur: metnin 8 yone kaydirilmis siyah kopyalari (bulanik golge acik sahnede okunmuyordu, olculdu).
"""
from __future__ import print_function

import bisect
import io
import os
import re
import time

from Screens.Screen import Screen
from Components.Label import Label
from enigma import getDesktop, gFont, gRGB, ePoint, eSize

from .ayarlar import cfg, FONTLAR, FONT_DIZINI, gunluk

_SRT_ZAMAN = re.compile(r"(\d+):(\d\d):(\d\d)[,.](\d{1,3})\s*-->\s*(\d+):(\d\d):(\d\d)[,.](\d{1,3})")
_SRT_ETIKET = re.compile(r"<[^>]*>|\{[^}]*\}")
KESTIRIM_SINIRI_MS = 1500
KONTUR_YONLERI = ((-1, 0), (1, 0), (0, -1), (0, 1), (-0.7, -0.7), (0.7, -0.7), (-0.7, 0.7), (0.7, 0.7))
SAYDAM = 0xff000000
CUBUK_H = 290        # oynaticilarin alt bilgi seridi (FHD); cubuk acikken altyazi bunun ustune cikar


def _fhd():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:  # noqa: BLE001
        return False


def _o(px):
    return px if _fhd() else int(px * 2 / 3)


def _b(metin):
    """eLabel.setText py2'de bayt ister."""
    if isinstance(metin, type(u"")) and str is bytes:
        return metin.encode("utf-8")
    return metin or ""


def srt_oku(yol):
    """[(bas_ms, bit_ms, metin)] sirali. Dosya UTF-8 olmali (cagiran cevirir); bozuk bloklar atlanir."""
    try:
        with io.open(yol, encoding="utf-8", errors="replace") as f:
            metin = f.read()
    except (IOError, OSError) as e:
        gunluk("srt okunamadi: %s" % e)
        return []
    sonuc = []
    for blok in re.split(r"\n\s*\n", metin.replace(u"\r", u"")):
        satirlar = blok.strip().split(u"\n")
        for i, satir in enumerate(satirlar):
            m = _SRT_ZAMAN.search(satir)
            if not m:
                continue
            g = [int(x) for x in m.groups()]
            bas = ((g[0] * 60 + g[1]) * 60 + g[2]) * 1000 + int(m.group(4).ljust(3, "0"))
            bit = ((g[4] * 60 + g[5]) * 60 + g[6]) * 1000 + int(m.group(8).ljust(3, "0"))
            yazi = u"\n".join(_SRT_ETIKET.sub(u"", s).strip() for s in satirlar[i + 1:] if s.strip())
            yazi = yazi.replace(u"♪", u"~").replace(u"♫", u"~")    # paketteki fontlarda nota yok
            if yazi and bit > bas:
                sonuc.append((bas, bit, yazi))
            break
    sonuc.sort()
    return sonuc


def srt_bul(srt, baslar, t):
    """t (ms) anindaki satir(lar); ust uste binenler alt alta."""
    i = bisect.bisect_right(baslar, t) - 1
    parcalar = []
    j = i
    while j >= 0 and i - j < 4:
        bas, bit, yazi = srt[j]
        if bas <= t < bit:
            parcalar.insert(0, yazi)
        j -= 1
    return u"\n".join(parcalar)


def utf8_kaydet(ham, yol):
    """Indirilen .srt baytlari -> UTF-8 dosya (BOM atilir; utf-8, sonra Turkce windows-1254). Kodlamayi dondurur."""
    if ham.startswith(b"\xef\xbb\xbf"):
        ham = ham[3:]
    for kodlama in ("utf-8", "cp1254", "latin-1"):
        try:
            metin = ham.decode(kodlama)
            break
        except UnicodeDecodeError:
            continue
    d = os.path.dirname(yol)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    with io.open(yol, "w", encoding="utf-8") as f:
        f.write(metin.replace(u"\r\n", u"\n"))
    return kodlama


_kayitli = set()


def altyazi_fontu(anahtar):
    """Secili .srt fontunun enigma2 adi (addFont ile bir kez kaydedilir); yoksa 'Regular'."""
    f = FONTLAR.get(anahtar)
    if not f:
        return "Regular"
    ad, dosya = f[0], f[1]
    if ad not in _kayitli:
        yol = os.path.join(FONT_DIZINI, dosya)
        if not os.path.isfile(yol):
            gunluk("altyazi fontu yok: %s" % yol)
            return "Regular"
        try:
            from enigma import addFont
            addFont(yol, ad, 100, 0)
            _kayitli.add(ad)
        except Exception as e:  # noqa: BLE001
            gunluk("altyazi fontu kaydedilemedi: %s" % e)
            return "Regular"
    return ad


def _skin():
    W = 1920 if _fhd() else 1280
    H = 1080 if _fhd() else 720
    katman = """<widget name="%s" position="0,0" size="%d,%d" font="Regular;40" foregroundColor="#000000" backgroundColor="#ff000000" transparent="1" halign="center" valign="center" zPosition="%d" />"""
    kontur = "".join(katman % ("kontur%d" % i, W, H // 3, 1) for i in range(len(KONTUR_YONLERI)))
    return """
    <screen name="SubtitleStyleKutu" position="0,0" size="%d,%d" backgroundColor="transparent" flags="wfNoBorder" zPosition="900">
        %s
        <widget name="metin" position="0,0" size="%d,%d" font="Regular;40" foregroundColor="#ffffff" backgroundColor="#ff000000" transparent="1" halign="center" valign="center" zPosition="2" />
    </screen>""" % (W, H, kontur, W, H // 3)


class AltyaziKutusu(Screen):
    """Tek altyazi satiri (cfg'ye gore). Etiket yaziya gore boyutlanir ve ortalanir (kutu stilinde arka plan
    yaziyi sarar); cubuk acikken seridin ustune cikar. Oynatici ekranindan BAGIMSIZ diyalog
    (InfoBarShowHide.hide() oynatici ekranini gizler)."""

    def __init__(self, session):
        self.skin = _skin()
        Screen.__init__(self, session)
        self["metin"] = Label("")
        for i in range(len(KONTUR_YONLERI)):
            self["kontur%d" % i] = Label("")
        self.metin = None
        self.yukarida = None
        self.kontur = 0
        self.dolgu = (0, 0)
        self.boyut = _o(52)
        self.W = 1920 if _fhd() else 1280
        self.H = 1080 if _fhd() else 720
        self.onLayoutFinish.append(self.stil_uygula)

    def _katmanlar(self):
        return [self["kontur%d" % i].instance for i in range(len(KONTUR_YONLERI))]

    @staticmethod
    def _golgesiz(e):
        e.setShadowColor(gRGB(SAYDAM))
        e.setShadowOffset(ePoint(0, 0))
        e.setShadowBlur(0.0)

    def stil_uygula(self):
        e = self["metin"].instance
        if e is None:
            return
        try:
            boyut = _o(int(cfg.boyut.value))
        except (TypeError, ValueError):
            boyut = _o(52)
        self.boyut = boyut
        font = gFont(altyazi_fontu(cfg.font.value), boyut)
        stil = cfg.stil.value
        self.dolgu = (0, 0)
        self.kontur = max(2, int(round(boyut / 22.0))) if stil == "kontur" else 0
        e.setFont(font)
        e.setForegroundColor(gRGB(int(cfg.renk.value, 16)))
        self._golgesiz(e)
        if stil == "kutu":
            e.setTransparent(0)
            e.setBackgroundColor(gRGB(0x50000000))          # ~%70 opak siyah
            self.dolgu = (_o(26), _o(10))
            try:
                e.setCornerRadius(float(_o(12)))
            except Exception:  # noqa: BLE001
                pass
        else:
            e.setTransparent(1)
            try:
                e.setCornerRadius(0.0)
            except Exception:  # noqa: BLE001
                pass
            if stil == "golge":
                e.setShadowColor(gRGB(0x00000000))
                e.setShadowOffset(ePoint(_o(3), _o(3)))
                e.setShadowBlur(max(2.0, boyut / 18.0))
            elif stil == "kontur":
                e.setShadowColor(gRGB(0x60000000))           # konturun disina hafif yumusak golge
                e.setShadowOffset(ePoint(0, _o(2)))
                e.setShadowBlur(max(2.0, boyut / 16.0))
        try:
            e.setPadding(ePoint(self.dolgu[0], self.dolgu[1]))
        except Exception:  # noqa: BLE001
            pass
        for k in self._katmanlar():
            k.setFont(font)
            k.setForegroundColor(gRGB(0x00000000))
            k.setTransparent(1)
            self._golgesiz(k)
            k.hide()
        metin, self.metin = self.metin, None
        self.goster(metin or u"", self.yukarida or False)

    def goster(self, metin, yukarida):
        if metin == self.metin and yukarida == self.yukarida:
            return
        self.metin, self.yukarida = metin, yukarida
        e = self["metin"].instance
        if e is None:
            return
        katmanlar = self._katmanlar() if self.kontur else []
        if not metin:
            for ad in ["metin"] + ["kontur%d" % i for i in range(len(KONTUR_YONLERI))]:
                self[ad].setText("")
            e.hide()
            for k in self._katmanlar():
                k.hide()
            return
        en_genis = self.W - 2 * _o(160)
        e.resize(eSize(en_genis, self.H // 3))           # satir kirma bu genislige gore
        self["metin"].setText(_b(metin))
        try:
            olcu = e.calculateSize()
            w = min(en_genis, olcu.width() + 2 * self.dolgu[0] + _o(8))
            # calculateSize alt kuyruklari (y, g, ğ) saymiyor: kutu stilinde son satir kesiliyordu (olculdu)
            h = olcu.height() + 2 * self.dolgu[1] + _o(4) + self.boyut // 4
        except Exception:  # noqa: BLE001
            w, h = en_genis, self.boyut * 3
        alt = (self.H - _o(CUBUK_H) - _o(24)) if yukarida else (self.H - _o(int(cfg.konum.value)))
        x, y = (self.W - w) // 2, max(0, alt - h)
        e.resize(eSize(w, h))
        e.move(ePoint(x, y))
        for i, k in enumerate(katmanlar):
            dx, dy = KONTUR_YONLERI[i]
            self["kontur%d" % i].setText(_b(metin))
            k.resize(eSize(w, h))
            k.move(ePoint(x + int(round(dx * self.kontur)), y + int(round(dy * self.kontur))))
            k.show()
        e.show()


def _zamanlayici(geri):
    from enigma import eTimer
    z = eTimer()
    try:
        b = z.timeout.connect(geri)
    except AttributeError:
        z.callback.append(geri)
        b = None
    return z, b


class SrtCizici(object):
    """Bir oynatici icin .srt cizimi: dosya, diyalog, 200 ms zamanlayici, konum kestirimi.
    durum() -> (duraklatildi, cubuk_acik); oynaticinin kendi durumundan, boru hattina sorgu yapmadan."""

    def __init__(self, session, yol, durum):
        self.session = session
        self.durum = durum
        self.srt = srt_oku(yol) if yol else []
        self.baslar = [x[0] for x in self.srt]
        self.acik = bool(self.srt)
        self._ornek = None
        self.kutu = None
        self.z, self.zb = _zamanlayici(self._ciz)
        if self.srt:
            self.kutu = session.instantiateDialog(AltyaziKutusu)
            self.kutu.neverAnimate()
            gunluk("harici altyazi: %d satir" % len(self.srt))

    def var(self):
        return bool(self.srt)

    def baslat(self):
        if self.kutu:
            self.kutu.show()
            self.z.start(200, False)

    def ornek(self, konum_ms):
        if self.kutu:
            self._ornek = (konum_ms, time.time())

    def sifirla(self):
        self._ornek = None
        if self.kutu:
            self.kutu.goster(u"", False)

    def degistir(self):
        self.acik = not self.acik
        return self.acik

    def gizle(self):
        if self.kutu:
            self.kutu.hide()

    def goster(self):
        if self.kutu:
            self.kutu.stil_uygula()
            self.kutu.show()

    def _ciz(self):
        if not self.kutu:
            return
        ornek = self._ornek
        metin = u""
        try:
            duraklatildi, cubuk_acik = self.durum()
        except Exception:  # noqa: BLE001
            duraklatildi, cubuk_acik = False, False
        if self.acik and ornek is not None:
            gecen = 0 if duraklatildi else int((time.time() - ornek[1]) * 1000)
            t = ornek[0] + max(0, min(gecen, KESTIRIM_SINIRI_MS)) - int(cfg.gecikme.value)   # +: altyazi gec gelsin
            metin = srt_bul(self.srt, self.baslar, t)
        self.kutu.goster(metin, cubuk_acik)

    def kapat(self):
        self.z.stop()
        if self.kutu:
            try:
                self.session.deleteDialog(self.kutu)
            except Exception:  # noqa: BLE001
                pass
            self.kutu = None
