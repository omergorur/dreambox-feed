# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_subtitlestyle.py); depoda yok.
SURUM = "1.6"
COMMIT = "f8ba943"
