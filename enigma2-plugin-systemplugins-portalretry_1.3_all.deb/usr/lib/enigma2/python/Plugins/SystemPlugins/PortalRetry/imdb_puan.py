# -*- coding: utf-8 -*-
"""
Gercek IMDb puani: Stalker ogesinin tmdb_id'si -> TMDB'den IMDb kimligi (tt...)
-> IMDb'nin gunluk yayimladigi title.ratings dosyasindan puan.

NEDEN: sunucunun "rating_imdb" alani IMDb puani degil (olculdu: tum ogelerde
rating_kinopoisk ile ayni, tam sayi; Minerva Academy 8, IMDb'de 5.3).
Buna karsilik her ogede tmdb_id dolu; bu kimlikle eslestirme ad/yil
tahmini gerektirmez.

  - TMDB anahtari: /etc/enigma2/portalretry-tmdb.key (kullanici koyar;
    pakette yok). Yoksa puan hic gosterilmez.
  - Eslesmeler kalici: <dizin>/tmdb-imdb.json  ("tv:312557" -> "tt28765828")
    TMDB'de IMDb kimligi olmayanlar 7 gun sonra yeniden sorulur.
  - Puanlar: <dizin>/title.ratings.tsv (datasets.imdbws.com, ~30 MB acik),
    gunde bir tazelenir; bellege alinmaz, tt kimligine gore (dosya alfabetik
    sirali) diskte ikili aramayla okunur.
Bu urun TMDB API'sini kullanir ancak TMDB tarafindan onaylanmamistir.
IMDb verisi kisisel, ticari olmayan kullanim icindir.
"""
import json
import os
import subprocess
import threading
import time
import traceback

ETIKET = "[PortalRetry]"
ANAHTAR_DOSYA = "/etc/enigma2/portalretry-tmdb.key"
DIZIN = "/data/portalretry"
ESLEME = os.path.join(DIZIN, "tmdb-imdb.json")
PUANLAR = os.path.join(DIZIN, "title.ratings.tsv")
PUAN_URL = "https://datasets.imdbws.com/title.ratings.tsv.gz"
TMDB = "https://api.themoviedb.org/3/%s/%s/external_ids"
PUAN_OMRU = 24 * 3600
BOS_OMRU = 7 * 24 * 3600
ESZAMANLI = 6
SAYFA_BUTCESI = 5.0  # bir sayfadaki bilinmeyenler icin en fazla bu kadar sn

_kilit = threading.Lock()
_esleme = {}  # "tv:312557" -> ["tt28765828", zaman]
_kirli = [False]
_puan_onbellek = {}
_anahtar = [None]
_indiriliyor = [False]


def _oku_anahtar():
	try:
		with open(ANAHTAR_DOSYA) as f:
			return f.read().strip() or None
	except IOError:
		return None


def hazir_mi():
	return bool(_anahtar[0]) and os.path.isfile(PUANLAR)


def baslat():
	"""Eklenti yuklenirken cagrilir (ana is parcacigi); agir is arka planda."""
	_anahtar[0] = _oku_anahtar()
	if not _anahtar[0]:
		print("%s IMDb: TMDB anahtari yok (%s), puan gosterilmeyecek" % (ETIKET, ANAHTAR_DOSYA))
		return
	if not os.path.isdir(os.path.dirname(DIZIN)):
		print("%s IMDb: %s yok, puan gosterilmeyecek" % (ETIKET, os.path.dirname(DIZIN)))
		_anahtar[0] = None
		return
	try:
		if not os.path.isdir(DIZIN):
			os.makedirs(DIZIN)
		with open(ESLEME) as f:
			_esleme.update(json.load(f))
	except (IOError, ValueError):
		pass
	puanlari_tazele()


def puanlari_tazele():
	try:
		yas = time.time() - os.path.getmtime(PUANLAR)
	except OSError:
		yas = None
	if yas is not None and yas < PUAN_OMRU:
		return
	with _kilit:
		if _indiriliyor[0]:
			return
		_indiriliyor[0] = True
	t = threading.Thread(target=_indir, name="portalretry_imdb")
	t.daemon = True
	t.start()


def _indir():
	import requests
	gz = PUANLAR + ".gz.tmp"
	tsv = PUANLAR + ".tmp"
	try:
		r = requests.get(PUAN_URL, stream=True, timeout=30)
		r.raise_for_status()
		with open(gz, "wb") as f:
			for parca in r.iter_content(256 * 1024):
				f.write(parca)
		# acma ayri surecte: enigma2'nin Python kilidini tutmasin
		if subprocess.call("nice -n 19 gzip -dc '%s' > '%s'" % (gz, tsv), shell=True) != 0:
			raise IOError("gzip acilamadi")
		os.rename(tsv, PUANLAR)
		with _kilit:
			_puan_onbellek.clear()
		print("%s IMDb: puan dosyasi guncellendi (%d MB)" % (ETIKET, os.path.getsize(PUANLAR) // (1024 * 1024)))
	except Exception as e:
		print("%s IMDb: puan dosyasi indirilemedi: %s" % (ETIKET, e))
	finally:
		for yol in (gz, tsv):
			try:
				os.remove(yol)
			except OSError:
				pass
		_indiriliyor[0] = False


def _ara(tt):
	"""title.ratings.tsv'de tt'yi ikili aramayla bulur: "5.3" ya da ""."""
	hedef = tt + "\t"
	with open(PUANLAR, "rb") as f:
		f.seek(0, 2)
		alt, ust = 0, f.tell()
		# alt: tt'den kucuk olmayan ilk satirin baslangicini arar
		while alt < ust:
			orta = (alt + ust) // 2
			f.seek(orta)
			if orta:
				f.readline()
			satir = f.readline()
			if not satir or satir >= hedef:
				ust = orta
			else:
				alt = orta + 1
		f.seek(alt)
		if alt:
			f.readline()
		for _ in range(3):
			satir = f.readline()
			if not satir:
				break
			if satir.startswith(hedef):
				return satir.split("\t")[1].strip()
			if satir > hedef:
				break
	return ""


def puan(tt):
	if not tt or not os.path.isfile(PUANLAR):
		return ""
	with _kilit:
		if tt in _puan_onbellek:
			return _puan_onbellek[tt]
	try:
		p = _ara(tt)
	except IOError:
		return ""
	with _kilit:
		_puan_onbellek[tt] = p
	return p


def _anahtar_adi(tur, tmdb_id):
	return "%s:%s" % (tur, tmdb_id)


def imdb_kimligi(tur, tmdb_id):
	"""Yalnizca onbellekten: "tt..." ya da "" (bilinmiyor / yok)."""
	with _kilit:
		k = _esleme.get(_anahtar_adi(tur, tmdb_id))
	return k[0] if k else ""


def _bilinmeyen_mi(tur, tmdb_id):
	with _kilit:
		k = _esleme.get(_anahtar_adi(tur, tmdb_id))
	return k is None or (not k[0] and time.time() - k[1] > BOS_OMRU)


def _tmdb_sor(tur, tmdb_id):
	import requests
	for t in ((tur, "movie" if tur == "tv" else "tv")):
		try:
			r = requests.get(TMDB % (t, tmdb_id), params={"api_key": _anahtar[0]}, timeout=4)
		except Exception:
			return None  # ag hatasi: kaydetme, sonra yeniden denenir
		if r.status_code == 404:
			continue  # sunucu turu yanlis yazmis olabilir; digerini dene
		if r.status_code != 200:
			return None
		try:
			return r.json().get("imdb_id") or ""
		except ValueError:
			return None
	return ""


def toplu_esle(tur, kimlikler):
	"""Bilinmeyen tmdb kimliklerini TMDB'den ceker (arka plan is parcacigindan)."""
	if not _anahtar[0]:
		return
	sira = [k for k in set(kimlikler) if k and _bilinmeyen_mi(tur, k)]
	if not sira:
		return
	son = time.time() + SAYFA_BUTCESI
	kilit = threading.Lock()

	def isci():
		while time.time() < son:
			with kilit:
				if not sira:
					return
				k = sira.pop()
			tt = _tmdb_sor(tur, k)
			if tt is not None:
				with _kilit:
					_esleme[_anahtar_adi(tur, k)] = [tt, int(time.time())]
					_kirli[0] = True
	isciler = [threading.Thread(target=isci, name="portalretry_tmdb") for _ in range(min(ESZAMANLI, len(sira)))]
	for t in isciler:
		t.daemon = True
		t.start()
	for t in isciler:
		t.join(max(0.1, son - time.time()))
	kaydet()


def kaydet():
	with _kilit:
		if not _kirli[0]:
			return
		veri = json.dumps(_esleme)
		_kirli[0] = False
	try:
		gecici = ESLEME + ".tmp"
		with open(gecici, "w") as f:
			f.write(veri)
		os.rename(gecici, ESLEME)
	except (IOError, OSError):
		traceback.print_exc()
