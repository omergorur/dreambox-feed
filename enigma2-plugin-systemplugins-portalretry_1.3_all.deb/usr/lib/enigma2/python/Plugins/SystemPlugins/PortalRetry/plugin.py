# -*- coding: utf-8 -*-
"""
PortalRetry -- Stalker portal liste sayfalarini gecici hatada yeniden ister.

NEDEN: AJPanel bir dizi/film kategorisini sayfa sayfa ceker (her sayfa ayri
bir "action=get_ordered_list" istegi). Sunucu tek bir sayfada bile zaman
asimi, 5xx ya da bos/bozuk cevap verirse AJPanel butun listeyi "error while
reading" ile birakir (olculdu: 1039 ogeden 70'inde). Hata cogu zaman
geciciyor; ayni sayfa bir-iki saniye sonra geliyor.

Bu eklenti requests.get'i sarmalar; YALNIZCA get_ordered_list isteklerinde
ve yalnizca arka plan is parcacigindan (ana dongu bekletilmez) su durumlarda
1, 2, 4 sn bekleyerek en fazla 3 kez yeniden dener:
  - baglanti hatasi / zaman asimi
  - HTTP 429, 5xx
  - HTTP 200 ama govde JSON degil ya da "js" alani yok
Son deneme de basarisizsa sonuc AJPanel'e oldugu gibi iletilir.

1.2 -- gercek IMDb puani (imdb.py): sunucunun "rating_imdb" alani IMDb
puani degil (olculdu: kinopoisk ile ayni tam sayi). Ogenin tmdb_id'si ile
TMDB'den IMDb kimligi, IMDb'nin gunluk dosyasindan puan alinir. Cevap
AJPanel'e ulasmadan puan, AJPanel'in zaten gosterdigi alanlara yazilir:
  - film ve dizi listeleri: "Catch-up" sutunu (bu listelerde hep bos ve
    yalnizca gosterim icin; tv_archive_duration)  -> "5.3"
  - bolum sayfasi (movie_id istegi): sezon adi   -> "Sezon 1 | IMDb 5.3"
    (dizi listesinde gorulen puan kullanilir)
1.3 -- AJPanel'in film/dizi listesindeki "Catch-up" sutun basligi "IMDb"
olur: enigma2 acildiktan sonra AJPanel'in yuklu kodunda basliklar demeti
(icinde "Cat./Genre", sonu "Catch-up") ICERIGINE gore aranir ve yalnizca o
sabit degistirilir; AJPanel dosyasina dokunulmaz, karisik fonksiyon adlari
degisse de calisir. Bulunamazsa hicbir sey yapilmaz.
Gunluk:  journalctl -u enigma2 | grep PortalRetry
"""
import json
import re
import sys
import types
import threading
import time
import traceback

from Plugins.Plugin import PluginDescriptor

_ETIKET = "[PortalRetry]"
_BEKLEME = (1, 2, 4)


def _ana_mi():
	return isinstance(threading.current_thread(), threading._MainThread)


def _hedef_mi(url):
	return isinstance(url, basestring) and "action=get_ordered_list" in url


_dizi_puani = {}  # dizi id -> "5.3" (dizi listesinden, bolum sayfasi icin)
_puan_ilk = [True]


def _puan_ekle(url, res):
	"""Gercek IMDb puanini AJPanel'in gosterdigi alanlara yazar; cevabi yerinde degistirir."""
	import imdb_puan as imdb
	tur = re.search(r"[?&]type=(vod|series)(&|$)", url)
	if not tur or res.status_code != 200 or not imdb.hazir_mi():
		return
	try:
		veri = json.loads(res.text)
		ogeler = veri["js"]["data"]
	except Exception:
		return
	if not isinstance(ogeler, list):
		return
	ogeler = [x for x in ogeler if isinstance(x, dict)]
	film_id = re.search(r"[?&]movie_id=([^&]+)", url)
	yazilan = 0
	if film_id:
		# bolum sayfasi: ogeler sezonlar; AJPanel sezon adini "Season" sutununda gosterir
		p = _dizi_puani.get(film_id.group(1), "")
		for item in ogeler:
			if p and item.get("name") and "IMDb" not in item["name"]:
				item["name"] = "%s | IMDb %s" % (item["name"], p)
				yazilan += 1
	else:
		imdb_tur = "tv" if tur.group(1) == "series" else "movie"
		if not _ana_mi():
			imdb.toplu_esle(imdb_tur, [str(x.get("tmdb_id") or "") for x in ogeler])
		for item in ogeler:
			p = imdb.puan(imdb.imdb_kimligi(imdb_tur, str(item.get("tmdb_id") or "")))
			if not p:
				continue
			if item.get("id") is not None:
				_dizi_puani[str(item["id"])] = p
			# AJPanel: sayi olmayan tv_archive_duration "Catch-up" sutununda aynen gorunur
			item["tv_archive_duration"] = p if "." in p else p + ".0"
			yazilan += 1
	if _puan_ilk[0] and not film_id:
		_puan_ilk[0] = False
		print("%s IMDb: ilk sayfada %d/%d ogeye puan yazildi (%s)" % (_ETIKET, yazilan, len(ogeler), tur.group(1)))
	if yazilan:
		res._content = json.dumps(veri).encode("utf-8")
		res.encoding = "utf-8"


def _sorun(res):
	"""Cevap yeniden denenmeli mi? Nedeni (str) ya da None."""
	kod = res.status_code
	if kod == 429 or kod >= 500:
		return "HTTP %d" % kod
	if kod != 200:
		return None  # 4xx kalici; yeniden denemek anlamsiz
	try:
		veri = json.loads(res.text)
	except ValueError:
		return "HTTP 200, govde JSON degil (%d bayt)" % len(res.content or "")
	if not isinstance(veri, dict) or "js" not in veri:
		return "HTTP 200, 'js' alani yok"
	return None


def _kur():
	import requests
	import requests.api

	asil_get = requests.get
	yeniden_denenebilir = (requests.Timeout, requests.ConnectionError)

	def get(url, params=None, **kwargs):
		if not _hedef_mi(url):
			return asil_get(url, params=params, **kwargs)
		res = _getir(url, params, kwargs)
		if res is not None:
			try:
				_puan_ekle(url, res)
			except Exception:
				traceback.print_exc()
		return res

	def _getir(url, params, kwargs):
		if _ana_mi():
			# ana dongu bekletilmez: yeniden deneme yok
			return asil_get(url, params=params, **kwargs)
		for deneme, bekle in enumerate(_BEKLEME + (None,)):
			try:
				res = asil_get(url, params=params, **kwargs)
				neden = _sorun(res)
			except yeniden_denenebilir as e:
				if bekle is None:
					raise
				res, neden = None, e.__class__.__name__
			if neden is None:
				if deneme:
					print("%s %d. yeniden denemede geldi" % (_ETIKET, deneme))
				return res
			if bekle is None:
				print("%s %d denemede de olmadi (%s), AJPanel'e iletiliyor: %s" % (_ETIKET, deneme + 1, neden, url))
				return res
			print("%s %s -- %d sn sonra yeniden denenecek: %s" % (_ETIKET, neden, bekle, url))
			time.sleep(bekle)

	requests.get = get
	requests.api.get = get
	print("%s etkin: get_ordered_list istekleri gecici hatada yeniden denenir, gercek IMDb puani eklenir" % _ETIKET)


try:
	_kur()
	import imdb_puan
	imdb_puan.baslat()
except Exception:
	traceback.print_exc()


_YENI_BASLIK = "IMDb"


def _baslik_mi(c):
	return isinstance(c, tuple) and len(c) > 2 and "Cat./Genre" in c and c[-1] == "Catch-up"


def _kod_yamala(kod):
	sabitler = list(kod.co_consts)
	degisti = False
	for i, c in enumerate(sabitler):
		if _baslik_mi(c):
			sabitler[i] = c[:-1] + (_YENI_BASLIK,)
			degisti = True
		elif isinstance(c, types.CodeType):
			yeni = _kod_yamala(c)
			if yeni is not c:
				sabitler[i] = yeni
				degisti = True
	if not degisti:
		return kod
	return types.CodeType(kod.co_argcount, kod.co_nlocals, kod.co_stacksize, kod.co_flags,
		kod.co_code, tuple(sabitler), kod.co_names, kod.co_varnames, kod.co_filename,
		kod.co_name, kod.co_firstlineno, kod.co_lnotab, kod.co_freevars, kod.co_cellvars)


def _fonksiyonlar(modul):
	for deger in list(vars(modul).values()):
		if isinstance(deger, types.FunctionType):
			yield deger
		elif isinstance(deger, (type, types.ClassType)) and getattr(deger, "__module__", None) == modul.__name__:
			for u in list(vars(deger).values()):
				if isinstance(u, (staticmethod, classmethod)):
					u = u.__func__
				if isinstance(u, types.FunctionType):
					yield u


def _baslik_duzelt():
	sayi = 0
	for ad, modul in list(sys.modules.items()):
		if not modul or not ad.startswith("Plugins.Extensions.") or not ad.endswith(".plugin"):
			continue
		for f in _fonksiyonlar(modul):
			yeni = _kod_yamala(f.func_code)
			if yeni is not f.func_code:
				f.func_code = yeni
				sayi += 1
	print("%s AJPanel 'Catch-up' basligi -> '%s': %d yerde" % (_ETIKET, _YENI_BASLIK, sayi))


def _oturum_basladi(reason, session=None, **kwargs):
	# eklentilerin hepsi yuklendikten sonra
	if reason == 0:
		try:
			_baslik_duzelt()
		except Exception:
			traceback.print_exc()


def Plugins(**kwargs):
	return [PluginDescriptor(name="PortalRetry", where=PluginDescriptor.WHERE_SESSIONSTART, fnc=_oturum_basladi)]
