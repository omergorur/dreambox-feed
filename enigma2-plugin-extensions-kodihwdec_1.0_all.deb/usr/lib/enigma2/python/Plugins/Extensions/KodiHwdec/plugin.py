# -*- coding: utf-8 -*-
import os

from Plugins.Plugin import PluginDescriptor

# IKI AYRI IKON, IKI AYRI MEKANIZMA:
#
#   Eklenti tarayicisi -> PluginDescriptor(icon=...), eklentinin kendi
#   dizininden okunur. Burada Kodi'nin genis yazi logosu kullaniliyor;
#   pakette geliyor.
#
#   Ana menu -> Screens/Menu.py, ikonu AKTIF SKININ menu/<anahtar>.svg
#   dosyasindan okur ve skin dizini disindaki yollari acikca reddeder
#   (current_skin kontrolu). Bu yuzden orasi pakete gomulemez; kurulumda
#   her skinin KENDI menu/xbmc.svg dosyasi menu/kodihwdec.svg olarak
#   kopyalaniyor, boylece ikon her skinin cizim diline uyuyor.
HERE = os.path.dirname(os.path.abspath(__file__))
ICON = "plugin.svg" if os.path.exists(os.path.join(HERE, "plugin.svg")) else None

NAME = _("Kodi (donanim cozucu)")
DESC = _("Donanim video cozucu destekli Kodi'yi baslat")


def main(session, **kwargs):
	from kodihwdec import KodiHwdec
	session.open(KodiHwdec)


def MainMenu(menuid, **kwargs):
	if menuid == "mainmenu":
		return [(NAME, main, "kodihwdec", 22)]
	return []


def Plugins(**kwargs):
	return [
		PluginDescriptor(name=NAME, description=DESC, icon=ICON,
		                 where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
		PluginDescriptor(name=NAME, description=DESC,
		                 where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
		PluginDescriptor(name=NAME, description=DESC,
		                 where=PluginDescriptor.WHERE_MENU, fnc=MainMenu),
	]
