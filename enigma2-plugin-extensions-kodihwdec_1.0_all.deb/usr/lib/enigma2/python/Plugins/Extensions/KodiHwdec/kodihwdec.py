# -*- coding: utf-8 -*-
# Donanim cozucu destekli Kodi'yi enigma2 icinden baslatir.
#
# Kutunun kendi "Kodi MediaCenter" eklentisi (XBMCMediaCenter) yerinde kalir;
# bu ayri bir menu girisidir. Iskelet oradan alinmistir, farklari:
#
#   * /usr/bin/kodi-hwdec calistirilir (stok /usr/bin/xbmc-start degil)
#   * ALSA HDMI aygiti KAPATILIR: enigma2 hw:0,0'i acik tutuyor ve Kodi'nin
#     hdmidmix (dmix) aygiti ona baglanamiyor -> Kodi'de ses cikmiyordu
#     ("CAESinkALSA - Unable to open device hdmidmix for playback").
#     Cikista ServiceStopScreen servisi geri baslattiginda enigma2 aygiti
#     yeniden aciyor.

from enigma import eConsoleAppContainer, fbClass, eRCInput

from Components.Language import language
from Components.Sources.StaticText import StaticText

from Screens.Screen import Screen
from Screens.ServiceStopScreen import ServiceStopScreen

from Tools.Directories import resolveFilename, SCOPE_PLUGINS

from skin import loadSkin

loadSkin(resolveFilename(SCOPE_PLUGINS, "Extensions/KodiHwdec/skin.xml"))

LAUNCHER = "/usr/bin/kodi-hwdec"


class KodiHwdecSummary(Screen):
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent=parent)
		self.skinName = ["KodiHwdecSummary"]


class KodiHwdec(Screen, ServiceStopScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		ServiceStopScreen.__init__(self)
		self.skinName = ["KodiHwdec"]
		self["title"] = StaticText("Kodi")
		self["lcdinfo"] = StaticText()
		self.__container = eConsoleAppContainer()
		self.__appClosed_conn = self.__container.appClosed.connect(self.__runFinished)
		self.stopService()
		self.__run()

	def __run(self):
		print "[KodiHwdec] baslatiliyor"
		try:
			from enigma import eAlsaOutput
			eAlsaOutput.getInstance(eAlsaOutput.HDMI).close()
			print "[KodiHwdec] ALSA HDMI kapatildi"
		except Exception, e:
			print "[KodiHwdec] ALSA kapatilamadi:", e
		eRCInput.getInstance().lock()
		fbClass.getInstance().lock()
		com = "export LANG=" + language.getLanguage() + ".UTF-8;"
		com += LAUNCHER + ";"
		self.__container.execute(com)

	def __runFinished(self, retval):
		print "[KodiHwdec] cikildi, kod =", retval
		fbClass.getInstance().unlock()
		eRCInput.getInstance().unlock()
		self.close()

	def createSummary(self):
		return KodiHwdecSummary
