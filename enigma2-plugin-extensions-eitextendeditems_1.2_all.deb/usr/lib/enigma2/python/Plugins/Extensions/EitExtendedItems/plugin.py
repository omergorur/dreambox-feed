# -*- coding: utf-8 -*-
#
# EitExtendedItems
#
# DreamOS enigma2'de EPG'nin "alt bilgileri" -- Actors, Directors, Production Year,
# Country gibi alanlar -- gorunmez, cunku DreamOS'un C++ EIT ayristiricisi
# extended_event_descriptor icindeki item listesini kullanmaz; sadece text_char
# alanini eServiceEvent::getExtendedDescription() ile verir.
#
# Bu eklenti EIT'i (PID 0x12) kendi section filtresi ile okur, item'lari onbellege
# alir ve calisma zamaninda EPG ekranlarina ekler. Sistem dosyalarina dokunmaz.
#
# Kurulum:
#   /usr/lib/enigma2/python/Plugins/Extensions/EitExtendedItems/
#   ardindan enigma2 yeniden baslatilir.
#
# Ayarlar: Menu > Eklentiler > EPG Ek Bilgileri (EIT items)
#
VERSION = "1.2"

from Plugins.Plugin import PluginDescriptor

from .settings import cfg
from .eitreader import getReader, log
from . import patcher
from .ui import openSetup


def sessionstart(reason, session=None, **kwargs):
    if reason == 0:
        if not cfg.enabled.value:
            log("eklenti kapali")
            return
        patcher.patchAll()
        getReader().start()
        log("v%s baslatildi" % VERSION)
    elif reason == 1:
        getReader().stop()
        patcher.unpatchAll()


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="EitExtendedItems",
            description="EPG ek bilgileri (Actors / Production Year ...)",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            needsRestart=False,
            fnc=sessionstart),
        PluginDescriptor(
            name="EPG Ek Bilgileri (EIT items)",
            description="EPG'de Actors / Directors / Production Year alanlarini goster",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            needsRestart=False,
            fnc=openSetup),
    ]
