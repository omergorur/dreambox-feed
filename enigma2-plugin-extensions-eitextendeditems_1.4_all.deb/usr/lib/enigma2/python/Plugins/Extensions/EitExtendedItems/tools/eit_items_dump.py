#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# eit_items_dump.py v2 - DreamOS / enigma2 teshis araci
#
# 1) Once PAT (PID 0x00 / table 0x00) okuyarak demux erisiminin calistigini dogrular.
# 2) Sonra EIT (PID 0x12 / table 0x4E, 0x4F, 0x50) okuyup extended_event_descriptor
#    icindeki "items" listesini (Actors / Directors / Production Year ...) doker.
# 3) Parametre verilmezse demux0..demuxN arasinda otomatik tarar.
#
# Kullanim:  python /tmp/eit_items_dump.py            -> otomatik tarama
#            python /tmp/eit_items_dump.py 0 2 20     -> adapter 0, demux 2, 20 sn
#
import os, sys, struct, fcntl, select, time, glob

PY3 = sys.version_info[0] >= 3

# struct dmx_sct_filter_params:
#   u16 pid; u8 filter[16]; u8 mask[16]; u8 mode[16]; u32 timeout; u32 flags
# native hizalama ile: 2 + 48 + 2 dolgu + 4 + 4 = 60 byte
SCT_FMT = "<H48s2xII"

DMX_SET_FILTER      = 0x403C6F2B   # _IOW('o', 43, 60)
DMX_START           = 0x00006F29
DMX_STOP            = 0x00006F2A
DMX_SET_BUFFER_SIZE = 0x00006F2D   # _IO('o', 45)
DMX_IMMEDIATE_START = 4
DMX_CHECK_CRC       = 1


def b2i(x):
    return x if PY3 else ord(x)


def open_filter(dev, pid, table_ids, verbose=True):
    fd = os.open(dev, os.O_RDWR)
    try:
        fcntl.ioctl(fd, DMX_SET_BUFFER_SIZE, 256 * 1024)
    except Exception as e:
        if verbose:
            print("  (uyari: buffer buyutulemedi: %s)" % e)
    filt = bytearray(16)
    mask = bytearray(16)
    mode = bytearray(16)
    if len(table_ids) == 1:
        filt[0] = table_ids[0]
        mask[0] = 0xFF
    else:
        common = 0xFF
        for t in table_ids[1:]:
            common &= (~(table_ids[0] ^ t)) & 0xFF
        filt[0] = table_ids[0] & common
        mask[0] = common
    params = struct.pack(SCT_FMT, pid,
                         bytes(filt) + bytes(mask) + bytes(mode),
                         0,                 # timeout 0 = sonsuz
                         DMX_CHECK_CRC)
    fcntl.ioctl(fd, DMX_SET_FILTER, params)
    fcntl.ioctl(fd, DMX_START)
    return fd


def read_sections(fd, seconds, cb):
    t0 = time.time()
    got = 0
    while time.time() - t0 < seconds:
        r, _, _ = select.select([fd], [], [], 1.0)
        if not r:
            continue
        try:
            data = os.read(fd, 65536)
        except OSError as e:
            print("  read hatasi: %s" % e)
            continue
        if data:
            got += 1
            cb(data)
    return got


def close_filter(fd):
    try:
        fcntl.ioctl(fd, DMX_STOP)
    except Exception:
        pass
    os.close(fd)


# --- DVB metin cozumu (ETSI EN 300 468 Annex A, basitlestirilmis) ---
CHARSETS = {0x01: "iso-8859-5", 0x02: "iso-8859-6", 0x03: "iso-8859-7",
            0x04: "iso-8859-8", 0x05: "iso-8859-9", 0x06: "iso-8859-10",
            0x07: "iso-8859-11", 0x09: "iso-8859-13", 0x0A: "iso-8859-14",
            0x0B: "iso-8859-15", 0x11: "utf-16-be", 0x15: "utf-8"}


def dvb_text(b):
    if not b:
        return ""
    b = bytes(bytearray(b))
    enc = "iso-8859-9"
    if b2i(b[0:1]) < 0x20:
        first = b2i(b[0:1])
        if first == 0x10 and len(b) >= 3:
            enc = "iso-8859-%d" % b2i(b[2:3])
            b = b[3:]
        else:
            enc = CHARSETS.get(first, "iso-8859-9")
            b = b[1:]
    b = b.replace(b"\x8a", b"\n")
    try:
        s = b.decode(enc, "replace")
    except Exception:
        s = b.decode("iso-8859-9", "replace")
    return s if PY3 else s.encode("utf-8")


def parse_eit(sec, seen):
    if len(sec) < 14:
        return
    table_id = b2i(sec[0:1])
    seclen = ((b2i(sec[1:2]) & 0x0F) << 8) | b2i(sec[2:3])
    service_id = struct.unpack(">H", sec[3:5])[0]
    end = min(3 + seclen - 4, len(sec))
    pos = 14
    while pos + 12 <= end:
        event_id = struct.unpack(">H", sec[pos:pos + 2])[0]
        dll = ((b2i(sec[pos + 10:pos + 11]) & 0x0F) << 8) | b2i(sec[pos + 11:pos + 12])
        dpos = pos + 12
        dend = min(dpos + dll, end)
        title = ""
        ext_text = ""
        items = []
        while dpos + 2 <= dend:
            tag = b2i(sec[dpos:dpos + 1])
            dlen = b2i(sec[dpos + 1:dpos + 2])
            body = sec[dpos + 2:dpos + 2 + dlen]
            if tag == 0x4D and len(body) >= 4:
                nl = b2i(body[3:4])
                title = dvb_text(body[4:4 + nl])
            elif tag == 0x4E and len(body) >= 6:
                loi = b2i(body[4:5])
                ip = 5
                iend = 5 + loi
                while ip + 1 <= iend and iend <= len(body):
                    idl = b2i(body[ip:ip + 1])
                    ip += 1
                    idesc = dvb_text(body[ip:ip + idl])
                    ip += idl
                    if ip >= len(body):
                        break
                    il = b2i(body[ip:ip + 1])
                    ip += 1
                    ival = dvb_text(body[ip:ip + il])
                    ip += il
                    items.append((idesc, ival))
                if iend < len(body):
                    tl = b2i(body[iend:iend + 1])
                    ext_text += dvb_text(body[iend + 1:iend + 1 + tl])
            dpos += 2 + dlen
        key = (service_id, event_id)
        if key not in seen:
            seen[key] = len(items)
            print("=" * 72)
            print("table=0x%02X  service_id=0x%04X  event_id=%d" % (table_id, service_id, event_id))
            print("Baslik      : %s" % title)
            t = ext_text.replace("\n", " ")
            print("Ext. metin  : %s" % (t[:160] + ("..." if len(t) > 160 else "")))
            if items:
                print(">>> ITEM SAYISI: %d  <<<  (DreamOS bu satirlari ATIYOR)" % len(items))
                for d, v in items:
                    print("    %-22s : %s" % (d, v))
            else:
                print("    item yok")
            sys.stdout.flush()
        pos = dend


def try_demux(dev, seconds):
    print("")
    print("--- %s ---" % dev)
    try:
        fd = open_filter(dev, 0x00, [0x00])
    except Exception as e:
        print("  DMX_SET_FILTER basarisiz: %s" % e)
        return False, {}
    pat = [0]

    def onpat(d):
        if pat[0] == 0:
            print("  PAT OK (%d byte) -> demux erisimi calisiyor" % len(d))
        pat[0] += 1

    n = read_sections(fd, 4, onpat)
    close_filter(fd)
    if not n:
        print("  PAT gelmedi -> bu demux TS'e bagli degil, atlaniyor")
        return False, {}

    seen = {}
    fd = open_filter(dev, 0x12, [0x4E, 0x4F, 0x50])
    print("  EIT dinleniyor (%d sn)..." % seconds)
    n = read_sections(fd, seconds, lambda d: parse_eit(d, seen))
    close_filter(fd)
    print("  -> %d section, %d farkli event" % (n, len(seen)))
    return True, seen


def main():
    print("Python %s" % sys.version.split()[0])
    args = sys.argv[1:]
    if len(args) >= 2:
        devs = ["/dev/dvb/adapter%s/demux%s" % (args[0], args[1])]
        secs = int(args[2]) if len(args) > 2 else 20
    else:
        devs = sorted(glob.glob("/dev/dvb/adapter*/demux*"))
        secs = int(args[0]) if len(args) == 1 else 15
    if not devs:
        print("Hic demux cihazi yok. 'ls -l /dev/dvb/' ciktisini paylasin.")
        return 1
    print("Bulunan demux'lar: %s" % ", ".join(devs))
    total = {}
    for dev in devs:
        try:
            ok, seen = try_demux(dev, secs)
        except Exception as e:
            print("  hata: %s" % e)
            continue
        total.update(seen)
        if seen:
            break
    print("")
    print("=" * 72)
    if not total:
        print("SONUC: hic EIT event'i okunamadi.")
    else:
        withitems = sum(1 for v in total.values() if v)
        print("SONUC: %d event okundu, %d tanesinde item var." % (len(total), withitems))
        if withitems:
            print("=> Bilgi yayinda GELIYOR, DreamOS ayristirmiyor. Converter yazilabilir.")
        else:
            print("=> Bu transponderde item gonderilmiyor.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
