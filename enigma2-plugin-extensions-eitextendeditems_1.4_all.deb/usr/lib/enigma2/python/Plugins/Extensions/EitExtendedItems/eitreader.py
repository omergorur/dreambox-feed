# -*- coding: utf-8 -*-
#
# EitExtendedItems - EIT okuyucu ve item onbellegi
#
# DreamOS'un C++ EIT ayristiricisi (lib/service/event.cpp) extended_event_descriptor
# icindeki item listesini -- Actors / Directors / Production Year / Country gibi
# alanlari -- kullanmiyor; sadece text_char alanini eServiceEvent::getExtendedDescription()
# ile veriyor. Python API'sinde de item'lara erisecek bir metot yok
# (bkz. enigma.py, class eServiceEvent).
#
# Bu modul PID 0x12'yi kendi section filtresi ile okuyup item listesini onbellege alir.
# Okuma eSocketNotifier ile enigma2'nin ana dongusune baglanir; ayri thread yoktur.
#
# Kapsam: o an takili transponderdeki EIT tablolari (0x40..0x5F -- actual/other TS,
# present-following + schedule). Baska transponderdeki kanallarin item'lari, o
# transpondere gecilene kadar bilinmez.
#
import os
import glob
import struct
import fcntl

from select import POLLIN

from enigma import eSocketNotifier, eTimer, iPlayableService

from .settings import cfg, hiddenItemNames

# struct dmx_sct_filter_params:
#   u16 pid; u8 filter[16]; u8 mask[16]; u8 mode[16]; u32 timeout; u32 flags
# native hizalama ile 2 + 48 + 2 dolgu + 4 + 4 = 60 byte
SCT_FMT = "<H48s2xII"

DMX_SET_FILTER      = 0x403C6F2B   # _IOW('o', 43, 60)
DMX_START           = 0x00006F29
DMX_STOP            = 0x00006F2A
DMX_SET_BUFFER_SIZE = 0x00006F2D   # _IO('o', 45)
DMX_CHECK_CRC       = 1

EIT_PID = 0x12
# 0x40 / maske 0xE0 -> 0x40..0x5F arasi tum EIT tablolari
EIT_TABLE_BASE = 0x40
EIT_TABLE_MASK = 0xE0

# Demux bu sure boyunca hic section vermezse siradaki demux denenir.
DEMUX_PROBE_MS = 8000


def log(msg):
    if cfg.debug.value:
        print("[EitExtendedItems] %s" % msg)


def _b2i(x):
    """Tek byte'lik dilimi int'e cevirir (Python 2/3 uyumlu)."""
    if isinstance(x, int):
        return x
    return ord(x)


# --- DVB metin cozumu (ETSI EN 300 468 Annex A) ---
_CHARSETS = {
    0x01: "iso-8859-5",  0x02: "iso-8859-6",  0x03: "iso-8859-7",
    0x04: "iso-8859-8",  0x05: "iso-8859-9",  0x06: "iso-8859-10",
    0x07: "iso-8859-11", 0x09: "iso-8859-13", 0x0A: "iso-8859-14",
    0x0B: "iso-8859-15", 0x11: "utf-16-be",   0x15: "utf-8",
}

# Kod tablosu belirtilmemis metinlerde kullanilacak varsayilan. Turksat/Avrupa
# yayinlarinda pratikte Latin-5 dogru sonucu verir.
DEFAULT_CHARSET = "iso-8859-9"

_PY2 = str is bytes


def dvb_text(raw):
    if not raw:
        return ""
    b = bytes(bytearray(raw))
    enc = DEFAULT_CHARSET
    first = _b2i(b[0:1])
    if first < 0x20:
        if first == 0x10 and len(b) >= 3:
            enc = "iso-8859-%d" % _b2i(b[2:3])
            b = b[3:]
        else:
            enc = _CHARSETS.get(first, DEFAULT_CHARSET)
            b = b[1:]
    b = b.replace(b"\x8a", b"\n")
    try:
        s = b.decode(enc, "replace")
    except (LookupError, UnicodeDecodeError):
        s = b.decode(DEFAULT_CHARSET, "replace")
    if _PY2:                  # enigma2 Python 2'de utf-8 byte string bekler
        return s.encode("utf-8")
    return s


def _normTitle(t):
    """Baslik karsilastirmasi icin gevsek normalizasyon."""
    if not t:
        return ""
    return " ".join(t.split()).lower()


def titlesMatch(a, b):
    """Iki baslik ayni programi gosteriyor mu?

    Yayinci EIT'te basligi kisaltabilir; ayrica enigma2'nin kod tablosu cozumu
    bizimkinden farkli olabilir. Bu yuzden tam esitlik yerine onek eslesmesi de
    kabul edilir (en az 8 karakter ortusme sarti ile).
    """
    a = _normTitle(a)
    b = _normTitle(b)
    if not a or not b:
        return False
    if a == b:
        return True
    shorter, longer = (a, b) if len(a) <= len(b) else (b, a)
    return len(shorter) >= 8 and longer.startswith(shorter)


class EitItemReader(object):
    def __init__(self):
        self.fd = None
        self.sn = None
        self.sn_conn = None
        self.dev = None
        self.devices = []
        self.dev_index = 0
        self.section_count = 0
        self.disabled = False
        self.nav_conn = False
        self.transponder = None

        # (onid, tsid, service_id, event_id) -> (baslik, [(ad, deger), ...])
        # Bir servisi benzersiz kilan onid+tsid+sid uclusudur; service_id tek
        # basina agdan aga tekrar eder.
        self.by_key = {}
        # event_id -> [anahtar, ...]  (servis referansi bilinmediginde basliga
        # gore ayirmak icin)
        self.by_eid = {}
        # (table_id, service_id, section_number, version) -> ayristirildi
        self.seen = set()

        self.probe_timer = eTimer()
        self.probe_timer_conn = self.probe_timer.timeout.connect(self._onProbeTimeout)

    @property
    def event_count(self):
        """Onbellekteki (item tasiyan) event sayisi."""
        return len(self.by_key)

    # ------------------------------------------------------------------ demux

    def _openDemux(self, dev):
        fd = os.open(dev, os.O_RDWR | os.O_NONBLOCK)
        try:
            fcntl.ioctl(fd, DMX_SET_BUFFER_SIZE, 256 * 1024)
        except (IOError, OSError):
            pass
        flt = bytearray(16)
        msk = bytearray(16)
        mode = bytearray(16)
        flt[0] = EIT_TABLE_BASE
        msk[0] = EIT_TABLE_MASK
        params = struct.pack(SCT_FMT, EIT_PID,
                             bytes(flt) + bytes(msk) + bytes(mode),
                             0,                 # timeout 0 = sonsuz
                             DMX_CHECK_CRC)
        fcntl.ioctl(fd, DMX_SET_FILTER, params)
        fcntl.ioctl(fd, DMX_START)
        return fd

    def _deviceList(self):
        forced = (cfg.demux.value or "auto").strip()
        if forced and forced != "auto":
            return [forced]
        return sorted(glob.glob("/dev/dvb/adapter*/demux*"))

    def start(self):
        # Nav baglantisi enigma2 acilis sirasinda henuz kurulamamis olabilir;
        # her cagride yeniden denenir (zaten bagliysa ucuz).
        self._connectNav()
        if self.fd is not None:
            return True
        if self.disabled or not cfg.enabled.value:
            return False
        if not self.devices:
            self.devices = self._deviceList()
        if not self.devices:
            log("demux cihazi bulunamadi")
            self.disabled = True
            return False
        if self.dev_index >= len(self.devices):
            # Hicbir demux section vermedi; bosuna tekrar denemeyelim.
            log("kullanilabilir demux yok, modul devre disi")
            self.disabled = True
            return False

        dev = self.devices[self.dev_index]
        try:
            self.fd = self._openDemux(dev)
        except (IOError, OSError) as e:
            log("%s acilamadi: %s" % (dev, e))
            self.fd = None
            self.dev_index += 1
            return self.start()

        self.dev = dev
        self.section_count = 0
        self.sn = eSocketNotifier(self.fd, POLLIN)
        self.sn_conn = self.sn.activated.connect(self._onData)
        self.probe_timer.start(DEMUX_PROBE_MS, True)
        log("%s dinleniyor" % dev)
        return True

    def stop(self):
        self.probe_timer.stop()
        self.sn_conn = None
        self.sn = None
        if self.fd is not None:
            try:
                fcntl.ioctl(self.fd, DMX_STOP)
            except (IOError, OSError):
                pass
            try:
                os.close(self.fd)
            except OSError:
                pass
            self.fd = None
        self.dev = None

    def restart(self):
        """Ayar degisikliginden sonra sifirdan basla."""
        self.stop()
        self.devices = []
        self.dev_index = 0
        self.disabled = False
        self.clearCache()
        self.start()

    def clearCache(self):
        self.by_key.clear()
        self.by_eid.clear()
        self.seen.clear()

    def _onProbeTimeout(self):
        """Secilen demux hic section vermediyse sonrakini dene."""
        if self.section_count:
            return
        log("%s section vermedi, sonraki demux deneniyor" % self.dev)
        self.stop()
        self.dev_index += 1
        self.start()

    # -------------------------------------------------------- servis degisimi

    def _connectNav(self):
        if self.nav_conn:
            return
        try:
            import NavigationInstance
            nav = NavigationInstance.instance
        except (ImportError, AttributeError):
            return
        if nav is None:
            return
        nav.event.append(self._onNavEvent)
        self.nav_conn = True

    def _onNavEvent(self, what):
        if what != iPlayableService.evStart:
            return
        try:
            import NavigationInstance
            ref = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        except (ImportError, AttributeError):
            return
        if ref is not None:
            self.onServiceChanged(ref.toString())

    def onServiceChanged(self, refstr):
        """Transponder degistiyse onbellek gecersizdir."""
        tp = self._transponderOf(refstr)
        if tp is None or tp == self.transponder:
            return
        log("transponder degisti: %s -> %s" % (self.transponder, tp))
        self.transponder = tp
        self.clearCache()

    # ---------------------------------------------------------------- okuma

    def _onData(self, what=None):
        if self.fd is None:
            return
        for _ in range(32):
            try:
                data = os.read(self.fd, 65536)
            except (IOError, OSError):
                return          # EAGAIN: su an okunacak section yok
            if not data:
                return
            self.section_count += 1
            try:
                self._parse(data)
            except (IndexError, struct.error):
                pass

    def _parse(self, sec):
        if len(sec) < 14:
            return
        table_id = _b2i(sec[0:1])
        seclen = ((_b2i(sec[1:2]) & 0x0F) << 8) | _b2i(sec[2:3])
        service_id = struct.unpack(">H", sec[3:5])[0]
        version = (_b2i(sec[5:6]) >> 1) & 0x1F
        section_number = _b2i(sec[6:7])
        tsid = struct.unpack(">H", sec[8:10])[0]
        onid = struct.unpack(">H", sec[10:12])[0]

        seen_key = (table_id, service_id, section_number, version)
        if seen_key in self.seen:
            return
        self.seen.add(seen_key)

        end = min(3 + seclen - 4, len(sec))
        pos = 14
        while pos + 12 <= end:
            event_id = struct.unpack(">H", sec[pos:pos + 2])[0]
            dll = ((_b2i(sec[pos + 10:pos + 11]) & 0x0F) << 8) | _b2i(sec[pos + 11:pos + 12])
            dpos = pos + 12
            dend = min(dpos + dll, end)
            title = ""
            items = []
            while dpos + 2 <= dend:
                tag = _b2i(sec[dpos:dpos + 1])
                dlen = _b2i(sec[dpos + 1:dpos + 2])
                body = sec[dpos + 2:dpos + 2 + dlen]
                if tag == 0x4D and len(body) >= 4:
                    # short_event_descriptor -> baslik (event eslestirmesi icin)
                    if not title:
                        nl = _b2i(body[3:4])
                        title = dvb_text(body[4:4 + nl])
                elif tag == 0x4E and len(body) >= 6:
                    # extended_event_descriptor -> item listesi
                    # Not: bir event birden fazla parcali descriptor tasiyabilir,
                    # hepsinin item'lari birlestirilir.
                    loi = _b2i(body[4:5])
                    ip = 5
                    iend = 5 + loi
                    if iend <= len(body):
                        while ip + 1 <= iend:
                            idl = _b2i(body[ip:ip + 1])
                            ip += 1
                            idesc = dvb_text(body[ip:ip + idl])
                            ip += idl
                            if ip >= len(body):
                                break
                            il = _b2i(body[ip:ip + 1])
                            ip += 1
                            ival = dvb_text(body[ip:ip + il])
                            ip += il
                            if idesc or ival:
                                items.append((idesc, ival))
                dpos += 2 + dlen
            if items:
                self._store(onid, tsid, service_id, event_id, title, items)
            pos = dend

    def _store(self, onid, tsid, service_id, event_id, title, items):
        key = (onid, tsid, service_id, event_id)
        old = self.by_key.get(key)
        if old is not None:
            if old[1] != items or old[0] != title:
                self.by_key[key] = (title, items)
            return
        try:
            limit = int(cfg.max_events.value)
        except ValueError:
            limit = 40000
        if len(self.by_key) >= limit:
            return
        self.by_key[key] = (title, items)
        self.by_eid.setdefault(event_id, []).append(key)

    # --------------------------------------------------------------- sorgu

    @staticmethod
    def _transponderOf(refstr):
        """eServiceReference dizesinden (tsid, onid, namespace) uclusu."""
        parts = refstr.split(":")
        if len(parts) < 7:
            return None
        return (parts[4], parts[5], parts[6])

    @staticmethod
    def _dvbIdsOf(refstr):
        """eServiceReference -> (onid, tsid, service_id); cozulemezse None.

        Bicim: type:flags:service_type:sid:tsid:onid:namespace:...  (onaltilik)
        """
        parts = refstr.split(":")
        if len(parts) < 6:
            return None
        try:
            return (int(parts[5], 16), int(parts[4], 16), int(parts[3], 16))
        except ValueError:
            return None

    def lookupItems(self, event, refstr=None):
        """Event icin [(ad, deger), ...] listesi dondurur, eslesme yoksa [].

        Yanlis event'in bilgisini gostermektense hicbir sey gostermemek yeglenir:
        her sonuc ya (onid, tsid, sid, event_id) tam eslesmesiyle ya da baslik
        dogrulamasiyla teyit edilir. Teyitsiz tahmin yapilmaz -- EIT "other TS"
        tablolari baska transponderlerin EPG'sini de tasidigindan, ayni event_id
        baska bir yayincinin programina ait olabilir.
        """
        if self.fd is None and not self.disabled:
            self.start()
        try:
            event_id = event.getEventId()
        except AttributeError:
            return []
        if not event_id:
            return []

        try:
            name = event.getEventName()
        except AttributeError:
            name = None

        # 1) Servis referansi biliniyorsa tam eslesme ara. Referans her zaman
        # dogru olmayabilir (bazi converter'lar source'tan servis veremedigi icin
        # calan kanala duser), bu yuzden baslikla da teyit edilir.
        if refstr:
            ids = self._dvbIdsOf(refstr)
            if ids is not None:
                rec = self.by_key.get(ids + (event_id,))
                if rec is not None and (not name or not rec[0]
                                        or titlesMatch(rec[0], name)):
                    return rec[1]

        # 2) Referans yok ya da teyit edilemedi: yalnizca baslik eslesmesini kabul et
        keys = self.by_eid.get(event_id)
        if not keys:
            return []
        if not name:
            return []
        matches = []
        for key in keys:
            rec = self.by_key.get(key)
            if rec is not None and rec[0] and titlesMatch(rec[0], name):
                matches.append(rec[1])
        if not matches:
            return []
        # Birden fazla kanalda ayni baslik: ancak icerikleri de ayniysa guvenli
        first = matches[0]
        for other in matches[1:]:
            if other != first:
                return []
        return first

_reader = None


def getReader():
    global _reader
    if _reader is None:
        _reader = EitItemReader()
    return _reader


def formatItems(items):
    """[(ad, deger)] -> 'Actors: ...\\nDirectors: ...' (gizlenenler ayiklanir)."""
    if not items:
        return ""
    hidden = hiddenItemNames()
    lines = []
    for name, value in items:
        if not value:
            continue
        if hidden and name.strip().lower() in hidden:
            continue
        lines.append("%s: %s" % (name, value) if name else value)
    return "\n".join(lines)


def getItemsText(event, refstr=None):
    """Converter/Screen'lerden cagrilan kisayol. Hata durumunda '' doner."""
    if event is None or not cfg.enabled.value:
        return ""
    try:
        return formatItems(getReader().lookupItems(event, refstr))
    except Exception as e:
        log("lookup hatasi: %s" % e)
        return ""


def appendItems(description, event, refstr=None):
    """Extended description'in sonuna item satirlarini ekler."""
    text = getItemsText(event, refstr)
    if not text:
        return description
    if description:
        return "%s\n\n%s" % (description.rstrip(), text)
    return text
