# -*- coding: utf-8 -*-
#
# EitExtendedItems - skin converter'i
#
# Skin motoruna 'Components.Converter.EitEventItems' adiyla tanitilir
# (bkz. patcher._registerConverter), boylece sistem dizinine dosya
# yazmadan skin'lerde kullanilabilir:
#
#   <widget source="session.Event_Now" render="Label">
#     <convert type="EitEventItems">Items</convert>
#   </widget>
#
#   <convert type="EitEventItems">Full</convert>          extended + item'lar
#   <convert type="EitEventItems">Item,Actors</convert>   tek alanin degeri
#   <convert type="EitEventItems">Item,Production Year</convert>
#
from Components.Converter.Converter import Converter
from Components.Element import cached

from .eitreader import getReader, formatItems


class EitEventItems(Converter, object):
    ITEMS = 0
    FULL = 1
    SINGLE = 2

    def __init__(self, type):
        Converter.__init__(self, type)
        args = [a.strip() for a in (type or "").split(",")]
        kind = args.pop(0) if args else ""
        self.wanted = args[0] if args else ""
        if kind == "Full":
            self.type = self.FULL
        elif kind == "Item":
            self.type = self.SINGLE
        else:
            self.type = self.ITEMS

    def _refStr(self):
        ref = getattr(self.source, "service", None)
        if ref is not None:
            try:
                return ref.toString()
            except AttributeError:
                return None
        return None

    @cached
    def getText(self):
        event = self.source.event
        if event is None:
            return ""
        try:
            items = getReader().lookupItems(event, self._refStr())
        except Exception:
            return ""

        if self.type == self.SINGLE:
            wanted = self.wanted.lower()
            for name, value in items:
                if name.strip().lower() == wanted:
                    return value
            return ""

        text = formatItems(items)
        if self.type == self.FULL:
            ext = event.getExtendedDescription()
            if ext and text:
                return "%s\n\n%s" % (ext.rstrip(), text)
            return ext or text
        return text

    text = property(getText)
