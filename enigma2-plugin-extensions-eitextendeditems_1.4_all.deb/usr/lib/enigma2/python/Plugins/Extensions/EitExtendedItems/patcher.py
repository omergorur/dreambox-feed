# -*- coding: utf-8 -*-
#
# EitExtendedItems - calisma zamani genisletmeleri
#
# Sistem dosyalarina dokunmadan, calisan enigma2 icindeki ilgili siniflari
# sarmalayarak item satirlarini extended description'in sonuna ekler.
# Her yama geri alinabilir (unpatchAll).
#
import sys

from .settings import cfg
from .eitreader import appendItems, getItemsText, log

# uygulanan yamalar: (aciklama, geri_alma_fonksiyonu)
_patches = []
_status = {}


def patchStatus():
    """Ayar ekraninda gosterilecek durum sozlugu."""
    return dict(_status)


def _refStrOfSource(source):
    """Converter'in source'undan servis referans dizesini cikarir (tie-breaker)."""
    ref = getattr(source, "service", None)
    if ref is not None:
        try:
            return ref.toString()
        except AttributeError:
            try:
                return str(ref)
            except Exception:
                return None
    try:
        import NavigationInstance
        cur = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
        return cur and cur.toString() or None
    except (ImportError, AttributeError):
        return None


# --------------------------------------------------------------- EventName

def _patchEventName():
    """Stok EventName converter'i: ExtendedDescription / FullDescription."""
    from Components.Converter import EventName as mod

    cls = mod.EventName
    orig_prop = cls.__dict__.get("text")
    orig_getText = orig_prop.fget if isinstance(orig_prop, property) else cls.getText

    def getText(self):
        text = orig_getText(self)
        if not cfg.enabled.value or not cfg.in_converter.value:
            return text
        if self.type not in (self.EXTENDED_DESCRIPTION, self.FULL_DESCRIPTION):
            return text
        try:
            event = self.source.event
        except AttributeError:
            return text
        if event is None:
            return text
        return appendItems(text or "", event, _refStrOfSource(self.source))

    cls.getText = getText
    cls.text = property(getText)

    def undo():
        cls.getText = orig_getText
        cls.text = orig_prop if orig_prop is not None else property(orig_getText)

    _patches.append(("Components.Converter.EventName", undo))
    return True


# ------------------------------------------------------------ ExtEventName

def _patchExtEventName():
    """Bazi temalarin kullandigi ExtEventName converter'i (varsa)."""
    try:
        from Components.Converter import ExtEventName as mod
    except ImportError:
        return False

    cls = getattr(mod, "ExtEventName", None)
    if cls is None or not hasattr(cls, "getExtendedDescription"):
        return False

    orig = cls.getExtendedDescription

    def getExtendedDescription(self, event):
        ext = orig(self, event)
        if not cfg.enabled.value or not cfg.in_converter.value:
            return ext
        return appendItems(ext or "", event, _refStrOfSource(self.source))

    cls.getExtendedDescription = getExtendedDescription

    def undo():
        cls.getExtendedDescription = orig

    _patches.append(("Components.Converter.ExtEventName", undo))
    return True


# --------------------------------------------------------------- EventView

def _patchEventView():
    """EPG detay ekrani (EventView / EventViewBase)."""
    from Screens import EventView as mod

    cls = getattr(mod, "EventViewBase", None)
    if cls is None or not hasattr(cls, "setEvent"):
        return False

    orig = cls.setEvent

    def setEvent(self, event):
        orig(self, event)
        if event is None or not cfg.enabled.value or not cfg.in_eventview.value:
            return
        try:
            widget = self["epg_description"]
        except (KeyError, AttributeError):
            return
        getter = getattr(widget, "getText", None)
        if getter is None:
            return          # duz Label: mevcut metni okuyamayiz, dokunma
        try:
            refstr = self.currentService and self.currentService.ref.toString() or None
        except AttributeError:
            refstr = None
        items = getItemsText(event, refstr)
        if not items:
            return
        current = getter() or ""
        if items in current:
            return          # converter yolu zaten eklemis
        widget.setText("%s\n\n%s" % (current.rstrip(), items) if current else items)

    cls.setEvent = setEvent

    def undo():
        cls.setEvent = orig

    _patches.append(("Screens.EventView", undo))
    return True


# ------------------------------------------------- skin converter'i sunma

def _registerConverter():
    """
    Plugin icindeki converter'i skin motoruna 'Components.Converter.EitEventItems'
    adiyla tanitir; boylece sistem dizinine dosya yazmadan
    <convert type="EitEventItems">Items</convert> kullanilabilir.
    """
    from . import converter as mod
    import Components.Converter as pkg

    name = "Components.Converter.EitEventItems"
    if name in sys.modules:
        return True
    sys.modules[name] = mod
    setattr(pkg, "EitEventItems", mod)

    def undo():
        sys.modules.pop(name, None)
        try:
            delattr(pkg, "EitEventItems")
        except AttributeError:
            pass

    _patches.append(("skin converter EitEventItems", undo))
    return True


# --------------------------------------------------------------------- API

_TARGETS = (
    ("EventName", _patchEventName),
    ("ExtEventName", _patchExtEventName),
    ("EventView", _patchEventView),
    ("EitEventItems", _registerConverter),
)


def patchAll():
    if _patches:
        return _status
    for label, fn in _TARGETS:
        try:
            ok = fn()
            _status[label] = "tamam" if ok else "yok"
        except Exception as e:
            _status[label] = "hata: %s" % e
            log("%s yamalanamadi: %s" % (label, e))
    log("yamalar: %s" % _status)
    return _status


def unpatchAll():
    while _patches:
        label, undo = _patches.pop()
        try:
            undo()
        except Exception as e:
            log("%s geri alinamadi: %s" % (label, e))
    _status.clear()
