# EitExtendedItems

DreamOS enigma2 için EPG "alt bilgileri" eklentisi — **Actors, Directors,
Production Year, Country** gibi alanları EPG ekranlarında gösterir.

## Sorun

DreamOS'un C++ EIT ayrıştırıcısı (`lib/service/event.cpp`),
`extended_event_descriptor` (tag `0x4E`) içindeki **item listesini** kullanmaz;
yalnızca `text_char` alanını `eServiceEvent::getExtendedDescription()` ile verir.
Python API'sinde de item'lara erişecek bir metot yoktur (bkz. `enigma.py`,
`class eServiceEvent`).

OpenATV/Pure² tabanlı imajlarda aynı yerde şu döngü vardır:

```cpp
const ExtendedEventList *itemlist = eed->getItems();
for (ExtendedEventConstIterator it = itemlist->begin(); it != itemlist->end(); ++it) {
    m_extended_description_items += '\n';
    m_extended_description_items += convertDVBUTF8((*it)->getItemDescription(), table, tsidonid);
    m_extended_description_items += ": ";
    m_extended_description_items += convertDVBUTF8((*it)->getItem(), table, tsidonid);
}
```

Bu yüzden aynı yayın Pure²'de "Actors: …" satırlarını gösterirken DreamOS'ta
göstermez. Bilgi cihaza **ulaşır**, enigma2 onu atar.

## Çözüm

Eklenti EIT'i (PID `0x12`, tablo `0x40`–`0x5F`) kendi section filtresiyle okur,
item'ları önbelleğe alır ve çalışma zamanında EPG ekranlarına ekler.
**Sistem dosyalarına dokunmaz** — ilgili sınıflar bellekte sarmalanır ve
kaldırıldığında geri alınır.

Okuma `eSocketNotifier` ile enigma2'nin ana döngüsüne bağlanır; ayrı thread
veya yoklama (polling) yoktur.

## Kurulum

```
dpkg -i enigma2-plugin-extensions-eitextendeditems_1.2_all.deb
killall -9 enigma2      # ya da menüden enigma2 yeniden başlat
```

Kaldırma:

```
dpkg -r enigma2-plugin-extensions-eitextendeditems
```

## Ayarlar

**Menü → Eklentiler → EPG Ek Bilgileri (EIT items)**

| Ayar | Açıklama |
|------|----------|
| Eklenti etkin | Tümünü açar/kapatır |
| EPG detay ekranında göster | `EventView` (uzun EPG penceresi) |
| Skin converter'larında göster | Infobar ve EPG listelerindeki açıklama alanları |
| Teknik alanları gizle | `MasterProductionID`, `CRID` gibi alanları eler |
| Gizlenecek alanlar | Virgülle ayrılmış liste |
| Demux | `auto` ya da `/dev/dvb/adapter0/demux0` |
| Azami event sayısı | Önbellek üst sınırı |
| Günlüğe ayrıntı yaz | Sorun giderme çıktısı |

Ekranın alt yarısı canlı durum gösterir: hangi demux dinleniyor, kaç section
okundu, önbellekte kaç event var, hangi yamalar uygulandı ve o an izlenen
programın item'ları.

## Skin'de kullanım (isteğe bağlı)

Eklenti, skin motoruna `EitEventItems` adıyla bir converter tanıtır — bunun için
sistem dizinine dosya yazılmaz:

```xml
<!-- yalnızca item satırları -->
<widget source="session.Event_Now" render="Label" position="20,20" size="800,200">
    <convert type="EitEventItems">Items</convert>
</widget>

<!-- extended description + item satırları -->
<convert type="EitEventItems">Full</convert>

<!-- tek bir alanın değeri -->
<convert type="EitEventItems">Item,Actors</convert>
<convert type="EitEventItems">Item,Production Year</convert>
```

## Eşleştirme güvencesi

Bir event'in item'ları ancak şu iki yoldan biriyle **teyit edilirse** gösterilir:

1. `(original_network_id, transport_stream_id, service_id, event_id)` tam
   eşleşmesi — üstüne başlık teyidi;
2. servis referansı bilinmiyorsa, yalnızca başlığı eşleşen tek bir kayıt varsa.

Teyitsiz tahmin yapılmaz. EIT "other TS" tabloları başka transponderlerin
EPG'sini de taşıdığından, `event_id` tek başına ayırt edici değildir — aynı
`event_id` başka bir yayıncının programına ait olabilir. Eşleşme belirsizse
yanlış bilgi göstermek yerine hiçbir şey gösterilmez.

## Kapsam ve sınırlar

- Yalnızca **o an takılı transponderin** EIT tabloları okunur. Başka
  transponderdeki kanalların item'ları, o transpondere geçilene kadar bilinmez.
  (Aynı transponderdeki tüm kanalların tüm EPG'si kapsanır — schedule tabloları
  da dinlenir.)
- Kanal değiştirip transponder değiştiğinde önbellek temizlenir ve yeniden dolar;
  birkaç saniye sürer.
- Yayıncı item göndermiyorsa gösterilecek bir şey yoktur. Teşhis için
  `tools/eit_items_dump.py` betiği kutuda çalıştırılabilir:
  ```
  python /usr/lib/enigma2/python/Plugins/Extensions/EitExtendedItems/tools/eit_items_dump.py
  ```

## Yamalanan yerler

| Hedef | Etki |
|-------|------|
| `Components.Converter.EventName` | `ExtendedDescription` / `FullDescription` tipleri |
| `Components.Converter.ExtEventName` | Varsa (bazı temalar kullanır) |
| `Screens.EventView` | EPG detay ekranı |
| `EitEventItems` | Yeni skin converter'ı |

Bir tema bunların dışında kendi converter'ını kullanıyorsa, o alanda item'lar
görünmez; skin'e yukarıdaki `EitEventItems` converter'ı eklenerek çözülür.
