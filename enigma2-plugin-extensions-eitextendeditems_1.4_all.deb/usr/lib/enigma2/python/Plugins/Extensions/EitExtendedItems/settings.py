# -*- coding: utf-8 -*-
#
# EitExtendedItems - ayarlar
#
from Components.config import config, ConfigSubsection, ConfigYesNo, \
    ConfigSelection, ConfigText

config.plugins.eitextendeditems = ConfigSubsection()
cfg = config.plugins.eitextendeditems

# Eklenti tumuyle etkin mi
cfg.enabled = ConfigYesNo(default=True)

# Nerede gosterilsin
cfg.in_eventview = ConfigYesNo(default=True)    # EPG detay ekrani (EventView)
cfg.in_converter = ConfigYesNo(default=True)    # skin converter'lari (infobar, EPG listeleri)

# Teknik/ise yaramaz alanlari gizle (MasterProductionID, CRID vb.)
cfg.hide_technical = ConfigYesNo(default=True)

# Gizlenecek item adlari (virgulle ayrilmis, kucuk/buyuk harf onemsiz)
cfg.hidden_items = ConfigText(
    default="MasterProductionID,CRID,SeriesCRID,ProgrammeCRID,RecommendationCRID",
    fixed_size=False)

# Demux secimi: auto = tum /dev/dvb/adapter*/demux* denenir
cfg.demux = ConfigText(default="auto", fixed_size=False)

# Onbellege alinacak azami event sayisi
cfg.max_events = ConfigSelection(
    default="40000",
    choices=[("10000", "10000"), ("20000", "20000"),
             ("40000", "40000"), ("80000", "80000")])

# Gunluge ayrinti yaz
cfg.debug = ConfigYesNo(default=False)


def hiddenItemNames():
    """Gizlenecek item adlarini kucuk harfli kume olarak dondurur."""
    if not cfg.hide_technical.value:
        return frozenset()
    raw = cfg.hidden_items.value or ""
    return frozenset(x.strip().lower() for x in raw.split(",") if x.strip())
