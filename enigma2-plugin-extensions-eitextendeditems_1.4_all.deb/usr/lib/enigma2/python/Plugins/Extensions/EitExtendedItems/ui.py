# -*- coding: utf-8 -*-
#
# EitExtendedItems - ayar ve durum ekrani
#
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.config import getConfigListEntry, configfile

from enigma import getDesktop

from .settings import cfg
from .eitreader import getReader, formatItems
from . import patcher

# Ornek listede gosterilecek azami item satiri
MAX_SAMPLE_LINES = 8


# Not: config widget'ina font/itemHeight verilmez -- DreamOS'ta eListbox'ta
# setFont yoktur (skin.py applySingleAttribute -> AttributeError -> yesil ekran).
# Config listesinin fontu ve satir yuksekligi temanin <listboxcontent> tanimindan gelir.
def _skin():
    try:
        width = getDesktop(0).size().width()
    except Exception:
        width = 1280
    if width >= 1920:
        return """
        <screen name="EitItemsSetup" position="center,center" size="1400,900" title="EPG Ek Bilgileri (EIT items)">
            <widget name="config" position="30,20" size="1340,400" scrollbarMode="showOnDemand" />
            <widget name="status" position="30,440" size="1340,370" font="Regular;26" />
            <widget source="key_red" render="Label" position="30,830" size="330,45" font="Regular;28" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="370,830" size="330,45" font="Regular;28" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="710,830" size="330,45" font="Regular;28" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1040,830" size="330,45" font="Regular;28" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="EitItemsSetup" position="center,center" size="900,600" title="EPG Ek Bilgileri (EIT items)">
        <widget name="config" position="20,15" size="860,235" scrollbarMode="showOnDemand" />
        <widget name="status" position="20,260" size="860,285" font="Regular;20" />
        <widget source="key_red" render="Label" position="20,555" size="210,30" font="Regular;20" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="235,555" size="210,30" font="Regular;20" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="450,555" size="210,30" font="Regular;20" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="665,555" size="210,30" font="Regular;20" foregroundColor="blue" halign="left" />
    </screen>"""


class EitItemsSetup(Screen, ConfigListScreen):
    def __init__(self, session):
        self.skin = _skin()
        Screen.__init__(self, session)
        self.setTitle("EPG Ek Bilgileri (EIT items)")

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText("Yenile")
        self["key_blue"] = StaticText("Onbellegi temizle")
        self["status"] = Label("")

        entries = [
            getConfigListEntry("Eklenti etkin", cfg.enabled),
            getConfigListEntry("EPG detay ekraninda goster", cfg.in_eventview),
            getConfigListEntry("Skin converter'larinda goster", cfg.in_converter),
            getConfigListEntry("Teknik alanlari gizle", cfg.hide_technical),
            getConfigListEntry("Gizlenecek alanlar", cfg.hidden_items),
            getConfigListEntry("Demux (auto veya /dev/dvb/adapterX/demuxY)", cfg.demux),
            getConfigListEntry("Azami event sayisi", cfg.max_events),
            getConfigListEntry("Gunluge ayrinti yaz", cfg.debug),
        ]
        # ConfigListScreen kendi "SetupActions" haritasini kurar (ok/left/right/
        # metin girisi). Asagidaki harita yalnizca cancel/save/renk tuslarini alir.
        ConfigListScreen.__init__(self, entries, session=session)

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "cancel": self.keyCancel,
                "save": self.keySave,
                "red": self.keyCancel,
                "green": self.keySave,
                "yellow": self.updateStatus,
                "blue": self.clearCache,
            }, -1)

        self.onLayoutFinish.append(self.updateStatus)

    # ------------------------------------------------------------------ durum

    def _currentEventItems(self):
        """Su an izlenen kanalin programindaki item'lari ornek olarak gosterir."""
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            event = info and info.getEvent(0)
        except Exception:
            return None, ""
        if event is None:
            return None, ""
        refstr = None
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            refstr = ref and ref.toString() or None
        except Exception:
            pass
        try:
            return event, formatItems(getReader().lookupItems(event, refstr))
        except Exception as e:
            return event, "hata: %s" % e

    def updateStatus(self):
        reader = getReader()
        lines = []

        if reader.disabled:
            lines.append("Okuyucu    : DEVRE DISI (kullanilabilir demux bulunamadi)")
        elif reader.fd is None:
            lines.append("Okuyucu    : baslatilmadi")
        else:
            lines.append("Okuyucu    : %s" % reader.dev)
        lines.append("Section    : %d okundu" % reader.section_count)
        lines.append("Onbellek   : %d event (item tasiyan)" % reader.event_count)
        lines.append("Transponder: %s" % (reader.transponder and ":".join(reader.transponder) or "-"))

        status = patcher.patchStatus()
        lines.append("Yamalar    : %s" % (", ".join(
            "%s=%s" % (k, v) for k, v in sorted(status.items())) if status else "uygulanmadi"))

        event, items = self._currentEventItems()
        lines.append("")
        if event is None:
            lines.append("Su anda bir kanal izlenmiyor.")
        else:
            lines.append("Su anki program: %s" % event.getEventName())
            if items:
                sample = items.split("\n")
                if len(sample) > MAX_SAMPLE_LINES:
                    sample = sample[:MAX_SAMPLE_LINES] + ["..."]
                lines.extend(sample)
            else:
                lines.append("(item bulunamadi -- onbellek dolana kadar birkac saniye")
                lines.append(" bekleyin; ya da bu kanal item gondermiyordur)")

        self["status"].setText("\n".join(lines))

    def clearCache(self):
        getReader().clearCache()
        self.updateStatus()

    # ------------------------------------------------------------------ kayit

    def keySave(self):
        self.saveAll()
        configfile.save()
        reader = getReader()
        if cfg.enabled.value:
            reader.restart()
        else:
            reader.stop()
        self.close()


def openSetup(session, **kwargs):
    session.open(EitItemsSetup)
