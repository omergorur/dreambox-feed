# -*- coding: utf-8 -*-
"""
SubtitleStyle -- ayarlar (config.plugins.subtitlestyle) ve fontconfig secimi.

Iki tur altyazi, iki ayri yol (olculdu 2026-10-12, GDrive gelistirirken):
  * Harici .srt: oynatici (GDrive, ileride StalkerTV) cizici.SrtCizici ile kendisi cizer -> font, boyut,
    stil (kontur/golge/kutu), renk, konum, zamanlama ANINDA uygulanir.
  * Dosya icindeki (MKV) metin altyazilari: GStreamer'in pango ogesi (textrender) cizer, fontu FONTCONFIG'ten
    ister (aile vermez: varsayilan 'serif'). Kutuda serif/sans fontu yok -> Arapca bir fontun Latin harfleri
    ('Arial' gorunumu). Burada font ve boyut (fontconfig matrisi) degistirilebilir; renk/kontur GStreamer'da.
    fontconfig yalnizca acilista okunur: degisiklik enigma2 yeniden baslayinca gecerli.
"""
import os

from Components.config import config, ConfigSubsection, ConfigSelection

try:
    _
except NameError:
    def _(txt):
        return txt

config.plugins.subtitlestyle = ConfigSubsection()
cfg = config.plugins.subtitlestyle

# --- harici altyazi (.srt) -----------------------------------------------------------------------
cfg.font = ConfigSelection(default="inter", choices=[("inter", "Inter (Netflix'e en yakın)"), ("roboto", "Roboto"), ("opensans", "Open Sans"), ("tema", _("Tema fontu"))])
cfg.boyut = ConfigSelection(default="52", choices=[("40", _("Küçük")), ("46", _("Orta-küçük")), ("52", _("Orta (Netflix)")), ("58", _("Büyük")), ("66", _("Çok büyük")), ("76", _("Dev"))])
cfg.stil = ConfigSelection(default="kontur", choices=[("kontur", _("Kontur (Netflix)")), ("golge", _("Gölge")), ("kutu", _("Yarı saydam kutu")), ("duz", _("Düz"))])
cfg.renk = ConfigSelection(default="ffffff", choices=[("ffffff", _("Beyaz")), ("ffe14d", _("Sarı")), ("d8d8d8", _("Açık gri")), ("aee8ff", _("Açık mavi"))])
cfg.konum = ConfigSelection(default="80", choices=[("30", _("En alt")), ("80", _("Alt (Netflix)")), ("140", _("Biraz yukarı")), ("220", _("Yukarı"))])
cfg.gecikme = ConfigSelection(default="0", choices=[(str(x), str(("%+.2f s" % (x / 1000.0)).replace(".", ",")) if x else "0 s") for x in range(-3000, 3001, 250)])

# --- dosya icindeki (MKV) metin altyazilari: fontconfig --------------------------------------------
cfg.gomulu_font = ConfigSelection(default="inter", choices=[("inter", "Inter (Netflix'e en yakın)"), ("roboto", "Roboto"), ("opensans", "Open Sans"), ("sistem", _("Değiştirme (sistem varsayılanı)"))])
cfg.gomulu_olcek = ConfigSelection(default="100", choices=[(str(x), "%%%d" % x) for x in range(70, 201, 10)])

PLUGIN_DIZINI = os.path.dirname(os.path.abspath(__file__))
FONT_DIZINI = os.path.join(PLUGIN_DIZINI, "fonts")
# enigma2 adi, dosya, fontconfig ailesi (fontTools alt kumesi ID16'yi atti: aile 'Inter Medium', 'Inter' degil)
FONTLAR = {
    "inter": ("SubStyleInter", "Inter-Medium.ttf", "Inter Medium"),
    "roboto": ("SubStyleRoboto", "Roboto-Medium.ttf", "Roboto Medium"),
    "opensans": ("SubStyleOpenSans", "OpenSans-SemiBold.ttf", "Open Sans SemiBold"),
}
FONTCONFIG_SECIM = "/etc/enigma2/subtitlestyle-fontconfig.conf"   # paketin /etc/fonts/conf.d/60-subtitlestyle.conf'u ice alir


def gunluk(m):
    if not isinstance(m, str):
        try:
            m = m.encode("utf-8") if str is bytes else m.decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            m = repr(m)
    print("[SubtitleStyle] " + m)


def fontconfig_icerigi():
    """Secime gore fontconfig XML'i; 'sistem' -> None (dosya silinir, hicbir sey degismez)."""
    f = FONTLAR.get(cfg.gomulu_font.value)
    if not f:
        return None
    aile = f[2]
    olcek = int(cfg.gomulu_olcek.value) / 100.0
    matris = ""
    if abs(olcek - 1.0) > 0.001:
        matris = ('  <match target="font"><test name="family"><string>%s</string></test>\n'
                  '    <edit name="matrix" mode="assign"><times><name>matrix</name><matrix>'
                  '<double>%.2f</double><double>0</double><double>0</double><double>%.2f</double></matrix></times></edit></match>\n'
                  % (aile, olcek, olcek))
    return ('<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "fonts.dtd">\n'
            '<!-- SubtitleStyle: dosya icindeki (MKV) metin altyazilari; eklenti yazar, elle degistirmeyin -->\n'
            '<fontconfig>\n'
            '  <alias binding="strong"><family>serif</family><prefer><family>%s</family></prefer></alias>\n'
            '  <alias binding="strong"><family>sans-serif</family><prefer><family>%s</family></prefer></alias>\n'
            '%s</fontconfig>\n' % (aile, aile, matris))


def fontconfig_yaz():
    """Secim dosyasini gunceller; icerik degistiyse True (enigma2 yeniden baslatilmali)."""
    yeni = fontconfig_icerigi()
    try:
        eski = open(FONTCONFIG_SECIM).read() if os.path.isfile(FONTCONFIG_SECIM) else None
    except (IOError, OSError):
        eski = None
    if yeni == eski:
        return False
    try:
        if yeni is None:
            os.remove(FONTCONFIG_SECIM)
        else:
            with open(FONTCONFIG_SECIM + ".tmp", "w") as f:
                f.write(yeni)
            os.rename(FONTCONFIG_SECIM + ".tmp", FONTCONFIG_SECIM)
        gunluk("fontconfig secimi yazildi (%s, %%%s); enigma2 yeniden baslayinca gecerli"
               % (cfg.gomulu_font.value, cfg.gomulu_olcek.value))
        return True
    except (IOError, OSError) as e:
        gunluk("fontconfig secimi yazilamadi: %s" % e)
        return False
