# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_subtitlestyle.py); depoda yok.
SURUM = "1.2"
COMMIT = "8d4c623"
