# -*- coding: utf-8 -*-
"""
Kutuda calistirilan tesis betigi: enigma2'nin 8001 stream sunucusu
proxy'nin bekledigi gibi davraniyor mu?

    python check_upstream.py [servis_referansi]

Referans verilmezse /etc/enigma2/settings icindeki config.tv.lastservice
kullanilir. Betik 8001'e baglanir, HTTP basligini ve gelen TS'in senkron
baytini (0x47) dogrular. "Veri gercekten geliyor mu?" sorusunu eklentiden
bagimsiz yanitlar; ZapFollow calismasa da kullanilabilir.
"""
from __future__ import print_function

import socket
import sys

HOST = "127.0.0.1"
PORT = 8001
SETTINGS = "/etc/enigma2/settings"
WANT_BYTES = 188 * 200          # ~37 KB, birkac yuz milisaniye
TIMEOUT = 8.0


def lastServiceFromSettings(path=SETTINGS):
    try:
        with open(path) as handle:
            for line in handle:
                if line.startswith("config.tv.lastservice="):
                    return line.split("=", 1)[1].strip()
    except IOError as error:
        print("settings okunamadi: %s" % error)
    return None


def normalize(ref):
    parts = ref.split(":")
    if len(parts) < 10:
        return None
    return ":".join(parts[:10]) + ":"


def main():
    ref = sys.argv[1] if len(sys.argv) > 1 else lastServiceFromSettings()
    if not ref:
        print("servis referansi bulunamadi")
        return 2
    path = normalize(ref)
    if path is None:
        print("referans bicimi taninmadi: %s" % ref)
        return 2
    print("servis   : %s" % path)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(TIMEOUT)
    try:
        sock.connect((HOST, PORT))
    except socket.error as error:
        print("8001'e baglanilamadi: %s" % error)
        print("-> enigma2 calismiyor olabilir ya da stream sunucusu kapali")
        return 1
    sock.sendall(("GET /%s HTTP/1.0\r\nHost: %s\r\n\r\n"
                  % (path, HOST)).encode("ascii"))

    buffer = b""
    try:
        while b"\r\n\r\n" not in buffer and len(buffer) < 4096:
            chunk = sock.recv(4096)
            if not chunk:
                break
            buffer += chunk
    except socket.timeout:
        print("baslik gelmedi (zaman asimi)")
        return 1

    head, _, body = buffer.partition(b"\r\n\r\n")
    first = head.split(b"\r\n", 1)[0].decode("ascii", "replace")
    print("yanit    : %s" % first)
    if b" 200" not in head[:16]:
        print("-> 8001 yayin vermedi")
        return 1

    try:
        while len(body) < WANT_BYTES:
            chunk = sock.recv(65536)
            if not chunk:
                break
            body += chunk
    except socket.timeout:
        pass
    finally:
        sock.close()

    print("gelen    : %d bayt" % len(body))
    if not body:
        print("-> baglanti kuruldu ama veri akmadi (tuner mesgul olabilir)")
        return 1

    start = body.find(b"\x47")
    aligned = body[start:]
    good = sum(1 for i in range(0, len(aligned) - 188, 188)
               if aligned[i:i + 1] == b"\x47")
    total = max(1, len(aligned) // 188 - 1)
    print("senkron  : %d/%d paket 0x47 ile basliyor" % (good, total))
    if good * 10 < total * 9:
        print("-> TS akisi bozuk gorunuyor")
        return 1
    print("sonuc    : 8001 saglikli, proxy bu kaynagi kullanabilir")
    return 0


if __name__ == "__main__":
    sys.exit(main())
