# -*- coding: utf-8 -*-
#
# ZapFollow - çalışma zamanı yaması
#
# Sistem dosyasına dokunmuyoruz; Navigation.playService'i sarmalıyoruz.
# Tüm zap yolları (kanal listesi, +/- tuşları, EPG, timer, uzaktan kumanda
# eklentileri) sonunda buradan geçer -- InfoBar'ı yamalamaktan çok daha
# güvenilir.
#
# Yamanın tek işi sıralamayı düzeltmek:
#   önce upstream soketini kapat (tuner serbest kalsın), sonra gerçek zap.
#
from __future__ import print_function

from .server import server, log

_patches = []


def isApplied():
    return bool(_patches)


def apply():
    if _patches:
        return True
    try:
        import Navigation as navigationModule
    except ImportError as e:
        log("Navigation modülü bulunamadı, yama uygulanmadı: %s" % e)
        return False

    cls = getattr(navigationModule, "Navigation", None)
    if cls is None:
        log("Navigation sınıfı bulunamadı, yama uygulanmadı")
        return False

    orig = cls.__dict__.get("playService")
    if orig is None:
        orig = getattr(cls, "playService", None)
    if orig is None:
        log("playService bulunamadı, yama uygulanmadı")
        return False

    def playService(navself, ref, *args, **kwargs):
        try:
            if server.wantsDeferredZap(ref):
                def run():
                    orig(navself, ref, *args, **kwargs)
                server.beginZap(run)
                return 0
        except Exception as e:
            log("zap sarmalayıcı hatası, doğrudan devam: %s" % e)
        return orig(navself, ref, *args, **kwargs)

    playService.__name__ = "playService"
    cls.playService = playService

    def revert():
        if cls.__dict__.get("playService") is playService:
            cls.playService = orig
        else:
            log("playService başkası tarafından değiştirilmiş, geri alınmadı")

    _patches.append(("Navigation.playService", revert))
    log("yama uygulandı: Navigation.playService")
    return True


def revert():
    while _patches:
        name, undo = _patches.pop()
        try:
            undo()
            log("yama geri alındı: %s" % name)
        except Exception as e:
            log("yama geri alınamadı (%s): %s" % (name, e))
