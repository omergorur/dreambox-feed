# -*- coding: utf-8 -*-
#
# ZapFollow - çekirdek: zap'ı takip eden TS proxy'si
#
# enigma2'nin kendi stream sunucusu (port 8001, "stream_enigma2") yalnızca
# URL'de yazan servis referansını yayınlar. Bu yüzden
#
#   * ağdan izleyen kişi sabit bir kanala kilitlenir,
#   * o kanal bir tuner tuttuğu için kutudan başka transpondere zap yapmak
#     "boşta tuner yok" ile geri çevrilir.
#
# Bu modül araya girer: istemci BİZE bağlanır (sabit /live ucu), biz de
# 127.0.0.1:8001'den o an çalan kanalı çekip aktarırız. Kutuda zap yapılınca
#
#   1. patcher gerçek playService'i çağırmadan önce bize haber verir,
#   2. upstream soketimizi kapatırız -> enigma2 streaming servisini bitirir,
#      tuner serbest kalır,
#   3. gerçek zap yapılır,
#   4. evStart gelince yeni kanala yeniden bağlanırız.
#
# İstemcinin TCP bağlantısı bu sırada hiç kapanmaz; akış yalnızca ~1 sn durur.
#
from __future__ import print_function

import errno
import socket
import time

from enigma import eSocketNotifier, eTimer, iPlayableService

import NavigationInstance

from .settings import cfg

UPSTREAM_HOST = "127.0.0.1"
UPSTREAM_PORT = 8001          # enigma2'nin kendi stream sunucusu

CHUNK = 64 * 1024
MAX_REQUEST = 8 * 1024        # HTTP istek başlığı üst sınırı
MAX_CLIENTS = 8

# Yavaş istemci akış denetimi: kuyruk HIGH_WATER'ı aşarsa upstream'i okumayı
# bırakırız (TCP geri basıncı), RESUME_WATER'ın altına inince devam ederiz.
# HARD_LIMIT'i de aşan istemci düşürülür -- yoksa bellek şişer.
HIGH_WATER = 2 * 1024 * 1024
RESUME_WATER = 512 * 1024
HARD_LIMIT = 8 * 1024 * 1024

# Zap'tan sonra gelen ilk evStart'i "bu benim zap'imin sonucu" saydigimiz
# sure. Zap reddedilirse evStart hic gelmez ve pencere bos kapanir.
ZAP_WINDOW_SECONDS = 3.0

# "auto" kipinde bu imzalari tasiyan istemciler zap'ta birakilir: hepsi
# libavformat tabanli ve giris PID'lerini basta sabitler.
RECONNECTING_AGENTS = ("lavf", "ffmpeg", "ffprobe", "libav")

_AGAIN = (errno.EAGAIN, errno.EWOULDBLOCK, errno.EINTR)

_READ = eSocketNotifier.Read
_WRITE = eSocketNotifier.Write
_BROKEN = eSocketNotifier.Error | eSocketNotifier.Hungup


def log(msg):
    print("[ZapFollow] %s" % msg)


def debug(msg):
    if cfg.debug.value:
        log(msg)


def streamPathForRef(ref):
    """Servis referansından 8001'in beklediği yolu üretir.

    DVB dışı servisler (dosya/kayıt oynatma, IPTV 4097...) için None döner:
    onlar tuner tutmaz, proxy'nin de işi yoktur."""
    if ref is None:
        return None
    try:
        if not ref.valid():
            return None
        if ref.getPath():                      # dosya / kayıt / IPTV
            return None
        text = ref.toString()
    except Exception as e:
        debug("referans okunamadı: %s" % e)
        return None
    parts = text.split(":")
    if len(parts) < 10 or parts[0] != "1":
        return None
    return ":".join(parts[:10]) + ":"


def currentStreamPath():
    """O an çalan DVB servisinin yayın yolu.

    Sıra önemli: `evStart` bize ulaştığında Navigation henüz
    `currentlyPlayingServiceReference`'ı yazmamıştır -- kaynaktaki uyarı
    açık: "It HAS to be set after evStart" (Navigation.py) -- üstelik
    ondan önce gelen `evEnd` onu None'a çekmiştir. O anda doğru cevabı
    yalnızca pnav'ın canlı referansı verir; bu yüzden önce ona bakarız."""
    nav = NavigationInstance.instance
    if nav is None:
        return None
    for getter in ("getCurrentServiceReference",
                   "getCurrentlyPlayingServiceReference"):
        fn = getattr(nav, getter, None)
        if fn is None:
            continue
        try:
            path = streamPathForRef(fn())
        except Exception as e:
            debug("%s okunamadı: %s" % (getter, e))
            continue
        if path:
            return path
    return None


def _closeSocket(sock):
    try:
        sock.close()
    except Exception:
        pass


# --------------------------------------------------------------- istemci

class _Client(object):
    """Bize bağlanan izleyici (VLC vb.).

    İki durumu var: önce HTTP isteğini okuruz, sonra sonsuza dek TS yazarız.
    Yazma her zaman non-blocking; yazılamayan veri kuyruğa alınır ve soket
    yazılabilir olunca (Write bildirimi) boşaltılır. Ana döngü hiçbir yerde
    bloklanmaz."""

    def __init__(self, server, sock, addr):
        self.server = server
        self.sock = sock
        self.addr = addr
        self.sock.setblocking(False)
        self.inbuf = b""
        self.outbuf = bytearray()
        self.streaming = False
        self.path = None
        self.userAgent = ""
        self.bytesSent = 0
        self.since = time.time()
        self._requested = _READ
        self.notifier = eSocketNotifier(sock.fileno(), self._requested)
        self.conn = self.notifier.activated.connect(self._activated)

    # ------------------------------------------------------------ olaylar

    def _activated(self, what):
        try:
            if what & _WRITE:
                self._flush()
            if self.sock is not None and what & _READ:
                self._read()
            if self.sock is not None and what & _BROKEN:
                self.close("bağlantı koptu")
        except Exception as e:
            log("istemci hatası (%s): %s" % (self.name, e))
            self.close("hata")

    def _read(self):
        try:
            data = self.sock.recv(4096)
        except socket.error as e:
            if e.args and e.args[0] in _AGAIN:
                return
            self.close("okuma hatası: %s" % e)
            return
        if not data:
            # İstemci bağlantıyı kapattı. Yayın sırasında karşı taraf bize
            # hiçbir şey göndermez, dolayısıyla EOF = ayrıldı demektir.
            self.close("istemci ayrıldı")
            return
        if self.streaming:
            return                              # yayın sırasında geleni yut
        self.inbuf += data
        if len(self.inbuf) > MAX_REQUEST:
            self._respondSimple("413 Request Entity Too Large",
                                "istek çok uzun\n")
            return
        if b"\r\n\r\n" in self.inbuf or b"\n\n" in self.inbuf:
            self._handleRequest()

    # -------------------------------------------------------------- istek

    def _handleRequest(self):
        try:
            line = self.inbuf.split(b"\n", 1)[0].decode("ascii", "replace")
        except Exception:
            line = ""
        for header in self.inbuf.splitlines()[1:]:
            if header[:11].lower() == b"user-agent:":
                self.userAgent = header.split(b":", 1)[1].strip().decode(
                    "ascii", "replace")
                break
        parts = line.split()
        method = parts[0].upper() if parts else ""
        path = parts[1] if len(parts) > 1 else "/"
        path = path.split("?", 1)[0].rstrip("/") or "/"
        self.path = path
        debug("istek: %s %s (%s)" % (method, path, self.name))

        if method not in ("GET", "HEAD"):
            self._respondSimple("405 Method Not Allowed", "yalnızca GET\n")
            return
        if path in ("/live", "/stream", "/"):
            if method == "HEAD":
                self._respondSimple("200 OK", "", ctype="video/mpeg")
                return
            self._startStreaming()
            return
        if path == "/status":
            self._respondSimple("200 OK", self.server.statusText())
            return
        self._respondSimple("404 Not Found", "bilinmeyen adres: %s\n" % path)

    def _respondSimple(self, status, body, ctype="text/plain; charset=utf-8"):
        if not isinstance(body, bytes):
            body = body.encode("utf-8")
        head = ("HTTP/1.0 %s\r\n"
                "Server: ZapFollow\r\n"
                "Content-Type: %s\r\n"
                "Content-Length: %d\r\n"
                "Connection: close\r\n\r\n" % (status, ctype, len(body)))
        self.outbuf.extend(head.encode("ascii") + body)
        self.close("yanıt verildi", flush=True)

    def _startStreaming(self):
        head = ("HTTP/1.0 200 OK\r\n"
                "Server: ZapFollow\r\n"
                "Content-Type: video/mpeg\r\n"
                "Cache-Control: no-cache\r\n"
                "Pragma: no-cache\r\n"
                "Connection: close\r\n\r\n")
        self.outbuf.extend(head.encode("ascii"))
        self.streaming = True
        self.inbuf = b""
        self._flush()
        log("izleyici bağlandı: %s (%s)"
            % (self.name, self.userAgent or "istemci belirtilmedi"))
        self.server.onClientReady(self)

    # -------------------------------------------------------------- yazma

    def feed(self, data):
        self.outbuf.extend(data)
        self._flush()
        if self.sock is not None and len(self.outbuf) > HARD_LIMIT:
            self.close("istemci akışa yetişemiyor")

    def _flush(self):
        while self.outbuf and self.sock is not None:
            block = bytes(self.outbuf[:CHUNK])
            try:
                sent = self.sock.send(block)
            except socket.error as e:
                if e.args and e.args[0] in _AGAIN:
                    break
                self.close("yazma hatası: %s" % e)
                return
            if sent <= 0:
                break
            del self.outbuf[:sent]
            self.bytesSent += sent
        self._updateRequested()
        if not self.outbuf:
            self.server.maybeResume()

    def _updateRequested(self):
        if self.sock is None:
            return
        want = (_READ | _WRITE) if self.outbuf else _READ
        if want != self._requested:
            self._requested = want
            try:
                self.notifier.setRequested(want)
            except Exception as e:
                debug("setRequested başarısız: %s" % e)

    # ------------------------------------------------------------ kapanış

    @property
    def name(self):
        try:
            return "%s:%s" % (self.addr[0], self.addr[1])
        except Exception:
            return "?"

    @property
    def queued(self):
        return len(self.outbuf)

    @property
    def dropsOnZap(self):
        """Kanal degisince bu istemcinin baglantisi kapatilsin mi?

        ffmpeg giristeki PID'leri ilk probe'da sabitler; kanal degisince
        yeni PID'leri gormez ve akis donar. Tek caresi yeniden baglanmasi,
        yani bizim baglantiyi kapatmamiz."""
        mode = cfg.on_zap.value
        if mode == "keep":
            return False
        if mode == "close":
            return True
        agent = (self.userAgent or "").lower()
        return any(tag in agent for tag in RECONNECTING_AGENTS)

    def close(self, reason="", flush=False):
        if self.sock is None:
            return
        if flush and self.outbuf:
            # kısa yanıtları kaybetmemek için tek seferlik bloklayan yazma
            try:
                self.sock.setblocking(True)
                self.sock.sendall(bytes(self.outbuf))
            except Exception:
                pass
        self.outbuf = bytearray()
        if self.streaming:
            log("izleyici ayrıldı: %s (%s, %.1f MB)"
                % (self.name, reason, self.bytesSent / 1048576.0))
        try:
            self.notifier.stop()
        except Exception:
            pass
        self.conn = None
        self.notifier = None
        _closeSocket(self.sock)
        self.sock = None
        self.server.onClientClosed(self)


# -------------------------------------------------------------- upstream

class _Upstream(object):
    """127.0.0.1:8001 üzerinden o an çalan kanalın TS akışı."""

    def __init__(self, server, path):
        self.server = server
        self.path = path
        self.state = "connecting"
        self.bytesIn = 0
        self.header = b""
        self.aligned = False
        self.since = time.time()
        self.notifier = None
        self.conn = None
        self._requested = 0
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setblocking(False)
        try:
            self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass
        rc = self.sock.connect_ex((UPSTREAM_HOST, UPSTREAM_PORT))
        if rc not in (0, errno.EINPROGRESS, errno.EWOULDBLOCK):
            _closeSocket(self.sock)
            self.sock = None
            self.state = "failed"
            log("8001'e bağlanılamadı: %s" % errno.errorcode.get(rc, rc))
            return
        self._requested = _READ | _WRITE
        self.notifier = eSocketNotifier(self.sock.fileno(), self._requested)
        self.conn = self.notifier.activated.connect(self._activated)
        debug("upstream açılıyor: %s" % path)

    # ------------------------------------------------------------ olaylar

    def _activated(self, what):
        try:
            if what & _WRITE and self.state == "connecting":
                self._onConnected()
            if self.sock is not None and what & _READ:
                self._read()
            if self.sock is not None and what & _BROKEN:
                self.close("upstream koptu")
        except Exception as e:
            log("upstream hatası: %s" % e)
            self.close("hata: %s" % e)

    def _onConnected(self):
        try:
            err = self.sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
        except Exception as e:
            self.close("soket durumu okunamadı: %s" % e)
            return
        if err:
            self.close("bağlantı reddedildi (%s)"
                       % errno.errorcode.get(err, err))
            return
        request = ("GET /%s HTTP/1.0\r\n"
                   "Host: %s:%d\r\n"
                   "User-Agent: ZapFollow\r\n"
                   "Connection: close\r\n\r\n"
                   % (self.path, UPSTREAM_HOST, UPSTREAM_PORT))
        try:
            self.sock.sendall(request.encode("ascii"))
        except socket.error as e:
            self.close("istek gönderilemedi: %s" % e)
            return
        self.state = "header"
        self._setRequested(_READ)
        debug("upstream isteği gönderildi: /%s" % self.path)

    def _read(self):
        for _ in range(16):                    # ana döngüyü aç bırak
            try:
                data = self.sock.recv(CHUNK)
            except socket.error as e:
                if e.args and e.args[0] in _AGAIN:
                    return
                self.close("okuma hatası: %s" % e)
                return
            if not data:
                self.close("upstream akışı bitti")
                return
            self.bytesIn += len(data)
            if self.state == "header":
                data = self._consumeHeader(data)
                if data is None:
                    if self.sock is None:
                        return
                    continue
            if data:
                self.server.broadcast(data)
            if self.server.paused or self.sock is None:
                return

    def _consumeHeader(self, data):
        """8001'in HTTP başlığını yutar, gövdenin ilk TS paketine hizalanır."""
        self.header += data
        sep = self.header.find(b"\r\n\r\n")
        size = 4
        if sep < 0:
            sep = self.header.find(b"\n\n")
            size = 2
        if sep < 0:
            if len(self.header) > MAX_REQUEST:
                self.close("upstream başlığı bozuk")
            return None
        if b" 200" not in self.header[0:16]:
            self.close("upstream yanıtı: %s"
                       % self.header.split(b"\r\n", 1)[0].decode("ascii",
                                                                 "replace"))
            return None
        body = self.header[sep + size:]
        self.header = b""
        self.state = "streaming"
        self.server.onUpstreamRunning(self)
        return self._align(body)

    def _align(self, data):
        """Kanal değiştiğinde araya giren yeni akışı TS paket sınırından
        başlatır; yarım paketle başlarsak oynatıcı gereksiz yere şaşırır."""
        if self.aligned or not data:
            return data
        idx = data.find(b"\x47")
        if idx < 0:
            return b""
        self.aligned = True
        return data[idx:]

    # ------------------------------------------------------------ denetim

    def _setRequested(self, req):
        if self.notifier is None or req == self._requested:
            return
        self._requested = req
        try:
            if req == 0:
                self.notifier.stop()
            else:
                self.notifier.setRequested(req)
                if not self.notifier.isRunning():
                    self.notifier.start()
        except Exception as e:
            debug("upstream notifier ayarlanamadı: %s" % e)

    def pause(self):
        self._setRequested(0)

    def resume(self):
        if self.sock is not None:
            self._setRequested(_READ)

    def close(self, reason=""):
        if self.sock is None:
            return
        debug("upstream kapandı: %s (%.1f MB)"
              % (reason, self.bytesIn / 1048576.0))
        try:
            if self.notifier is not None:
                self.notifier.stop()
        except Exception:
            pass
        self.conn = None
        self.notifier = None
        _closeSocket(self.sock)
        self.sock = None
        self.state = "closed"
        self.server.onUpstreamClosed(self, reason)


# ---------------------------------------------------------------- sunucu

class ZapFollowServer(object):

    def __init__(self):
        self.listenSock = None
        self.listenNotifier = None
        self.listenConn = None
        self.port = None
        self.clients = []
        self.upstream = None
        self.paused = False
        self.streamPath = None            # upstream'in bağlı olduğu servis
        self.lastError = ""
        self.zapPending = False
        # Zap'tan sonra gelecek evStart'i tanimak icin kisa bir pencere.
        # Bayrak yerine zaman kullaniyoruz: evStart bazen playService
        # cagrisinin icinden senkron, bazen birkac yuz ms sonra gelir.
        self._zapWindowUntil = 0.0
        self.navAttached = False
        self.startedAt = None

        self._openTimer = eTimer()
        self._openConn = self._openTimer.timeout.connect(self._openUpstream)
        self._zapTimer = eTimer()
        self._zapConn = self._zapTimer.timeout.connect(self._runPendingZap)
        self._pendingZap = None

    # ------------------------------------------------------- yaşam döngüsü

    @property
    def running(self):
        return self.listenSock is not None

    def start(self):
        if self.running:
            return True
        port = int(cfg.port.value)
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setblocking(False)
            sock.bind(("0.0.0.0", port))
            sock.listen(4)
        except socket.error as e:
            self.lastError = "port %d dinlenemedi: %s" % (port, e)
            log(self.lastError)
            if sock is not None:
                _closeSocket(sock)
            return False
        self.listenSock = sock
        try:
            self.port = sock.getsockname()[1]   # port 0 verilmişse gerçeği
        except Exception:
            self.port = port
        self.listenNotifier = eSocketNotifier(sock.fileno(), _READ)
        self.listenConn = self.listenNotifier.activated.connect(self._onAccept)
        self.startedAt = time.time()
        self.lastError = ""
        self.attachNav()
        log("dinleniyor: http://<kutu>:%d/live" % port)
        return True

    def stop(self):
        self._openTimer.stop()
        self._zapTimer.stop()
        self._pendingZap = None
        self.zapPending = False
        self._zapWindowUntil = 0.0
        self.detachNav()
        for client in list(self.clients):
            client.close("sunucu kapanıyor")
        self.clients = []
        self._closeUpstream("sunucu kapanıyor")
        if self.listenNotifier is not None:
            try:
                self.listenNotifier.stop()
            except Exception:
                pass
        self.listenConn = None
        self.listenNotifier = None
        if self.listenSock is not None:
            _closeSocket(self.listenSock)
            self.listenSock = None
            log("durduruldu")
        self.port = None
        self.startedAt = None

    def restart(self):
        self.stop()
        return self.start()

    # ----------------------------------------------------------- olaylar

    def attachNav(self):
        nav = NavigationInstance.instance
        if nav is None or self.navAttached:
            return
        nav.event.append(self._onServiceEvent)
        self.navAttached = True

    def detachNav(self):
        nav = NavigationInstance.instance
        if nav is not None and self.navAttached:
            try:
                nav.event.remove(self._onServiceEvent)
            except ValueError:
                pass
        self.navAttached = False

    def _onServiceEvent(self, what):
        if what != iPlayableService.evStart:
            return
        # Bizim başlattığımız zap'ın sonucu mu geldi? Kanalı okuyamasak
        # bile bu tek başına "kanal değişti" demektir; kesilmesi gereken
        # istemciler buna bakılarak bırakılır. Zap kayıt yüzünden
        # reddedilseydi evStart hiç gelmez, pencere sessizce kapanırdı.
        afterZap = time.time() < self._zapWindowUntil
        if afterZap:
            self._zapWindowUntil = 0.0
        self.zapPending = False
        path = currentStreamPath()

        if afterZap or (path is not None and path != self.streamPath):
            self._dropReconnectingClients()

        if path is None:
            # Ya DVB dışı bir servise geçildi (kayıt oynatma vb.), ya da
            # referans bu anda henüz okunabilir değil. İkisinde de yapılacak
            # şey aynı: akışı bırak, biraz sonra tekrar bak.
            if self.upstream is not None:
                self._closeUpstream("kanal değişiyor")
            self.streamPath = None
            if self.hasViewers():
                self._openTimer.start(int(cfg.restart_delay.value), True)
            return

        if path == self.streamPath and self.upstream is not None:
            return
        self.streamPath = path
        if self.hasViewers():
            self._openTimer.start(int(cfg.restart_delay.value), True)

    def _dropReconnectingClients(self):
        """ffmpeg gibi istemcileri bırakır: yeni kanalı ancak yeniden
        bağlanarak görebilirler.

        Kesme zap isteğinde değil, yeni servis başladığında (evStart)
        yapılır: kayıt yüzünden "boşta tuner yok" ile reddedilen bir zap'ta
        evStart hiç gelmez, dolayısıyla bu istemciler boşuna yeniden
        başlatılmaz -- akışları eski kanaldan sürer."""
        for client in list(self.clients):
            if client.streaming and client.dropsOnZap:
                client.close("kanal değişti, yeniden bağlanması gerekiyor")

    def _onAccept(self, what):
        while True:
            try:
                sock, addr = self.listenSock.accept()
            except socket.error as e:
                if e.args and e.args[0] in _AGAIN:
                    return
                log("accept hatası: %s" % e)
                return
            if len(self.clients) >= MAX_CLIENTS:
                log("istemci sınırı doldu, reddedildi: %s" % (addr,))
                _closeSocket(sock)
                continue
            self.clients.append(_Client(self, sock, addr))

    def onClientReady(self, client):
        """İstemci yayın istedi: upstream yoksa aç."""
        # sessionstart anında NavigationInstance henüz yoksa olay bağlantısı
        # kurulamamış olabilir; her fırsatta yeniden deneriz
        self.attachNav()
        if self.upstream is None and not self.zapPending:
            if self.streamPath is None:
                self.streamPath = currentStreamPath()
            self._openTimer.start(50, True)

    def onClientClosed(self, client):
        if client in self.clients:
            self.clients.remove(client)
        if not self.hasViewers():
            self._openTimer.stop()
            self._closeUpstream("izleyici kalmadı")
        else:
            self.maybeResume()

    # ---------------------------------------------------------- upstream

    def _openUpstream(self):
        self.attachNav()
        if not self.hasViewers() or self.zapPending:
            return
        path = self.streamPath or currentStreamPath()
        if path is None:
            # Ya DVB dışı bir servis çalıyor, ya da zap'tan sonra referans
            # hâlâ yazılmamış. İzleyici bekliyorsa pes etmeyip tekrar bakarız.
            debug("çalan servis yayınlanabilir değil, upstream açılmadı")
            self._openTimer.start(int(cfg.retry_delay.value), True)
            return
        self.streamPath = path
        if self.upstream is not None:
            if self.upstream.path == path and self.upstream.sock is not None:
                return
            self._closeUpstream("kanal değişti")
        self.paused = False
        upstream = _Upstream(self, path)
        if upstream.sock is None:
            self.lastError = "8001'e bağlanılamadı"
            self._openTimer.start(int(cfg.retry_delay.value), True)
            return
        self.upstream = upstream

    def _closeUpstream(self, reason):
        upstream = self.upstream
        self.upstream = None
        self.paused = False
        if upstream is not None:
            upstream.close(reason)

    def releaseUpstream(self, reason="zap"):
        """Zap'tan hemen önce çağrılır: tuner'ı tutan streaming servisini
        bırakırız. İstemci soketlerine dokunmayız."""
        self._openTimer.stop()
        self._closeUpstream(reason)

    def onUpstreamRunning(self, upstream):
        if upstream is self.upstream:
            self.lastError = ""
            log("kanal yayınlanıyor: %s" % upstream.path)

    def onUpstreamClosed(self, upstream, reason):
        if upstream is not self.upstream:
            return
        self.upstream = None
        self.paused = False
        if self.zapPending:
            return                             # zap sırasında biz kapattık
        if self.hasViewers() and cfg.enabled.value:
            self.lastError = reason
            self._openTimer.start(int(cfg.retry_delay.value), True)

    # ------------------------------------------------------------- akış

    def broadcast(self, data):
        worst = 0
        for client in list(self.clients):
            if not client.streaming:
                continue
            client.feed(data)
            if client.sock is not None and client.queued > worst:
                worst = client.queued
        if worst > HIGH_WATER and not self.paused and self.upstream is not None:
            self.paused = True
            self.upstream.pause()
            debug("akış duraklatıldı (kuyruk %d KB)" % (worst // 1024))

    def maybeResume(self):
        if not self.paused or self.upstream is None:
            return
        worst = max([c.queued for c in self.clients if c.streaming] or [0])
        if worst <= RESUME_WATER:
            self.paused = False
            self.upstream.resume()
            debug("akış devam ediyor")

    # -------------------------------------------------------------- zap

    def hasViewers(self):
        return any(c.streaming and c.sock is not None for c in self.clients)

    def wantsDeferredZap(self, ref):
        """patcher buradan sorar: bu zap'ı biz mi yöneteceğiz?"""
        if not cfg.enabled.value or not cfg.follow.value:
            return False
        if not self.running or not self.hasViewers():
            return False
        if self.upstream is None:
            return False                       # tuner'ı tutan bir şeyimiz yok
        try:
            if ref is None or not ref.valid():
                return False
        except Exception:
            return False
        return True

    def beginZap(self, callback):
        """Upstream'i bırak, gerçek zap'ı kısa bir gecikmeyle çalıştır.

        Gecikme şart: enigma2 soketimizin kapandığını ana döngüde fark edip
        streaming servisini sonlandırana kadar tuner hâlâ meşguldür.

        İstemcilere burada dokunulmaz: zap kayıt yüzünden reddedilebilir.
        Kesilmesi gerekenler, kanalın gerçekten değiştiği anda
        (`_dropReconnectingClients`) bırakılır."""
        self.zapPending = True
        self._zapWindowUntil = time.time() + ZAP_WINDOW_SECONDS
        self.releaseUpstream("zap")
        self._pendingZap = callback
        self._zapTimer.start(max(1, int(cfg.zap_delay.value)), True)

    def _runPendingZap(self):
        callback = self._pendingZap
        self._pendingZap = None
        self.zapPending = False
        if callback is None:
            return
        try:
            callback()
        except Exception as e:
            log("zap çalıştırılamadı: %s" % e)
        # evStart hiç gelmezse (iptal edilen zap, aynı servis) yine toparla
        if self.hasViewers():
            self._openTimer.start(int(cfg.restart_delay.value), True)

    # ------------------------------------------------------------ durum

    def statusText(self):
        lines = ["ZapFollow"]
        lines.append("durum      : %s"
                     % ("çalışıyor" if self.running else "kapalı"))
        if self.port:
            lines.append("port       : %d  (/live)" % self.port)
        lines.append("zap takibi : %s"
                     % ("açık" if cfg.follow.value else "kapalı"))
        lines.append("kanal      : %s" % (self.streamPath or "-"))
        if self.upstream is not None:
            lines.append("upstream   : %s, %.1f MB"
                         % (self.upstream.state,
                            self.upstream.bytesIn / 1048576.0))
        else:
            lines.append("upstream   : yok")
        viewers = [c for c in self.clients if c.streaming]
        lines.append("izleyici   : %d" % len(viewers))
        for client in viewers:
            lines.append("  %s  %.1f MB  kuyruk %d KB  %d sn  zapta:%s  %s"
                         % (client.name, client.bytesSent / 1048576.0,
                            client.queued // 1024,
                            int(time.time() - client.since),
                            "kes" if client.dropsOnZap else "koru",
                            client.userAgent or "-"))
        if self.paused:
            lines.append("akış       : duraklatıldı (yavaş izleyici)")
        if self.lastError:
            lines.append("son hata   : %s" % self.lastError)
        return "\n".join(lines) + "\n"


server = ZapFollowServer()
