# -*- coding: utf-8 -*-
#
# ZapFollow - ayarlar
#
from Components.config import (config, ConfigSubsection, ConfigYesNo,
                               ConfigSelection, ConfigInteger)

try:                      # enigma2 gettext'i "_" adını builtin olarak kurar;
    _                     # test/stub ortamında kurmamış olabilir
except NameError:
    def _(txt):
        return txt

config.plugins.zapfollow = ConfigSubsection()
cfg = config.plugins.zapfollow

# Eklenti tümüyle etkin mi
cfg.enabled = ConfigYesNo(default=True)

# Proxy'nin dinlediği port. 8001 enigma2'nin kendi stream sunucusunundur,
# 80 web arayüzünün; ikisi de kullanılamaz.
cfg.port = ConfigInteger(default=8002, limits=(1, 65535))

# Zap'ı takip et: kutuda kanal değişince akış da yeni kanala geçer.
# Kapatılırsa proxy yalnızca bağlandığı anki kanalı yayınlar (ve zap yine
# "boşta tuner yok" ile engellenebilir).
cfg.follow = ConfigYesNo(default=True)

# Zap isteğini kaç ms geciktirelim.
#
# Sıra önemli: önce kendi upstream soketimizi kapatırız, enigma2 bunu ana
# döngüde fark edip streaming servisini sonlandırır ve tuner'ı bırakır,
# ANCAK ondan sonra gerçek playService çalışabilir. Aradaki bu gecikme o
# devir teslime zaman tanır; çok kısa olursa zap yine "boşta tuner yok"
# ile döner.
cfg.zap_delay = ConfigSelection(default="250", choices=[
    ("0", _("beklemeden")), ("100", "100 ms"), ("250", "250 ms"),
    ("500", "500 ms"), ("1000", "1 s"),
])

# Zap bittikten kaç ms sonra yeni kanala yeniden bağlanalım. Hızlı ardışık
# zaplarda her kanal için upstream açıp kapatmayı da bu bekleme önler.
cfg.restart_delay = ConfigSelection(default="800", choices=[
    ("300", "300 ms"), ("500", "500 ms"), ("800", "800 ms"),
    ("1500", "1,5 s"), ("2500", "2,5 s"),
])

# Upstream beklenmedik şekilde koptuğunda (standby, servis hatası) yeniden
# deneme aralığı
cfg.retry_delay = ConfigSelection(default="3000", choices=[
    ("1000", "1 s"), ("3000", "3 s"), ("5000", "5 s"), ("10000", "10 s"),
])

# Kanal degisince istemci baglantisina ne olsun?
#
#   keep  : baglanti korunur. Oynaticilar (VLC vb.) icin dogru secim;
#           akis ~1 sn duraklar, sonra yeni kanaldan devam eder.
#   close : baglanti kapatilir. ffmpeg gibi araclar giristeki PID'leri
#           basta sabitler (-map 0:v:0), kanal degisince yeni PID'leri
#           GORMEZ ve donar; yeniden baslamalari gerekir.
#   auto  : istemcinin User-Agent'ina bakar -- ffmpeg/libavformat ise
#           kapatir, digerlerinde korur.
cfg.on_zap = ConfigSelection(default="auto", choices=[
    ("auto", _("Otomatik (ffmpeg kesilir, oynatıcı korunur)")),
    ("keep", _("Bağlantı korunsun")),
    ("close", _("Bağlantı kapansın")),
])

cfg.debug = ConfigYesNo(default=False)
