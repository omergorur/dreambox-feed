# -*- coding: utf-8 -*-
#
# ZapFollow - ayar ve durum ekranı
#
# Not: liste widget'ına skin'de font/itemHeight VERİLMEZ -- DreamOS'ta
# eListbox'ta setFont yoktur, skin.py applySingleAttribute AttributeError
# fırlatır ve ekran yeşile döner.
#
from __future__ import print_function

import socket

from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.config import getConfigListEntry, configfile

from enigma import getDesktop, eTimer

from .settings import cfg
from .server import server
from . import patcher

STATUS_REFRESH_MS = 2000


def _hd():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:
        return False


def localAddress():
    """Kutunun LAN adresi -- ekranda tam URL gösterebilmek için.

    UDP soketi hiçbir paket göndermez, yalnızca çekirdeğin hangi arayüzü
    seçtiğini sorar."""
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("192.0.2.1", 9))          # TEST-NET-1, yönlendirilmez
        return sock.getsockname()[0]
    except Exception:
        return "<kutu>"
    finally:
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass


def _setupSkin():
    if _hd():
        return """
        <screen name="ZapFollowSetup" position="center,center" size="1200,860" title="Zap Takipli Yayın">
            <widget name="config" position="30,20" size="1140,330" scrollbarMode="showOnDemand" />
            <widget name="status" position="30,370" size="1140,390" font="Regular;24" />
            <widget source="key_red" render="Label" position="30,780" size="280,45" font="Regular;28" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="320,780" size="280,45" font="Regular;28" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="610,780" size="280,45" font="Regular;28" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="900,780" size="270,45" font="Regular;28" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="ZapFollowSetup" position="center,center" size="800,560" title="Zap Takipli Yayın">
        <widget name="config" position="20,15" size="760,220" scrollbarMode="showOnDemand" />
        <widget name="status" position="20,245" size="760,240" font="Regular;18" />
        <widget source="key_red" render="Label" position="20,500" size="185,30" font="Regular;20" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="210,500" size="185,30" font="Regular;20" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="400,500" size="185,30" font="Regular;20" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="590,500" size="190,30" font="Regular;20" foregroundColor="blue" halign="left" />
    </screen>"""


class ZapFollowSetup(Screen, ConfigListScreen):
    """Ayarlar + canlı durum. Kutuya telnet'le girmeden teşhis için durum
    bölümü kasten ayrıntılı."""

    def __init__(self, session):
        self.skin = _setupSkin()
        Screen.__init__(self, session)
        self.setTitle(_("Zap Takipli Yayın"))

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Yenile"))
        self["key_blue"] = StaticText(_("Başlat/Durdur"))
        self["status"] = Label("")

        ConfigListScreen.__init__(self, self._entries(), session=session)

        # "ok" bağlanmaz: ConfigListScreen kendi haritasında kullanıyor
        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "cancel": self.keyCancel,
                "save": self.keySave,
                "red": self.keyCancel,
                "green": self.keySave,
                "yellow": self.updateStatus,
                "blue": self.toggleServer,
            }, -1)

        self.timer = eTimer()
        self.timer_conn = self.timer.timeout.connect(self.updateStatus)
        self.onLayoutFinish.append(self._onShown)
        self.onClose.append(self.timer.stop)

    def _onShown(self):
        self.updateStatus()
        self.timer.start(STATUS_REFRESH_MS, False)

    def _entries(self):
        return [
            getConfigListEntry(_("Etkin"), cfg.enabled),
            getConfigListEntry(_("Port"), cfg.port),
            getConfigListEntry(_("Zap'ı takip et"), cfg.follow),
            getConfigListEntry(_("Kanal değişince istemci"), cfg.on_zap),
            getConfigListEntry(_("Zap gecikmesi"), cfg.zap_delay),
            getConfigListEntry(_("Kanal sonrası bekleme"), cfg.restart_delay),
            getConfigListEntry(_("Yeniden deneme aralığı"), cfg.retry_delay),
            getConfigListEntry(_("Ayrıntılı günlük"), cfg.debug),
        ]

    # ------------------------------------------------------------- durum

    def updateStatus(self):
        lines = []
        if server.running:
            lines.append(_("Yayın adresi: http://%s:%d/live")
                         % (localAddress(), server.port))
        else:
            lines.append(_("Sunucu çalışmıyor"))
        lines.append(_("Zap yaması: %s")
                     % (_("uygulandı") if patcher.isApplied()
                        else _("uygulanmadı")))
        lines.append("")
        lines.append(server.statusText())
        self["status"].setText("\n".join(lines))

    def toggleServer(self):
        if server.running:
            patcher.revert()
            server.stop()
        else:
            if server.start():
                patcher.apply()
        self.updateStatus()

    # ---------------------------------------------------------- kaydetme

    def keySave(self):
        self.saveAll()
        configfile.save()
        if cfg.enabled.value:
            # port değişmiş olabilir: temiz yeniden başlatma
            server.restart()
            patcher.apply()
        else:
            patcher.revert()
            server.stop()
        self.close()


def openSetup(session, **kwargs):
    session.open(ZapFollowSetup)
