# ZapFollow

Ağdan izlenen yayını, kutuda yapılan zap ile birlikte taşır.

## Sorun

enigma2'nin stream sunucusunda (port 8001, `stream_enigma2`) **statik uç
yoktur**: URL'de hangi servis referansı yazıyorsa o yayınlanır.

```
http://192.168.2.20:8001/1:0:11:4286:78B5:2A:1A40000:0:0:0:
```

İki sonucu var:

1. Ağdan izleyen kişi tek bir kanala kilitlenir; kutuda kanal değişse bile
   onun akışı eski kanalda kalır.
2. O akış bir tuner tutar. Kutudan başka transpondere zap yapmak istediğinde
   enigma2 boş tuner bulamaz ve `"boşta tuner yok"` (`No free tuner!`,
   `Screens/InfoBarGenerics.py`) uyarısı verir. Yani evdeki biri seyrederken
   TV'de kanal değiştiremezsin.

Kayıt sırasında bu koruma yerindedir — kaydın yarıda kesilmemesi gerekir.
Ama biri **canlı olarak senin izlediğin kanalı** seyrediyorken zap'ın
engellenmesinin bir sebebi yok: akışı da yeni kanala taşımak yeterli.

(`WebInterface/WebChilds/RedirecToCurrentStream.py` "o anki kanal" için bir
uç sunar ama yalnızca 8001'e **yönlendirir**; istemci yine sabit referansa
bağlanır, dolayısıyla sorunun ikisini de çözmez.)

## Çözüm

Eklenti kutuda sabit bir uç açar:

```
http://<kutu>:8002/live
```

İstemci (VLC vb.) bu adrese bağlanır. Eklenti de arka planda
`127.0.0.1:8001` üzerinden o an çalan kanalı çeker ve istemciye aktarır.
Kanal değiştiğinde **istemcinin TCP bağlantısı kapanmaz**, yalnızca arkadaki
kaynak değişir:

1. `Navigation.playService` sarmalayıcısı gerçek zap'tan önce devreye girer,
2. upstream soketi kapatılır → enigma2 streaming servisini sonlandırır →
   **tuner serbest kalır**,
3. gerçek zap yapılır (artık "boşta tuner yok" gelmez),
4. `evStart` ile yeni kanal öğrenilir ve upstream yeniden açılır.

İzleyen taraf senin geçtiğin kanaldan devam eder. Görüntü yeniden
kodlanmaz; yayının ham TS'i aktarılır.

Bir uyarı: akışın ortasında program/PID değişimini **hiçbir oynatıcı iyi
karşılamıyor** -- ffmpeg de VLC de takılıyor ve yeni PMT'yi ancak yeniden
bağlanarak okuyor (VLC'de stop/start). Bu yüzden pratikte doğru kip,
istemcinin bağlantısını kesip yeniden bağlanmasını sağlamaktır; ffmpeg
için `auto` kipi bunu kendiliğinden yapar, VLC için aşağıdaki nota bakın.

## Uçlar

| Adres | Ne yapar |
|-------|----------|
| `/live` | O an çalan kanalın TS akışı (VLC'ye verilecek adres) |
| `/stream`, `/` | `/live` ile aynı |
| `/status` | Teşhis metni: izleyiciler, upstream durumu, kuyruk, son hata |

## Ayarlar

Menü > Eklentiler > **Zap Takipli Yayın**

| Ayar | Anlamı |
|------|--------|
| Etkin | Eklenti tümüyle açık/kapalı |
| Port | Dinlenen port (varsayılan 8002; 80 ve 8001 doludur) |
| Zap'ı takip et | Kapalıyken proxy yalnızca bağlandığı kanalı yayınlar |
| Kanal değişince istemci | `auto` (varsayılan): ffmpeg/libavformat istemcilerinin bağlantısı kapatılır, oynatıcılarınki korunur. `keep`: hepsi korunur. `close`: hepsi kapatılır. Aşağıdaki "ffmpeg" başlığına bakın. |
| Zap gecikmesi | Upstream bırakıldıktan sonra gerçek zap'a kadar beklenen süre. Zap hâlâ "boşta tuner yok" diyorsa artır. |
| Kanal sonrası bekleme | Zap bittikten sonra yeni kanala bağlanma gecikmesi. Hızlı ardışık zaplarda gereksiz bağlantı açılmasını da önler. |
| Yeniden deneme aralığı | Upstream koptuğunda (standby vb.) yeniden deneme sıklığı |
| Ayrıntılı günlük | enigma2 günlüğüne ayrıntı basar |

Ayar ekranının alt yarısı canlı durumu gösterir (yayın adresi, yamanın
uygulanıp uygulanmadığı, bağlı izleyiciler, aktarılan veri). Kutuya telnet
ile girmeden teşhis için oradan bakılabilir.

## Kurulum

```bash
dpkg -i enigma2-plugin-extensions-zapfollow_1.1r-3_all.deb
killall -9 enigma2
```

Kaldırma:

```bash
dpkg -r enigma2-plugin-extensions-zapfollow
```

## Mevcut Flask yönlendiricisi ile

Ağda `192.168.2.30:5000/live` adresi 8001'e yönlendirme yapıyorsa, artık
sabit hedefe yönlendirebilir:

```python
return redirect("http://192.168.2.20:8002/live")
```

Ya da o katman tümüyle atlanıp VLC'ye doğrudan `http://192.168.2.20:8002/live`
verilebilir — statik uç artık kutunun kendisinde.

## ffmpeg ile kullanım (transcode / HLS zinciri)

Oynatıcılar akışın ortasında program değişimini tolere eder, **ffmpeg etmez**:
`-i <url>` girişini bir kez probe eder ve `-map 0:v:0` ile o andaki PID'lere
bağlanır. Kanal değişince yeni PID'leri görmez, akış donar. Bağlantıyı açık
tutmak burada tam ters etki yapar.

Bu yüzden eklenti, `auto` kipinde User-Agent'ı `Lavf/…`, `ffmpeg`, `libav`
olan istemcilerin bağlantısını **kapatır** — ffmpeg'in çıkıp yeniden
başlaması, yeni kanalı baştan probe etmesi için. Kapatma, zap isteğinde
değil kanalın gerçekten değiştiği anda (`evStart`) yapılır; böylece kayıt
yüzünden reddedilen bir zap ffmpeg'i boşuna yeniden başlatmaz. Yeniden
başlatmayı çağıran taraf yapar; hazır betik: `Desktop\Video\live.bat`.

Betik HLS listesini kesintiye uğratmadan sürdürür:

| Bayrak | Neden |
|--------|-------|
| `append_list` | yeni segmentler eski listenin sonuna eklenir |
| `omit_endlist` | ffmpeg çıkarken `#EXT-X-ENDLIST` yazmaz; oynatıcı yayını bitmiş saymaz |
| `discont_start` | her turun ilk segmentine `#EXT-X-DISCONTINUITY` konur, zaman tabanı sıçraması sorun çıkarmaz |

Segment adları her turda ayrı önek alır (`seg-<rastgele>-%d.ts`), eskiyenleri
betik 30 saniye sonra siler. İzleyici kanal değişiminde birkaç saniye takılır,
sonra yeni kanaldan devam eder.

## Bilinmesi gerekenler

- **Kayıt korumasına dokunulmaz.** Yama yalnızca eklentinin kendi akışını
  bırakır; kaydın tuttuğu tuner'a dokunmaz. HDD'ye kayıt sürerken boş tuner
  kalmadıysa zap yine "boşta tuner yok" ile reddedilir — olması gereken de bu.
  Reddedilen zap'ta hiçbir istemci boşuna kesilmez: ffmpeg istemcileri kanalın
  gerçekten değiştiği anda (`evStart`) bırakılır, zap isteğinde değil. Akış
  kısa bir duraklamadan sonra eski kanaldan sürer.
- **Kanal değişiminde oynatıcı akışı yeniden çözmek zorundadır.** Ölçülen
  davranış: VLC bağlantı açık kaldığında yeni kanalı göstermiyor, stop/start
  gerekiyor; ffmpeg de aynı şekilde donuyor. Çözüm ikisinde de aynı:
  bağlantıyı kesip yeniden bağlanmak. ffmpeg'i `auto` kipi zaten kesiyor.
  VLC'yi de otomatikleştirmek istersen ayarı `close` yap ve VLC'yi
  `vlc --loop http://<kutu>:8002/live` ile aç -- akış kesilince VLC
  kendiliğinden yeniden bağlanır. Aksi hâlde VLC'de elle stop/start.
- **DVB dışı servislerde yayın durur.** Kutuda kayıt/film oynatılırken
  (`4097:`, dosya yollu referanslar) upstream açılmaz; izleyicinin bağlantısı
  ayakta kalır ve canlı TV'ye dönülünce akış kendiliğinden sürer.
- **İzleyici yoksa hiçbir kaynak tutulmaz.** Upstream ancak `/live` isteyen
  bir istemci varken açılır, son izleyici ayrılınca kapanır.
- **Yavaş izleyici** akışı geriletirse önce kuyruğa alınır (2 MB'ta upstream
  duraklatılır), 8 MB'ı aşarsa bağlantısı kesilir — kutunun belleği şişmesin.
- Aynı anda en fazla 8 istemci; hepsi tek upstream'i paylaşır, ek tuner
  kullanılmaz.

## Test

Kutuya erişmeden çalışır (sahte `eSocketNotifier`/`eTimer` ana döngüsü,
gerçek TCP soketleri, sahte bir 8001 sunucusu):

```bash
python _tools/test_zapfollow.py
```
