# -*- coding: utf-8 -*-
#
# ZapFollow
#
# enigma2'nin stream sunucusunda (port 8001) statik bir uç yoktur: URL'de
# hangi servis referansı yazıyorsa o yayınlanır. Sonuç olarak ağdan izleyen
# kişi tek bir kanala kilitlenir ve o kanal bir tuner tuttuğu için kutudan
# başka transpondere zap yapmak "boşta tuner yok" ile geri çevrilir.
#
# Bu eklenti kutuda sabit bir uç açar:
#
#     http://<kutu>:8002/live
#
# Bağlantı hiç kopmaz; arkadaki kaynak zap ile birlikte değişir. Kutuda
# kanal değiştirildiğinde önce upstream bırakılır (tuner serbest kalır),
# zap yapılır, sonra yeni kanala yeniden bağlanılır. İzleyen kişi de otomatik
# olarak yeni kanala geçmiş olur.
#
# Kurulum:
#   /usr/lib/enigma2/python/Plugins/Extensions/ZapFollow/
#   ardından enigma2 yeniden başlatılır.
#
# Ayarlar: Menü > Eklentiler > Zap Takipli Yayın
#
VERSION = "1.2"

from Plugins.Plugin import PluginDescriptor

from .settings import cfg
from .server import server, log
from . import patcher
from .ui import openSetup


def sessionstart(reason, session=None, **kwargs):
    if reason == 0:
        if not cfg.enabled.value:
            log("eklenti kapalı")
            return
        if server.start():
            patcher.apply()
            log("v%s başlatıldı" % VERSION)
    elif reason == 1:
        # enigma2 kapanıyor: soketleri ve yamayı geride bırakmayalım
        patcher.revert()
        server.stop()


def toggleFromExtensions(session, **kwargs):
    if server.running:
        patcher.revert()
        server.stop()
        text = _("Zap takipli yayın durduruldu")
    else:
        if server.start():
            patcher.apply()
            text = _("Zap takipli yayın açıldı: %s") % ("http://<kutu>:%d/live"
                                                        % server.port)
        else:
            text = _("Başlatılamadı: %s") % server.lastError
    try:
        session.toastManager.showToast(text)
    except Exception:
        log(text)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="ZapFollow",
            description="Ağdan izlenen yayını kutudaki zap ile birlikte taşır",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            needsRestart=False,
            fnc=sessionstart),
        PluginDescriptor(
            name=_("Zap Takipli Yayın"),
            description=_("Ağdan izleyen kişi zap yaptığın kanala geçsin"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            needsRestart=False,
            fnc=openSetup),
        PluginDescriptor(
            name=_("Zap takipli yayın aç/kapat"),
            description=_("Yayın sunucusunu geçici olarak durdur veya başlat"),
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            needsRestart=False,
            fnc=toggleFromExtensions),
    ]
