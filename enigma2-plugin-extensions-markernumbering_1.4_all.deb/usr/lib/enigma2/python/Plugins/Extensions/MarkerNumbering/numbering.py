# -*- coding: utf-8 -*-
#
# MarkerNumbering - çekirdek numaralandırma mantığı
#
# DreamOS kanal listesinde gösterilen numara Python tarafında hesaplanır
# (Components/ServiceList.py:392, ChannelSelectionPlus/plugin.py:1347 ...):
#
#     markers_before = self.l.getNumMarkersBeforeCurrent()
#     text = "%d" % (self.numberoffset + index + 1 - markers_before)
#
# `index` ve `markers_before` her ikisi de o an ÇİZİLEN satıra aittir
# (eListbox paint sırasında içerik imlecini satır satır ilerletir).
#
# Bu eklenti formüle dokunmaz; yalnızca `numberoffset`'e satıra özel bir fark
# ekler. Fark, satırın görüntü indeksine göre önceden hesaplanmış bir diziden
# okunur ve iki kip için ayrı ayrı tutulur:
#
#   gizli kip (varsayılan)  yer tutucu satırları listeden çıkarılır;
#                           fark = o satırdan önce gizlenen yer tutucu sayısı.
#   görünür kip            yer tutucular listede kalır; C++ onları da marker
#                           saydığı için fark = o satırdan önceki adsız
#                           marker sayısı (çıkarılanı geri ekler).
#
# İki durumda da sonuç: adsız marker bir kanal numarası tüketir, adlı marker
# (bölüm başlığı) tüketmez -- yani OpenATV davranışı.
#
from enigma import eServiceCenter, eServiceReference

from .settings import cfg

try:
    _
except NameError:
    def _(txt):
        return txt


def log(msg):
    if cfg.debug.value:
        print("[MarkerNumbering] %s" % msg)


# Kanal listesi bağlam menüsünden gelen geçici görünürlük seçimi.
# None = ayara uy, True/False = bu oturum için ayarı geçersiz kıl.
_hideOverride = [None]


def setHideOverride(value):
    _hideOverride[0] = value


def hideOverride():
    return _hideOverride[0]


def perBouquet():
    """Her buke 1'den mi başlıyor?"""
    return bool(cfg.enabled.value and cfg.numbering_mode.value == "perbouquet")


def hiding():
    """Yer tutucu satırları listeden gizleniyor mu?"""
    if not cfg.enabled.value:
        return False
    if _hideOverride[0] is not None:
        return bool(_hideOverride[0])
    return bool(cfg.hide_placeholders.value)


# --------------------------------------------------------------- marker tespiti

def isMarker(ref):
    try:
        return bool(ref.flags & eServiceReference.isMarker)
    except Exception:
        return False


def markerName(ref):
    """
    Marker'ın adını döndürür; adsız marker için boş dize.

    Birincil kaynak eServiceReference::getName(). Boş dönerse referans dizesi
    ayrıştırılır: toString() biçimi
        type:flags:data0..data7:path[:name]
    yani ad varsa 12. alandan itibaren gelir (11 alan + ad).
    """
    name = ""
    try:
        name = ref.getName() or ""
    except Exception:
        name = ""
    if not name:
        try:
            parts = ref.toString().split(":")
        except Exception:
            parts = []
        if len(parts) > 11:
            name = ":".join(parts[11:])
    try:
        return name.strip()
    except Exception:
        return ""


def isEmptyMarker(ref):
    """Kanal numarası rezerve eden 'boş marker' (yer tutucu) mu?"""
    return isMarker(ref) and not markerName(ref)


def countsAsChannel(ref):
    """
    Bu satır bir kanal numarası tüketir mi?

    - gerçek servis            -> evet
    - klasör / buke            -> hayır
    - adlı marker (başlık)     -> hayır
    - adsız marker (yer tutucu)-> eklenti etkinse evet
    """
    try:
        flags = ref.flags
    except Exception:
        return False
    if flags & eServiceReference.isDirectory:
        return False
    if flags & eServiceReference.isMarker:
        return bool(cfg.enabled.value) and not markerName(ref)
    return True


def listRoot(rootstr):
    """Bukenin ham içeriğini döndürür (görüntü listesi değil, buke dosyası)."""
    out = []
    try:
        lst = eServiceCenter.getInstance().list(eServiceReference(rootstr))
    except Exception as e:
        log("liste alınamadı (%s): %s" % (rootstr, e))
        return out
    if lst is None:
        return out
    while True:
        try:
            ref = lst.getNext()
        except Exception as e:
            log("getNext hatası: %s" % e)
            break
        if not ref.valid():
            break
        out.append(ref)
    return out


# ------------------------------------------------------------------- önbellek

class RootCache(object):
    """
    Buke başına, görüntü indeksine göre numara farkı.

    _visible[rootstr][i] : yer tutucular listedeyken i. satırın farkı
    _hidden[rootstr][i]  : yer tutucular gizliyken  i. satırın farkı
    _empty[rootstr]      : yer tutucu referanslarının dizeleri (gizleme için)
    """

    def __init__(self):
        self._visible = {}
        self._hidden = {}
        self._empty = {}
        self._stats = {}

    def clear(self):
        self._visible.clear()
        self._hidden.clear()
        self._empty.clear()
        self._stats.clear()
        log("önbellek tümüyle temizlendi")

    def invalidate(self, rootstr):
        if rootstr:
            self._visible.pop(rootstr, None)
            self._hidden.pop(rootstr, None)
            self._empty.pop(rootstr, None)
            self._stats.pop(rootstr, None)

    def _build(self, rootstr):
        visible = []
        hidden = []
        empty_refs = []
        empty = 0
        markers = 0
        entries = 0
        for ref in listRoot(rootstr):
            entries += 1
            if isMarker(ref):
                markers += 1
                if not markerName(ref):
                    # yer tutucu: görünür kipte kendi satırı var, gizli kipte yok
                    empty_refs.append(ref.toString())
                    visible.append(empty)
                    empty += 1
                    continue
            visible.append(empty)
            hidden.append(empty)
        self._visible[rootstr] = visible
        self._hidden[rootstr] = hidden
        self._empty[rootstr] = empty_refs
        self._stats[rootstr] = (entries, markers, len(empty_refs))
        log("önbellek: %s -> %d satır, %d marker, %d yer tutucu"
            % (rootstr, entries, markers, len(empty_refs)))

    def _ensure(self, rootstr):
        if rootstr not in self._stats:
            self._build(rootstr)

    @staticmethod
    def _at(array, index):
        if not array or index < 0:
            return 0
        if index >= len(array):
            return array[-1]
        return array[index]

    def deltaAt(self, rootstr, index):
        """Görüntü indeksi `index` olan satırın numarasına eklenecek fark."""
        if not cfg.enabled.value:
            return 0
        self._ensure(rootstr)
        if hiding():
            return self._at(self._hidden.get(rootstr), index)
        return self._at(self._visible.get(rootstr), index)

    def hiddenBefore(self, rootstr, index):
        """
        Görüntü indeksi `index` olan satırdan önce gizlenen yer tutucu sayısı.
        Görüntü indeksini buke indeksine çevirmek için kullanılır.
        """
        if not hiding():
            return 0
        self._ensure(rootstr)
        return self._at(self._hidden.get(rootstr), index)

    def emptyMarkerRefs(self, rootstr):
        """Gizlenecek yer tutucuların referans dizeleri."""
        self._ensure(rootstr)
        return self._empty.get(rootstr, [])

    def stats(self, rootstr):
        """(satır sayısı, marker sayısı, yer tutucu sayısı)"""
        self._ensure(rootstr)
        return self._stats.get(rootstr, (0, 0, 0))


cache = RootCache()


# ------------------------------------------------------------------- önizleme

def serviceName(ref):
    try:
        info = eServiceCenter.getInstance().info(ref)
        return (info and info.getName(ref)) or ""
    except Exception:
        return ""


def previewNumbering(rootstr, offset=0, limit=14):
    """
    Ayar ekranındaki canlı önizleme: bukenin ilk satırlarını, o an geçerli
    kurala göre numaralandırılmış olarak döndürür.
    """
    lines = []
    entries = listRoot(rootstr)
    if not entries:
        return [_("liste boş")]
    number = offset
    for ref in entries:
        if len(lines) >= limit:
            break
        if isMarker(ref):
            name = markerName(ref)
            if name:
                lines.append("       -- %s --" % name)
            elif countsAsChannel(ref):
                number += 1
                lines.append("%4d.  %s" % (number, _("(gizli yer tutucu)")
                                           if hiding() else _("(yer tutucu)")))
            else:
                lines.append("       %s" % _("(yer tutucu, numarasız)"))
            continue
        if ref.flags & eServiceReference.isDirectory:
            continue
        number += 1
        lines.append("%4d.  %s" % (number, serviceName(ref)))
    return lines
