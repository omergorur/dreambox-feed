# MarkerNumbering

DreamOS kanal listesi numaralandırmasını OpenATV davranışına getirir:
adsız marker'lar numara rezerve eder ve istenirse her buke 1'den başlar.

DreamOS'ta kanal listesindeki **marker'lar hiçbir zaman kanal numarası
tüketmez**. OpenATV / OpenPLi / VTi gibi diğer enigma2 imajlarında ise
**adsız** marker bir numarayı rezerve eder (yer tutucu), **adlı** marker
(bölüm başlığı) etmez:

```
   1. TRT 1                    22. KANAL D
   2. ATV                      23. NOW
   (3 ayrılmış, satır yok)     ── spor kanalları ──
   4. SHOW TV                  24. TRT SPOR
```

Bu eklenti aynı davranışı DreamOS'a kazandırır. Sistem dosyalarına dokunmaz.

## Neyi düzeltir

| Yer | Stok DreamOS | Bu eklenti ile |
|---|---|---|
| Kanal listesindeki numara | adsız marker atlanır | numarayı rezerve eder |
| Numara ile zaplama (`24`) | marker sayılmaz | marker sayılır |
| Çoklu bukede numara ofseti | marker sayılmaz | marker sayılır |
| Yer tutucu satırı | `<n/a>` + ikon, yer kaplar | listede hiç görünmez |
| Infobar'daki kanal numarası (tema renderer'ı) | marker sayılmaz | marker sayılır |
| Her bukede 1'den başlama | **seçenek yok** | ayardan açılır |

## Nasıl çalışır

DreamOS'ta liste numarası **Python tarafında** hesaplanır
(`Components/ServiceList.py:392`):

```python
markers_before = self.l.getNumMarkersBeforeCurrent()
text = "%d" % (self.numberoffset + index + 1 - markers_before)
```

C++ `getNumMarkersBeforeCurrent()` imleçten önceki **tüm** marker'ları sayar
ve bu sayı numaradan düşülür — bu yüzden hiçbir marker numara tüketmez.

Eklenti bu metodu sarmalayıp yalnızca **adlı** marker'ları döndürür. Kilit
gözlem: imleçten önce M marker varsa, bunlar bukedeki marker dizisinin ilk M
öğesidir. Yani indeks eşlemesi yapmaya gerek yoktur — buke başına
`prefix[i] = ilk i marker içindeki adsız marker sayısı` dizisi yeter ve sorgu
O(1)'dir (`numbering.py`).

Numaranın tüketildiği diğer iki nokta da Python'dadır ve aynı biçimde
sarmalanır:

- `Screens/InfoBarGenerics.py` → `InfoBarNumberZap.searchNumberHelper`
- `Screens/ChannelSelection.py` → `ChannelSelectionBase.getBouquetNumOffset`

Temaların kendi numara göstergeleri (`SuissChannelNumber`, `FlowChNumber`,
`SaberChNumber`, `ExtChNumber`) numarayı kendileri sayar. Bu modüller import
anında `InfoBar.instance`'a baktığı için oturum başında yüklenemezler; bunun
yerine skin motorunun içe aktarıcısı (`skin.my_import`, `skin.py:1064`)
sarmalanır ve renderer yüklendiği anda yamalanır.

Düzeltme **mutlak** yapılır: renderer'ın ürettiği sayıya fark eklenmez, kanal
listesinin seçili satırda gösterdiği numaranın aynısı hesaplanıp atanır. Bunun
sebebi, bu renderer'ların gövdesinin tümüyle `if not self.suspended:` içinde
olmasıdır (`Renderer.onHide` -> `suspended = True`): infobar gizliyken
`changed()` metni yeniden hesaplamaz, olduğu gibi bırakır. Fark eklemek, o
çağrılarda zaten düzeltilmiş değeri ikinci kez düzeltirdi. Ayrıca gizliyken
hiç dokunulmaz. Metin düz sayı değilse (ör. `ExtChNumber`'ın `$number $name`
biçimi) dokunulmaz.

`Renderer.onShow()` da sarmalanır: stok hâli yalnızca `suspended`'ı düşürür,
yeniden hesaplamaz. Bu yüzden ekran açıldığında metin bir önceki kanaldan
kalma olur ve ilk kaynak olayına kadar (1-2 sn) öyle görünür; görünür olur
olmaz bir kez hesaplatılır.

### Satırların gizlenmesi

Yer tutucular kanal listesinde `<n/a>` olarak yer kaplar. Bunları gizlemenin
tek yolu, doldurulduktan sonra **görüntü listesinden** çıkarmaktır
(`eListboxServiceContent.removeCurrent`). Buke dosyası değişmez;
`eServiceCenter.list()` onları vermeye devam eder, dolayısıyla numaralama,
zaplama ve buke ofseti hesapları etkilenmez.

Bunun iki yan etkisi vardır ve ikisi de karşılanır:

- **Taşıma kipi**: C++ `setCurrentMarked(False)` sırasında hedef konumu
  `cursorGet()` ile GÖRÜNTÜ indeksinden alır. Gizli satır varsa buke sırası
  bozulur — bu yüzden taşıma kipi boyunca yer tutucular gösterilir.
- **Yeniden adlandırma**: `renameEntry` `bouquet.moveService(cur, idx)` için
  yine görüntü indeksini kullanır; çağrı boyunca `getCurrentIndex()`
  düzeltilmiş (buke) indeksi döndürür.

Ayrıca C++ `removeCurrent()` listbox bağlı değilken hiçbir şey yapmaz; bu
yüzden gizleme hem `setRoot` sonrasında hem de `postWidgetCreate` sonrasında
denenir (işlem etkisizdir).

Yamaların tamamı geri alınabilir (`patcher.unpatchAll`).

## Her bukede 1'den başlama

OpenATV / OpenPLi'de bulunan "numbering mode" seçeneğinin DreamOS'ta karşılığı
yoktur -- `config.usage`'da yalnızca `multibouquet` vardır, C++ tarafında da
`setNumberingMode` gibi bir çengel bulunmaz. Numaralandırma tümüyle Python'da
yapıldığı için bu seçenek eklenti içinden verilebiliyor:

- `getBouquetNumOffset()` bu kipte 0 döner -- hem liste numaraları hem tema
  renderer'ları önceki bukeleri saymayı bırakır.
- `InfoBarNumberZap.zapToNumber()` numarayı bukeler boyunca değil, yalnızca
  **açık bukede** arar. Açık buke sırasıyla şuradan bulunur: kanal listesinin
  kökü, gezinme yolundaki son buke, çalan servisi içeren buke, ilk buke.

Bu iki nokta zaten marker numaralandırması için de yamalandığından ayrı bir
eklenti yapmak yerine buraya konuldu; iki eklenti aynı fonksiyonları
sarmalasaydı sarmalama ve geri alma sırası kırılgan olurdu.

## Yer tutucu ekleme

Kanal listesinde **Menü** → *boş numara ayır (yer tutucu)*. Seçili satırın
üstüne adsız bir marker eklenir. Elle de yapılabilir: *add marker* deyip adı
tümüyle silmek yeterlidir.

Yer tutucular gizliyken seçilemezler; silmek ya da taşımak için
**Menü** → *yer tutucuları göster* ile geçici olarak görünür yapın
(taşıma kipi bunu kendiliğinden yapar).

Buke dosyasında yer tutucu şuna benzer:

```
#SERVICE 1:64:0:0:0:0:0:0:0:0::
```

OpenATV'nin ürettiği `#SERVICE 1:832:D:0:0:0:0:0:0:0:` biçimindeki gizli
numaralı marker'lar da tanınır (832 & 64 = marker, adı yok), yani OpenATV'den
alınan bukeler doğrudan doğru numaralanır.

## Ayarlar

Menü → Eklentiler → **Kanal Numaralandırma**

| Ayar | Anlamı |
|---|---|
| Eklenti etkin | Eklentiyi tümüyle açar/kapatır |
| Numaralandırma | bukeler boyunca sürsün / her bukede 1'den başlasın |
| Yer tutucuları listede gizle | satır hiç çizilmesin (varsayılan) |
| Görünürken yer tutucu satırı | boş satır / ayrılan numara / çizgi |
| Ayrılmış numara tuşlanırsa | hiçbir şey yapma / sonraki gerçek kanala geç |
| Tema numara göstergelerini de düzelt | infobar numarası listeyle uyuşsun |
| Kanal listesi menüsüne girdi ekle | bağlam menüsündeki "boş numara ayır" |

Ekranda ayrıca **canlı durum** vardır: uygulanan yamalar, açık bukedeki
marker sayıları ve numaralandırma önizlemesi.

## Teşhis

Kutuda, enigma2 çalışmasa bile:

```sh
python /usr/lib/enigma2/python/Plugins/Extensions/MarkerNumbering/tools/bouquet_dump.py
```

Her satırı hem DreamOS hem OpenATV numarasıyla yazar, farkları işaretler.
`--perbouquet` ile her bukeyi 1'den başlatarak gösterir.

## Kurulum

```sh
dpkg -i enigma2-plugin-extensions-markernumbering_1.3r-2_all.deb
killall -9 enigma2
```

Kaldırma:

```sh
dpkg -r enigma2-plugin-extensions-markernumbering
```

## Dosyalar

| Dosya | İş |
|---|---|
| `plugin.py` | PluginDescriptor'lar, bağlam menüsü girdisi |
| `settings.py` | `config.plugins.markernumbering` |
| `numbering.py` | marker tespiti, satır farkı önbelleği, önizleme |
| `patcher.py` | geri alınabilir çalışma zamanı yamaları |
| `ui.py` | ayar + canlı durum ekranı |
| `tools/bouquet_dump.py` | kutuda çalışan teşhis betiği |

Birim testler geliştirme makinesinde: `python _tools/test_numbering.py`
(enigma2 sahtelenir, eklentinin gerçek kodu yamalanıp doğrulanır).
