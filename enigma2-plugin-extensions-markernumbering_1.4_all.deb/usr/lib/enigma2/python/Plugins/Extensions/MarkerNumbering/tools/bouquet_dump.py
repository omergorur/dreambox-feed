# -*- coding: utf-8 -*-
"""
Buke dosyalarını doğrudan okuyup numaralandırmayı gösterir.

enigma2 çalışmadan da kullanılabilir (telnet üzerinden):

    python /usr/lib/enigma2/python/Plugins/Extensions/MarkerNumbering/tools/bouquet_dump.py
    python .../bouquet_dump.py --radio
    python .../bouquet_dump.py --limit 40 userbouquet.favourites.tv
    python .../bouquet_dump.py --perbouquet      # her buke 1'den başlasın

Her satır iki numarayla yazılır:
    DOS  = DreamOS'un stok davranışı (hiçbir marker numara tüketmez)
    ATV  = OpenATV davranışı (adsız marker numarayı rezerve eder)
Fark eden satırlar '<<' ile işaretlenir.
"""
import os
import re
import sys

E2DIR = "/etc/enigma2"
MARKER_FLAG = 64
DIRECTORY_FLAG = 1

_SERVICE = re.compile(r"^#SERVICE\s+(.*)$")
_DESCRIPTION = re.compile(r"^#DESCRIPTION[:\s]\s*(.*)$")
_BOUQUETFILE = re.compile(r'FROM BOUQUET "([^"]+)"')


def _decode(raw):
    if isinstance(raw, bytes):
        for enc in ("utf-8", "iso-8859-9", "latin-1"):
            try:
                return raw.decode(enc)
            except UnicodeDecodeError:
                continue
        return raw.decode("latin-1", "replace")
    return raw


def refFlags(ref):
    parts = ref.split(":")
    if len(parts) < 2:
        return 0
    try:
        return int(parts[1])
    except ValueError:
        return 0


def refName(ref):
    """toString biçimi: type:flags:data0..data7:path[:name]"""
    parts = ref.split(":")
    if len(parts) > 11:
        return ":".join(parts[11:]).strip()
    return ""


def readBouquet(path):
    """[(ref, ad)] döndürür."""
    entries = []
    pending = None
    try:
        fh = open(path, "rb")
    except IOError as e:
        print("  ! açılamadı: %s" % e)
        return entries
    try:
        for raw in fh:
            line = _decode(raw).rstrip("\r\n")
            m = _SERVICE.match(line)
            if m:
                if pending is not None:
                    entries.append(pending)
                pending = [m.group(1).strip(), None]
                continue
            m = _DESCRIPTION.match(line)
            if m and pending is not None:
                pending[1] = m.group(1).strip()
    finally:
        fh.close()
    if pending is not None:
        entries.append(pending)
    return [(ref, name if name is not None else refName(ref))
            for ref, name in entries]


def bouquetList(radio=False):
    """bouquets.tv / bouquets.radio içindeki userbouquet dosya adları."""
    root = os.path.join(E2DIR, "bouquets.radio" if radio else "bouquets.tv")
    names = []
    for ref, _name in readBouquet(root):
        m = _BOUQUETFILE.search(ref)
        if m:
            names.append(m.group(1))
    return names


def dump(filename, dos, atv, limit):
    """(dos, atv) sayaçlarını ilerletip satırları yazar."""
    path = os.path.join(E2DIR, filename)
    entries = readBouquet(path)
    print("")
    print("=== %s  (%d satır) ===" % (filename, len(entries)))
    shown = 0
    diff = 0
    for ref, name in entries:
        flags = refFlags(ref)
        if flags & DIRECTORY_FLAG:
            continue
        if flags & MARKER_FLAG:
            if name:
                if shown < limit:
                    print("       %-6s %-6s -- %s --" % ("", "", name))
                    shown += 1
                continue
            atv += 1                       # adsız marker: ATV numara ayırır
            if shown < limit:
                print("       %-6s %-6d (yer tutucu)" % ("-", atv))
                shown += 1
            diff += 1
            continue
        dos += 1
        atv += 1
        if shown < limit:
            mark = " <<" if dos != atv else ""
            print("       %-6d %-6d %s%s" % (dos, atv, name or ref[:40], mark))
            shown += 1
    if shown >= limit and len(entries) > shown:
        print("       ... (%d satır daha)" % (len(entries) - shown))
    if diff:
        print("       -> bu bukede %d adsız marker var; "
              "sonraki numaralar %d kayıyor" % (diff, atv - dos))
    return dos, atv


def main(argv):
    global E2DIR
    radio = "--radio" in argv
    perbouquet = "--perbouquet" in argv
    argv = [a for a in argv if a not in ("--radio", "--perbouquet")]
    if "--dir" in argv:                    # geliştirme makinesinde denemek için
        i = argv.index("--dir")
        try:
            E2DIR = argv[i + 1]
            del argv[i:i + 2]
        except IndexError:
            pass
    limit = 30
    if "--limit" in argv:
        i = argv.index("--limit")
        try:
            limit = int(argv[i + 1])
        except (IndexError, ValueError):
            pass
        del argv[i:i + 2]

    files = argv[1:] or bouquetList(radio)
    if not files:
        print("buke bulunamadı (%s)" % E2DIR)
        return 1

    print("Sütunlar: DOS = DreamOS stok, ATV = OpenATV (bu eklentinin verdiği)")
    dos = atv = 0
    total_dos = total_atv = 0
    for name in files:
        if perbouquet:
            dos = atv = 0
        before_dos, before_atv = dos, atv
        dos, atv = dump(name, dos, atv, limit)
        total_dos += dos - before_dos
        total_atv += atv - before_atv
    print("")
    if perbouquet:
        print("Kip: her buke 1'den başlar")
    print("Toplam: DreamOS %d numara, OpenATV %d numara" % (total_dos, total_atv))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
