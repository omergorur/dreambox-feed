# -*- coding: utf-8 -*-
#
# MarkerNumbering - çalışma zamanı yamaları
#
# Sistem dosyalarına dokunulmaz; ilgili sınıflar çalışırken sarmalanır.
# Her yama geri alınabilir (unpatchAll).
#
# Numaranın hesaplandığı/tüketildiği yerler -- hepsi Python:
#
#   Components/ServiceList.py:392        listede gösterilen numara
#   ChannelSelectionPlus ServiceListOwn  aynı formülün tema kopyası
#   Screens/InfoBarGenerics.py:313       numara ile zaplama
#   Screens/ChannelSelection.py:923      önceki bukelerin numara ofseti
#   Components/Renderer/*ChNumber.py     infobar numarası
#
# Liste numarası için `numberoffset` bir property'ye çevrilir: okunduğu tek
# yer çizim fonksiyonudur ve orada imleç çizilen satırdadır, dolayısıyla
# satıra özel fark eklenebilir. Böylece stok formüle hiç dokunulmaz ve
# ServiceList'in tema alt sınıfları (ServiceListOwn) da kapsanır.
#
import sys

from Components.config import config
from enigma import eServiceReference, eServiceCenter, eListboxServiceContent, \
    eListboxPythonMultiContent, eDVBDB

from .settings import cfg
from .numbering import cache, countsAsChannel, hiding, isEmptyMarker, \
    markerName, perBouquet, serviceName, log

try:
    _
except NameError:
    def _(txt):
        return txt

# uygulanan yamalar: (etiket, geri_alma_fonksiyonu)
_patches = []
_status = {}

TYPE_TEXT = eListboxPythonMultiContent.TYPE_TEXT

# ServiceList adsız marker için servis adı bulamaz ve bu sabiti yazar
NA_TEXT = "<n/a>"
DASH_TEXT = "———"

# Liste yeniden doldurulurken gizlemeyi geçici olarak kapatmak için
_suppressHide = [False]


def patchStatus():
    """Ayar ekranında gösterilecek durum sözlüğü."""
    return dict(_status)


def _register(label, undo):
    _patches.append((label, undo))


def _rootstr(servicelist):
    root = getattr(servicelist, "root", None)
    return root.toString() if root is not None else None


# ------------------------------------------ 1) satıra özel numara farkı

def _patchNumberOffset():
    """
    ServiceList.numberoffset -> property.

    Okuyucu: `numberoffset + index + 1 - markers_before`. Getter, çizilen
    satırın görüntü indeksine karşılık gelen farkı ekler.
    """
    from Components.ServiceList import ServiceList

    original = ServiceList.__dict__.get("numberoffset")

    def getter(self):
        base = self.__dict__.get("_mn_base", 0)
        if not cfg.enabled.value:
            return base
        try:
            rootstr = _rootstr(self)
            if not rootstr:
                return base
            return base + cache.deltaAt(rootstr, self.getCurrentIndex())
        except Exception as e:
            log("numara farkı hesaplanamadı: %s" % e)
            return base

    def setter(self, value):
        self.__dict__["_mn_base"] = value

    ServiceList.numberoffset = property(getter, setter)

    def undo():
        if original is None:
            try:
                del ServiceList.numberoffset
            except AttributeError:
                pass
        else:
            ServiceList.numberoffset = original

    _register("ServiceList.numberoffset", undo)
    return True


# ------------------------------------------ 2) yer tutucu satırlarını gizle

def _removePlaceholders(servicelist):
    """
    Yer tutucuları GÖRÜNTÜ listesinden çıkarır. Buke dosyası değişmez;
    eServiceCenter.list() onları vermeye devam eder, dolayısıyla numaralama,
    zaplama ve buke ofseti hesapları etkilenmez.
    """
    rootstr = _rootstr(servicelist)
    if not rootstr:
        return 0
    refs = cache.emptyMarkerRefs(rootstr)
    if not refs:
        return 0
    content = servicelist.l
    saved = servicelist.getCurrent()
    removed = 0
    for refstr in refs:
        ref = eServiceReference(refstr)
        content.setCurrent(ref)
        current = eServiceReference()
        content.getCurrent(current)
        if current.valid() and current == ref and isEmptyMarker(current):
            content.removeCurrent()
            removed += 1
    if saved is not None and saved.valid() and not isEmptyMarker(saved):
        servicelist.setCurrent(saved)
    if removed:
        try:
            servicelist.selectionChanged()
        except Exception:
            pass
        log("%d yer tutucu gizlendi (%s)" % (removed, rootstr))
    return removed


def _refill(servicelist, hide):
    """Listeyi yeniden doldurur; `hide` yanlışsa yer tutucular görünür kalır."""
    root = getattr(servicelist, "root", None)
    if root is None:
        return
    saved = servicelist.getCurrent()
    _suppressHide[0] = not hide
    try:
        servicelist.setRoot(root)
    finally:
        _suppressHide[0] = False
    if saved is not None and saved.valid():
        servicelist.setCurrent(saved)


def _patchSetRoot():
    """Liste her dolduğunda yer tutucuları çıkar."""
    from Components.ServiceList import ServiceList

    orig = ServiceList.setRoot

    def setRoot(self, root, justSet=False):
        try:
            cache.invalidate(root.toString() if root is not None else None)
        except Exception:
            pass
        result = orig(self, root, justSet)
        # justSet=True iken C++ listeyi hiç doldurmaz
        if not justSet and hiding() and not _suppressHide[0]:
            try:
                _removePlaceholders(self)
            except Exception as e:
                log("yer tutucular gizlenemedi: %s" % e)
        return result

    # Emniyet ağı: C++ removeCurrent() listbox bağlı değilken hiçbir şey
    # yapmaz. setRoot widget kurulmadan önce çağrıldıysa gizleme başarısız
    # olur; içerik listbox'a bağlanır bağlanmaz yeniden dener.
    # (İşlem etkisizdir: zaten çıkarılmış satır bulunamaz, atlanır.)
    orig_post = ServiceList.postWidgetCreate

    def postWidgetCreate(self, instance):
        result = orig_post(self, instance)
        if hiding() and not _suppressHide[0] and getattr(self, "root", None):
            try:
                _removePlaceholders(self)
            except Exception as e:
                log("widget sonrası gizleme başarısız: %s" % e)
        return result

    ServiceList.setRoot = setRoot
    ServiceList.postWidgetCreate = postWidgetCreate

    def undo():
        ServiceList.setRoot = orig
        ServiceList.postWidgetCreate = orig_post

    _register("ServiceList.setRoot", undo)
    return True


# ------------------------------------------ 3) görünür kipte yer tutucu satırı

def _decoratePlaceholderRow(servicelist, service, res):
    """Yer tutucu satırındaki "<n/a>" metnini ayara göre değiştirir/siler."""
    mode = cfg.placeholder.value
    if mode == "number":
        text = "%d" % (servicelist.numberoffset + servicelist.getCurrentIndex()
                       + 1 - servicelist.l.getNumMarkersBeforeCurrent())
    elif mode == "dash":
        text = DASH_TEXT
    else:
        text = None
    # ServiceList ad sütununa şunu yazar: info.getName(ref) or "<n/a>"
    label = serviceName(service) or NA_TEXT
    out = [res[0]]
    replaced = False
    for entry in res[1:]:
        if (not replaced and entry and entry[0] == TYPE_TEXT
                and len(entry) > 7 and entry[7] == label):
            replaced = True
            if text is None:
                continue                        # satırı boş bırak
            entry = tuple(entry[:7]) + (text,) + tuple(entry[8:])
        out.append(entry)
    return out


def _wrapBuildFunc(func):
    owner = getattr(func, "__self__", None) or getattr(func, "im_self", None)

    def wrapped(service, *args, **kwargs):
        res = func(service, *args, **kwargs)
        if not cfg.enabled.value or hiding() or owner is None:
            return res                          # gizliyse satır zaten yok
        try:
            if isEmptyMarker(service):
                return _decoratePlaceholderRow(owner, service, res)
        except Exception as e:
            log("yer tutucu satırı çizilemedi: %s" % e)
        return res

    wrapped._mn_wrapped = True
    return wrapped


def _patchBuildFunc():
    """
    Çizim fonksiyonunu sınıf düzeyinde değil, kurulduğu yerde sarmalarız
    (ServiceList.__init__ -> self.l.setBuildFunc). Böylece temaların kendi
    ServiceList alt sınıfları da (ör. ChannelSelectionPlus.ServiceListOwn,
    buildOptionEntry'yi tümüyle override eder) kapsanır.
    """
    orig = eListboxServiceContent.setBuildFunc

    def setBuildFunc(self, func, *args):
        if func is not None and not getattr(func, "_mn_wrapped", False):
            try:
                func = _wrapBuildFunc(func)
            except Exception as e:
                log("çizim fonksiyonu sarmalanamadı: %s" % e)
        return orig(self, func, *args)

    eListboxServiceContent.setBuildFunc = setBuildFunc
    _register("eListboxServiceContent.setBuildFunc",
              lambda: setattr(eListboxServiceContent, "setBuildFunc", orig))
    return True


# ------------------------------------------ 4) düzenlemede önbellek / görünürlük

def _patchListEdits():
    """Listeye satır eklenip çıkarıldığında önbelleği düşür."""
    from Components.ServiceList import ServiceList

    orig_add = ServiceList.addService
    orig_del = ServiceList.removeCurrent

    def invalidate(self):
        try:
            cache.invalidate(_rootstr(self))
        except Exception:
            pass

    def addService(self, service, beforeCurrent=False):
        invalidate(self)
        return orig_add(self, service, beforeCurrent)

    def removeCurrent(self):
        invalidate(self)
        return orig_del(self)

    ServiceList.addService = addService
    ServiceList.removeCurrent = removeCurrent

    def undo():
        ServiceList.addService = orig_add
        ServiceList.removeCurrent = orig_del

    _register("ServiceList düzenleme", undo)
    return True


def _patchReloadBouquets():
    """Bukeler yeniden yüklendiğinde (dışarıdan yükleme, tarama) her şeyi düşür."""
    orig = eDVBDB.reloadBouquets

    def reloadBouquets(self, *args):
        cache.clear()
        return orig(self, *args)

    eDVBDB.reloadBouquets = reloadBouquets
    _register("eDVBDB.reloadBouquets",
              lambda: setattr(eDVBDB, "reloadBouquets", orig))
    return True


def _patchMoveMode():
    """
    Taşıma kipinde C++ `setCurrentMarked(False)` sırasında hedef konumu
    GÖRÜNTÜ indeksinden alır (cursorGet). Gizli satır varsa buke sırası
    bozulur; bu yüzden taşıma kipi boyunca yer tutucular gösterilir --
    kullanıcı zaten onları da konumlandırabilmelidir.
    """
    from Screens.ChannelSelection import ChannelSelectionEdit

    orig = ChannelSelectionEdit.toggleMoveMode

    def toggleMoveMode(self):
        entering = not self.movemode
        active = hiding()
        if entering and active:
            _refill(self.servicelist, False)
        result = orig(self)
        if not entering and active:
            _refill(self.servicelist, True)
        return result

    ChannelSelectionEdit.toggleMoveMode = toggleMoveMode
    _register("ChannelSelectionEdit.toggleMoveMode",
              lambda: setattr(ChannelSelectionEdit, "toggleMoveMode", orig))
    return True


def _patchRenameEntry():
    """
    renameEntry, `bouquet.moveService(cur, idx)` için görüntü indeksini
    kullanır. Gizli satır varsa bu indeks buke indeksinden küçüktür ve
    yeniden adlandırılan kanal listede yukarı kayar. Çağrı boyunca
    getCurrentIndex() düzeltilmiş değeri döndürür.
    """
    from Screens.ChannelSelection import ChannelSelectionEdit

    orig = ChannelSelectionEdit.renameEntry

    def renameEntry(self, name):
        servicelist = self.servicelist
        if not hiding():
            return orig(self, name)
        real = servicelist.getCurrentIndex

        def corrected():
            index = real()
            try:
                return index + cache.hiddenBefore(_rootstr(servicelist), index)
            except Exception:
                return index

        servicelist.getCurrentIndex = corrected
        try:
            return orig(self, name)
        finally:
            try:
                del servicelist.getCurrentIndex
            except AttributeError:
                pass

    ChannelSelectionEdit.renameEntry = renameEntry
    _register("ChannelSelectionEdit.renameEntry",
              lambda: setattr(ChannelSelectionEdit, "renameEntry", orig))
    return True


# ------------------------------------------ 5) numara ile zaplama

def _patchNumberZap():
    """
    Stok searchNumberHelper adsız marker'ı atlar. Yerine, adsız marker'ın da
    bir numara tükettiği bir arama koyulur.

    Rezerve edilmiş ama boş bir numara tuşlanırsa ayara göre ya hiçbir şey
    yapılmaz (servis None döner) ya da sonraki gerçek kanala geçilir.
    """
    from Screens.InfoBarGenerics import InfoBarNumberZap

    orig = InfoBarNumberZap.searchNumberHelper

    def searchNumberHelper(self, serviceHandler, num, bouquet):
        if not cfg.enabled.value:
            return orig(self, serviceHandler, num, bouquet)
        try:
            servicelist = serviceHandler.list(bouquet)
        except Exception as e:
            log("buke listelenemedi: %s" % e)
            return None, num
        if servicelist is None:
            return None, num

        found = None
        while num:
            ref = servicelist.getNext()
            if not ref.valid():
                break
            flags = ref.flags
            if flags & eServiceReference.isDirectory:
                continue
            if flags & eServiceReference.isMarker:
                if markerName(ref):
                    continue                # adlı marker: numara tüketmez
                num -= 1                    # adsız marker: numarayı rezerve eder
                if not num:
                    found = None
                continue
            num -= 1
            if not num:
                found = ref

        if num:                             # bu bukede bulunamadı
            return None, num

        if found is None and cfg.reserved_zap.value == "next":
            while True:
                ref = servicelist.getNext()
                if not ref.valid():
                    break
                if not (ref.flags & (eServiceReference.isDirectory
                                     | eServiceReference.isMarker)):
                    found = ref
                    break

        return found, 0

    InfoBarNumberZap.searchNumberHelper = searchNumberHelper
    _register("InfoBarNumberZap.searchNumberHelper",
              lambda: setattr(InfoBarNumberZap, "searchNumberHelper", orig))
    return True


# ------------------------------------------ 6) önceki bukelerin ofseti

def _patchBouquetOffset():
    """
    Çoklu buke modunda numaralandırma bukeler boyunca sürer. Stok kod önceki
    bukelerdeki 'playable' satırları sayar; adsız marker'lar da sayılmalıdır,
    yoksa ikinci bukeden itibaren numaralar kayar.
    """
    from Screens.ChannelSelection import ChannelSelectionBase

    orig = ChannelSelectionBase.getBouquetNumOffset

    def getBouquetNumOffset(self, bouquet):
        if not cfg.enabled.value:
            return orig(self, bouquet)
        if perBouquet():
            return 0                    # her buke 1'den başlar
        if not config.usage.multibouquet.value:
            return 0
        key = bouquet.toString()
        offsetCount = 0
        if key not in self.bouquetNumOffsetCache:
            serviceHandler = eServiceCenter.getInstance()
            bouquetlist = serviceHandler.list(self.bouquet_root)
            if bouquetlist is not None:
                while True:
                    bouquetIterator = bouquetlist.getNext()
                    if not bouquetIterator.valid():
                        break
                    self.bouquetNumOffsetCache[bouquetIterator.toString()] = offsetCount
                    if not (bouquetIterator.flags & eServiceReference.isDirectory):
                        continue
                    servicelist = serviceHandler.list(bouquetIterator)
                    if servicelist is not None:
                        while True:
                            serviceIterator = servicelist.getNext()
                            if not serviceIterator.valid():
                                break
                            if countsAsChannel(serviceIterator):
                                offsetCount += 1
        return self.bouquetNumOffsetCache.get(key, offsetCount)

    ChannelSelectionBase.getBouquetNumOffset = getBouquetNumOffset
    _register("ChannelSelectionBase.getBouquetNumOffset",
              lambda: setattr(ChannelSelectionBase,
                              "getBouquetNumOffset", orig))
    return True


# ------------------------------------------ 6b) her bukede 1'den başlama

def _isUserBouquet(ref):
    if ref is None:
        return False
    try:
        if not (ref.flags & eServiceReference.isDirectory):
            return False
    except Exception:
        return False
    path = ""
    try:
        path = ref.getPath() or ""
    except Exception:
        path = ""
    if not path:
        try:
            path = ref.toString()
        except Exception:
            return False
    return 'FROM BOUQUET "userbouquet' in path


def _bouquetOfPlayingService(csel):
    """Çalan servisi içeren bukeyi arar (liste bir bukede değilse yedek yol)."""
    try:
        import NavigationInstance
        playing = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
    except Exception:
        playing = None
    handler = eServiceCenter.getInstance()
    try:
        bouquetlist = handler.list(csel.bouquet_root)
    except Exception:
        return None
    if bouquetlist is None:
        return None
    first = None
    while True:
        bouquet = bouquetlist.getNext()
        if not bouquet.valid():
            break
        if not (bouquet.flags & eServiceReference.isDirectory):
            continue
        if first is None:
            first = bouquet
        if playing is None or not playing.valid():
            continue
        services = handler.list(bouquet)
        if services is None:
            continue
        while True:
            service = services.getNext()
            if not service.valid():
                break
            if service == playing:
                return bouquet
    return first


def _activeBouquet(csel):
    """Numara ile zaplamada kullanılacak buke."""
    try:
        root = csel.getRoot()
    except Exception:
        root = None
    if _isUserBouquet(root):
        return root
    try:
        for ref in reversed(list(getattr(csel, "servicePath", None) or [])):
            if _isUserBouquet(ref):
                return ref
    except Exception:
        pass
    return _bouquetOfPlayingService(csel)


def _patchZapToNumber():
    """
    Stok zapToNumber numarayı bukeler boyunca arar. 'Her bukede 1'den başla'
    kipinde arama yalnızca açık bukede yapılmalıdır.
    """
    from Screens.InfoBarGenerics import InfoBarNumberZap

    orig = InfoBarNumberZap.zapToNumber

    def zapToNumber(self, number):
        if not perBouquet():
            return orig(self, number)
        csel = self.servicelist
        bouquet = _activeBouquet(csel)
        if bouquet is None:
            return orig(self, number)
        service, remaining = self.searchNumberHelper(
            eServiceCenter.getInstance(), number, bouquet)
        if service is None or remaining:
            return
        if csel.getRoot() != bouquet:
            csel.clearPath()
            if csel.bouquet_root != bouquet:
                csel.enterPath(csel.bouquet_root)
            csel.enterPath(bouquet)
        csel.setCurrentSelection(service)
        csel.zap()

    InfoBarNumberZap.zapToNumber = zapToNumber
    _register("InfoBarNumberZap.zapToNumber",
              lambda: setattr(InfoBarNumberZap, "zapToNumber", orig))
    return True


# ------------------------------------------ 7) tema kanal numarası göstergeleri

# Bu renderer'lar numarayı kendileri sayar: getCurrentIndex() alır, kendi
# marker sayımını çıkarır, getBouquetNumOffset() ekler. Ürettikleri düz sayıya
# aynı satır farkını ekleriz.
_NUMBER_RENDERERS = ("SuissChannelNumber", "FlowChNumber", "SaberChNumber",
                     "ExtChNumber")

_patchedRenderers = {}


def _listNumberForSelection():
    """
    Kanal listesinin SEÇİLİ satırda gösterdiği numaranın aynısı.

    Çizim dışında içerik imleci seçili satırdadır, dolayısıyla listenin
    kullandığı formül burada da geçerlidir; `numberoffset` bizim property'miz
    olduğu için satır farkı zaten içindedir.
    """
    servicelist = currentServiceList()
    if servicelist is None or getattr(servicelist, "root", None) is None:
        return None
    try:
        return (servicelist.numberoffset + servicelist.getCurrentIndex() + 1
                - servicelist.l.getNumMarkersBeforeCurrent())
    except Exception as e:
        log("liste numarası hesaplanamadı: %s" % e)
        return None


def _wrapRenderer(cls):
    orig_changed = cls.changed
    orig_onShow = cls.onShow
    had_onShow = "onShow" in cls.__dict__

    def changed(self, what):
        orig_changed(self, what)
        if not (cfg.enabled.value and cfg.fix_renderers.value):
            return
        # Renderer'ın gövdesi tümüyle `if not self.suspended:` içindedir
        # (Renderer.onHide -> suspended = True). Gizliyken changed() metni
        # yeniden hesaplamaz, olduğu gibi bırakır; o anda düzeltme yapmak
        # zaten düzeltilmiş değeri ikinci kez düzeltmek olur.
        if getattr(self, "suspended", False):
            return
        try:
            text = self.text
            if not text:
                return
            text = text.strip()
            if not text.isdigit():
                return          # " " ya da "$number $name" gibi biçimler
            number = _listNumberForSelection()
            if number is None:
                return
            # Fark eklemek yerine MUTLAK değer atanır: aynı çağrı birden çok
            # kez gelse de sonuç değişmez.
            if text != str(number):
                self.text = str(number)
        except Exception as e:
            log("renderer düzeltilemedi: %s" % e)

    def onShow(self):
        # Renderer.onShow() yalnızca suspended'ı düşürür, yeniden hesaplamaz.
        # Bu yüzden ekran açıldığında metin bir önceki kanaldan kalma olabilir
        # ve ilk kaynak olayına kadar (1-2 sn) öyle görünür. Görünür olur olmaz
        # bir kez hesaplatıyoruz.
        orig_onShow(self)
        if not (cfg.enabled.value and cfg.fix_renderers.value):
            return
        try:
            self.changed((self.CHANGED_ALL,))
        except Exception as e:
            log("renderer gösterimde tazelenemedi: %s" % e)

    cls.changed = changed
    cls.onShow = onShow

    def undo():
        cls.changed = orig_changed
        if had_onShow:
            cls.onShow = orig_onShow
        else:
            try:
                del cls.onShow          # yine üst sınıfınki kullanılsın
            except AttributeError:
                pass

    return undo


def _maybePatchRenderer(module, name):
    if name not in _NUMBER_RENDERERS or name in _patchedRenderers:
        return
    cls = getattr(module, name, None)
    if cls is None or not hasattr(cls, "changed"):
        return
    try:
        _patchedRenderers[name] = _wrapRenderer(cls)
        log("renderer yamalandı: %s" % name)
    except Exception as e:
        log("%s yamalanamadı: %s" % (name, e))


def _patchChannelNumberRenderers():
    """
    Renderer modülleri import anında InfoBar.instance'a bakar; oturum başında
    henüz yoktur. Bu yüzden onları erkenden import etmek yerine skin motorunun
    içe aktarıcısı (skin.my_import, skin.py:1064) sarmalanır ve renderer
    yüklendiği anda yamalanır.
    """
    import skin

    orig = skin.my_import

    def my_import(name):
        module = orig(name)
        try:
            if name.startswith("Components.Renderer."):
                _maybePatchRenderer(module, name.rsplit(".", 1)[-1])
        except Exception as e:
            log("import kancası hatası: %s" % e)
        return module

    skin.my_import = my_import

    # Skin zaten yüklenmişse elde olanı yakala
    for name in _NUMBER_RENDERERS:
        module = sys.modules.get("Components.Renderer." + name)
        if module is not None:
            _maybePatchRenderer(module, name)

    def undo():
        skin.my_import = orig
        while _patchedRenderers:
            _name, restore = _patchedRenderers.popitem()
            try:
                restore()
            except Exception:
                pass

    _register("skin.my_import (renderer)", undo)
    return True


# --------------------------------------------------------------------- API

_TARGETS = (
    ("numberOffset", _patchNumberOffset),
    ("hidePlaceholders", _patchSetRoot),
    ("placeholderRow", _patchBuildFunc),
    ("listEdits", _patchListEdits),
    ("reloadBouquets", _patchReloadBouquets),
    ("moveMode", _patchMoveMode),
    ("renameEntry", _patchRenameEntry),
    ("numberZap", _patchNumberZap),
    ("bouquetOffset", _patchBouquetOffset),
    ("perBouquetZap", _patchZapToNumber),
    ("numberRenderers", _patchChannelNumberRenderers),
)


def patchAll():
    if _patches:
        return _status
    for label, fn in _TARGETS:
        try:
            _status[label] = "tamam" if fn() else "yok"
        except Exception as e:
            _status[label] = "hata: %s" % e
            print("[MarkerNumbering] %s yamalanamadı: %s" % (label, e))
    print("[MarkerNumbering] yamalar: %s" % _status)
    return _status


def unpatchAll():
    while _patches:
        label, undo = _patches.pop()
        try:
            undo()
        except Exception as e:
            print("[MarkerNumbering] %s geri alınamadı: %s" % (label, e))
    _status.clear()
    cache.clear()


def currentServiceList():
    """Açık kanal listesinin ServiceList bileşeni (yoksa None)."""
    try:
        from Screens.InfoBar import InfoBar
        instance = getattr(InfoBar, "instance", None)
        csel = instance and getattr(instance, "servicelist", None)
        return csel and getattr(csel, "servicelist", None)
    except Exception:
        return None


def refill(csel=None):
    """Verilen (ya da açık olan) kanal listesini yeniden doldurur."""
    if csel is not None:
        servicelist = getattr(csel, "servicelist", None)
    else:
        servicelist = currentServiceList()
    if servicelist is None:
        return
    try:
        _refill(servicelist, hiding())
    except Exception as e:
        log("liste tazelenemedi: %s" % e)


def refreshList():
    """Ayar değiştikten sonra açık listeyi yeniden kur."""
    cache.clear()
    try:
        from Screens.InfoBar import InfoBar
        instance = getattr(InfoBar, "instance", None)
        csel = instance and getattr(instance, "servicelist", None)
        for screen in (csel, getattr(csel, "radioTV", None)):
            if screen is not None and hasattr(screen, "bouquetNumOffsetCache"):
                screen.bouquetNumOffsetCache = {}
    except Exception as e:
        log("ofset önbelleği temizlenemedi: %s" % e)
    refill()


# Geriye dönük ad
dropOffsetCaches = refreshList
