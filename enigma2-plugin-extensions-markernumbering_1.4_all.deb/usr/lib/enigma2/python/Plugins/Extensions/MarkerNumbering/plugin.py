# -*- coding: utf-8 -*-
#
# MarkerNumbering
#
# DreamOS'ta kanal listesindeki marker'lar hiçbir zaman kanal numarası
# tüketmez. OpenATV / OpenPLi / VTi gibi diğer enigma2 imajlarında ise ADSIZ
# marker bir numarayı rezerve eder (yer tutucu), ADLI marker (bölüm başlığı)
# etmez:
#
#     1. TRT 1                     22. KANAL D
#     2. ATV                       23. NOW
#     3. <yer tutucu, gizli>       ── spor kanalları ──
#     4. SHOW TV                   24. TRT SPOR
#
# Bu eklenti aynı davranışı DreamOS'a kazandırır. Sistem dosyalarına
# dokunmaz; numaranın hesaplandığı Python noktalarını çalışma zamanında
# sarmalar (bkz. patcher.py).
#
# Kurulum:
#   /usr/lib/enigma2/python/Plugins/Extensions/MarkerNumbering/
#   ardından enigma2 yeniden başlatılır.
#
# Ayarlar: Menü > Eklentiler > Kanal Numaralandırma
#
VERSION = "1.4"

from Plugins.Plugin import PluginDescriptor

from .settings import cfg
from . import numbering
from . import patcher
from .ui import openSetup

# "yer tutucuları göster/gizle" girdisi; etiketi duruma göre güncellenir
_toggleDescriptor = None


def _log(msg):
    print("[MarkerNumbering] %s" % msg)


def sessionstart(reason, session=None, **kwargs):
    if reason == 0:
        if not cfg.enabled.value:
            _log("eklenti kapalı")
            return
        patcher.patchAll()
        _log("v%s başlatıldı" % VERSION)
    elif reason == 1:
        patcher.unpatchAll()


# ------------------------------------------------- kanal listesi bağlam menüsü

def _editableBouquet(csel):
    """Düzenlenebilir bir bukede miyiz?"""
    try:
        if not (cfg.enabled.value and cfg.context_menu.value):
            return False
        if getattr(csel, "movemode", False):
            return False
        if getattr(csel, "bouquet_mark_edit", 0):
            return False
        return csel.getMutableList() is not None
    except Exception as e:
        _log("bağlam menüsü kontrolü başarısız: %s" % e)
        return False


def _closeContextMenu(session):
    """ChannelContextMenu execPlugin'den sonra kendiliğinden kapanmaz."""
    try:
        from Screens.ChannelSelection import ChannelContextMenu
        dialog = getattr(session, "current_dialog", None)
        if isinstance(dialog, ChannelContextMenu):
            dialog.close(False)
    except Exception:
        pass


def _addHelper(csel):
    return _editableBouquet(csel)


def _addAction(session, service=None, csel=None, **kwargs):
    """Seçili satırın üstüne adsız bir marker (yer tutucu) ekler."""
    try:
        if csel is not None:
            csel.addMarker("")
            patcher.refill(csel)
            _log("yer tutucu eklendi")
    except Exception as e:
        _log("yer tutucu eklenemedi: %s" % e)
    _closeContextMenu(session)


def _toggleHelper(csel):
    if not _editableBouquet(csel):
        return False
    if _toggleDescriptor is not None:
        _toggleDescriptor.description = (
            _("yer tutucuları göster") if numbering.hiding()
            else _("yer tutucuları gizle"))
    return True


def _toggleAction(session, service=None, csel=None, **kwargs):
    """
    Yer tutucuları geçici olarak gösterir/gizler. Gizliyken seçilemedikleri
    için silme/taşıma bu geçişle yapılır. Kalıcı olan ayar ekranındakidir.
    """
    try:
        numbering.setHideOverride(not numbering.hiding())
        patcher.refill(csel)
    except Exception as e:
        _log("görünürlük değiştirilemedi: %s" % e)
    _closeContextMenu(session)


def Plugins(**kwargs):
    global _toggleDescriptor
    _toggleDescriptor = PluginDescriptor(
        name="MarkerNumberingToggle",
        description=_("yer tutucuları göster"),
        where=PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
        needsRestart=False,
        fnc=_toggleAction,
        helperfnc=_toggleHelper)

    return [
        PluginDescriptor(
            name="MarkerNumbering",
            description="Adsız marker'lar kanal numarası rezerve etsin",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            needsRestart=False,
            fnc=sessionstart),
        PluginDescriptor(
            name=_("Kanal Numaralandırma"),
            description=_("Marker numaralandırması ve buke başına numaralandırma"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            needsRestart=False,
            fnc=openSetup),
        PluginDescriptor(
            name="MarkerNumberingAdd",
            description=_("boş numara ayır (yer tutucu)"),
            where=PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU,
            needsRestart=False,
            fnc=_addAction,
            helperfnc=_addHelper),
        _toggleDescriptor,
    ]
