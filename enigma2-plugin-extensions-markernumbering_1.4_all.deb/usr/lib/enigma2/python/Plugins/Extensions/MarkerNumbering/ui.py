# -*- coding: utf-8 -*-
#
# MarkerNumbering - ayar ve durum ekranı
#
# Not: config widget'ına font/itemHeight verilmez -- DreamOS'ta eListbox'ta
# setFont yoktur (skin.py applySingleAttribute -> AttributeError -> yeşil ekran).
# Config listesinin fontu temanın <listboxcontent> tanımından gelir.
#
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.config import getConfigListEntry, configfile

from enigma import getDesktop

from .settings import cfg
from .numbering import cache, hiding, perBouquet, previewNumbering, setHideOverride
from . import patcher

PREVIEW_LINES = 12


def _skin():
    try:
        width = getDesktop(0).size().width()
    except Exception:
        width = 1280
    if width >= 1920:
        return """
        <screen name="MarkerNumberingSetup" position="center,center" size="1400,900" title="Kanal Numaralandırma">
            <widget name="config" position="30,20" size="1340,290" scrollbarMode="showOnDemand" />
            <widget name="status" position="30,325" size="640,485" font="Regular;24" />
            <widget name="preview" position="700,325" size="670,485" font="Regular;24" />
            <widget source="key_red" render="Label" position="30,830" size="330,45" font="Regular;28" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="370,830" size="330,45" font="Regular;28" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="710,830" size="330,45" font="Regular;28" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1040,830" size="330,45" font="Regular;28" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="MarkerNumberingSetup" position="center,center" size="900,600" title="Kanal Numaralandırma">
        <widget name="config" position="20,15" size="860,190" scrollbarMode="showOnDemand" />
        <widget name="status" position="20,215" size="410,330" font="Regular;18" />
        <widget name="preview" position="450,215" size="430,330" font="Regular;18" />
        <widget source="key_red" render="Label" position="20,555" size="210,30" font="Regular;20" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="235,555" size="210,30" font="Regular;20" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="450,555" size="210,30" font="Regular;20" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="665,555" size="210,30" font="Regular;20" foregroundColor="blue" halign="left" />
    </screen>"""


class MarkerNumberingSetup(Screen, ConfigListScreen):
    def __init__(self, session):
        self.skin = _skin()
        Screen.__init__(self, session)
        self.setTitle(_("Kanal Numaralandırma"))

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Yenile"))
        self["key_blue"] = StaticText(_("Önbelleği temizle"))
        self["status"] = Label("")
        self["preview"] = Label("")

        entries = [
            getConfigListEntry(_("Eklenti etkin"), cfg.enabled),
            getConfigListEntry(_("Numaralandırma"), cfg.numbering_mode),
            getConfigListEntry(_("Yer tutucuları listede gizle"), cfg.hide_placeholders),
            getConfigListEntry(_("Görünürken yer tutucu satırı"), cfg.placeholder),
            getConfigListEntry(_("Ayrılmış numara tuşlanırsa"), cfg.reserved_zap),
            getConfigListEntry(_("Tema numara göstergelerini de düzelt"), cfg.fix_renderers),
            getConfigListEntry(_("Kanal listesi menüsüne girdi ekle"), cfg.context_menu),
            getConfigListEntry(_("Günlüğe ayrıntı yaz"), cfg.debug),
        ]
        # ConfigListScreen kendi "SetupActions" haritasını kurar (ok/left/right).
        # Aşağıdaki harita yalnızca cancel/save/renk tuşlarını alır.
        ConfigListScreen.__init__(self, entries, session=session)

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "cancel": self.keyCancel,
                "save": self.keySave,
                "red": self.keyCancel,
                "green": self.keySave,
                "yellow": self.updateStatus,
                "blue": self.clearCache,
            }, -1)

        self.onLayoutFinish.append(self.updateStatus)

    # ------------------------------------------------------------------ durum

    def _currentBouquet(self):
        """(kök referans dizesi, buke numara ofseti) -- kanal listesinden."""
        try:
            from Screens.InfoBar import InfoBar
            csel = getattr(InfoBar, "instance", None)
            csel = csel and getattr(csel, "servicelist", None)
            if csel is None:
                return None, 0
            root = csel.getRoot()
            if root is None:
                return None, 0
            try:
                offset = csel.getBouquetNumOffset(root)
            except Exception:
                offset = 0
            return root.toString(), offset
        except Exception:
            return None, 0

    def updateStatus(self):
        lines = []
        lines.append("%-12s: %s" % (_("Durum"),
                                    _("etkin") if cfg.enabled.value else _("kapalı")))

        status = patcher.patchStatus()
        if status:
            for key in sorted(status.keys()):
                lines.append("  %-14s %s" % (key, status[key]))
        else:
            lines.append("  " + _("yama uygulanmadı (yeniden başlatın)"))

        rootstr, offset = self._currentBouquet()
        lines.append("")
        if rootstr:
            entries, markers, empty = cache.stats(rootstr)
            lines.append("%s:" % _("Açık buke"))
            lines.append("  %-14s %d" % (_("satır"), entries))
            lines.append("  %-14s %d" % (_("marker"), markers))
            lines.append("  %-14s %d" % (_("yer tutucu"), empty))
            lines.append("  %-14s %s" % (_("yer tutucular"),
                                         _("gizli") if hiding() else _("görünür")))
            lines.append("  %-14s %d" % (_("numara ofseti"), offset))
            lines.append("  %-14s %s" % (_("numaralandırma"),
                                         _("her bukede 1'den") if perBouquet()
                                         else _("bukeler boyunca")))
            preview = previewNumbering(rootstr, offset, PREVIEW_LINES)
        else:
            lines.append(_("Kanal listesi henüz açılmadı."))
            preview = [_("Önizleme için önce kanal listesini açın.")]

        lines.append("")
        lines.append(_("Kanal listesinde menü tuşu:"))
        lines.append(_("  'boş numara ayır'      -> yer tutucu ekle"))
        lines.append(_("  'yer tutucuları göster' -> geçici görünürlük"))

        self["status"].setText("\n".join(lines))
        self["preview"].setText("%s\n\n%s" % (_("Önizleme"), "\n".join(preview)))

    def clearCache(self):
        setHideOverride(None)          # geçici göster/gizle seçimini bırak
        patcher.refreshList()
        self.updateStatus()

    # ------------------------------------------------------------------ kayıt

    def keySave(self):
        was_enabled = cfg.enabled.value
        self.saveAll()
        configfile.save()
        if cfg.enabled.value and not patcher.patchStatus():
            patcher.patchAll()
        setHideOverride(None)
        patcher.refreshList()
        if was_enabled != cfg.enabled.value:
            self._toast(_("Numaraların tümüyle tazelenmesi için "
                          "kanal listesini kapatıp açın."))
        self.close()

    def _toast(self, text):
        try:
            self.session.toastManager.showToast(text)
        except Exception:
            print("[MarkerNumbering] %s" % text)


def openSetup(session, **kwargs):
    session.open(MarkerNumberingSetup)
