# -*- coding: utf-8 -*-
#
# MarkerNumbering - ayarlar
#
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection

try:                      # enigma2 gettext'i "_" adını builtin olarak kurar;
    _                     # test/stub ortamında kurmamış olabilir
except NameError:
    def _(txt):
        return txt

config.plugins.markernumbering = ConfigSubsection()
cfg = config.plugins.markernumbering

# Eklenti tümüyle etkin mi
cfg.enabled = ConfigYesNo(default=True)

# Yer tutucu satırları kanal listesinde hiç görünmesin (OpenATV gibi).
# Kapalıysa satır kalır, aşağıdaki 'placeholder' ayarına göre çizilir.
cfg.hide_placeholders = ConfigYesNo(default=True)

# Yer tutucu GÖRÜNÜRKEN satırda ne gösterilsin
#   blank  : hiçbir şey (OpenATV görünümü)
#   number : rezerve edilen kanal numarası
#   dash    : çizgi
cfg.placeholder = ConfigSelection(default="blank", choices=[
    ("blank", _("Boş satır")),
    ("number", _("Ayrılan numara")),
    ("dash", _("Çizgi")),
])

# Numaralandırma kipi
#   continuous : bukeler boyunca sürer (DreamOS stok davranışı)
#   perbouquet : her buke 1'den başlar (OpenATV'deki seçenek)
cfg.numbering_mode = ConfigSelection(default="continuous", choices=[
    ("continuous", _("Bukeler boyunca sürsün")),
    ("perbouquet", _("Her bukede 1'den başlasın")),
])

# Rezerve edilmiş (boş) bir numara tuşlanırsa ne olsun
cfg.reserved_zap = ConfigSelection(default="ignore", choices=[
    ("ignore", _("Hiçbir şey yapma")),
    ("next", _("Sonraki gerçek kanala geç")),
])

# Tema kanal numarası göstergelerini (SuissChannelNumber vb.) de düzelt
cfg.fix_renderers = ConfigYesNo(default=True)

# Kanal listesi bağlam menüsüne "yer tutucu ekle" girdisini koy
cfg.context_menu = ConfigYesNo(default=True)

# Günlüğe ayrıntı yaz
cfg.debug = ConfigYesNo(default=False)
