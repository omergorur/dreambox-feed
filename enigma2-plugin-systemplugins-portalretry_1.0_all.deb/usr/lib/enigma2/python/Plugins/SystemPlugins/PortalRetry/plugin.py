# -*- coding: utf-8 -*-
"""
PortalRetry -- Stalker portal liste sayfalarini gecici hatada yeniden ister.

NEDEN: AJPanel bir dizi/film kategorisini sayfa sayfa ceker (her sayfa ayri
bir "action=get_ordered_list" istegi). Sunucu tek bir sayfada bile zaman
asimi, 5xx ya da bos/bozuk cevap verirse AJPanel butun listeyi "error while
reading" ile birakir (olculdu: 1039 ogeden 70'inde). Hata cogu zaman
geciciyor; ayni sayfa bir-iki saniye sonra geliyor.

Bu eklenti requests.get'i sarmalar; YALNIZCA get_ordered_list isteklerinde
ve yalnizca arka plan is parcacigindan (ana dongu bekletilmez) su durumlarda
1, 2, 4 sn bekleyerek en fazla 3 kez yeniden dener:
  - baglanti hatasi / zaman asimi
  - HTTP 429, 5xx
  - HTTP 200 ama govde JSON degil ya da "js" alani yok
Son deneme de basarisizsa sonuc AJPanel'e oldugu gibi iletilir.
Gunluk:  journalctl -u enigma2 | grep PortalRetry
"""
import json
import threading
import time
import traceback

from Plugins.Plugin import PluginDescriptor

_ETIKET = "[PortalRetry]"
_BEKLEME = (1, 2, 4)


def _ana_mi():
	return isinstance(threading.current_thread(), threading._MainThread)


def _hedef_mi(url):
	return isinstance(url, basestring) and "action=get_ordered_list" in url


def _sorun(res):
	"""Cevap yeniden denenmeli mi? Nedeni (str) ya da None."""
	kod = res.status_code
	if kod == 429 or kod >= 500:
		return "HTTP %d" % kod
	if kod != 200:
		return None  # 4xx kalici; yeniden denemek anlamsiz
	try:
		veri = json.loads(res.text)
	except ValueError:
		return "HTTP 200, govde JSON degil (%d bayt)" % len(res.content or "")
	if not isinstance(veri, dict) or "js" not in veri:
		return "HTTP 200, 'js' alani yok"
	return None


def _kur():
	import requests
	import requests.api

	asil_get = requests.get
	yeniden_denenebilir = (requests.Timeout, requests.ConnectionError)

	def get(url, params=None, **kwargs):
		if not _hedef_mi(url) or _ana_mi():
			return asil_get(url, params=params, **kwargs)
		for deneme, bekle in enumerate(_BEKLEME + (None,)):
			try:
				res = asil_get(url, params=params, **kwargs)
				neden = _sorun(res)
			except yeniden_denenebilir as e:
				if bekle is None:
					raise
				res, neden = None, e.__class__.__name__
			if neden is None:
				if deneme:
					print("%s %d. yeniden denemede geldi" % (_ETIKET, deneme))
				return res
			if bekle is None:
				print("%s %d denemede de olmadi (%s), AJPanel'e iletiliyor: %s" % (_ETIKET, deneme + 1, neden, url))
				return res
			print("%s %s -- %d sn sonra yeniden denenecek: %s" % (_ETIKET, neden, bekle, url))
			time.sleep(bekle)

	requests.get = get
	requests.api.get = get
	print("%s etkin: get_ordered_list istekleri gecici hatada yeniden denenir" % _ETIKET)


try:
	_kur()
except Exception:
	traceback.print_exc()


def Plugins(**kwargs):
	return [PluginDescriptor(name="PortalRetry", where=PluginDescriptor.WHERE_AUTOSTART, fnc=lambda **kw: None)]
