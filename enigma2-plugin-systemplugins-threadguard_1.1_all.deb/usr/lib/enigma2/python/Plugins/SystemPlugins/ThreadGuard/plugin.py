# -*- coding: utf-8 -*-
"""
ThreadGuard -- arka plan is parcaciklarindan yapilan GUI cagrilarini ana
is parcacigina devreder.

NEDEN: enigma2'de ekranlar ve zamanlayicilar (eTimer) yalnizca ana is
parcacigindan kullanilabilir. Bazi eklentiler (olculdu: AJPanel, dizi
kategorisi yuklerken sunucu bir sayfada hata verince) ilerleme ekranini
arka plan is parcacigindan kapatiyor: Screen.close -> Session.close ->
execEnd + delay_timer.start. Bu sirada ana is parcacigi Python kilidini
(GIL) birakmis, poll() icinde bekliyor; sonuc: tum is parcaciklari GIL'i
bekler, enigma2 donar, kumanda cevap vermez.

Ikinci ornek (olculdu, 1.1): AJPanel sunucudan oturum anahtari alamayinca
hata kutusunu arka plan is parcacigindan aciyor (session.open); ekran
kurulurken eTimer C++ tarafinda baslatiliyor ve enigma2 "FATAL!: addTimer
... must be called from thread" ile kendini dusuruyor (yesil ekran).

Bu eklenti Screen.close, eTimer.start/stop ve Session.open/instantiateDialog'u
sarmalar: ana is parcacigindan gelen cagrilar oldugu gibi gecer; baska is
parcacigindan gelenler twisted reactor.callFromThread ile ana donguye
devredilir. close ve eTimer kuyruklanir; open ve instantiateDialog acilan
diyalogu dondurmek zorunda oldugu icin (openWithCallback dlg.callback'i
ayarlar) cagiran is parcacigi ana dongu isi bitirene kadar bekler.
Cagiran yer (dosya:satir) bir kez gunluge yazilir:
    journalctl -u enigma2 | grep ThreadGuard
Sistem dosyalarina dokunmaz; sarmalama calisma zamanindadir.
"""
import threading
import traceback

from Plugins.Plugin import PluginDescriptor

_ETIKET = "[ThreadGuard]"
_gorulen = set()
_ESLI_SURE = 15


def _ana_mi():
	return isinstance(threading.current_thread(), threading._MainThread)


def _kaydet(ne):
	yigin = traceback.extract_stack()[:-2]
	# cagiran: sarmalayicinin disindaki en yakin cerceve
	yer = "%s:%d %s" % yigin[-1][:3] if yigin else "?"
	anahtar = (ne, yer)
	if anahtar in _gorulen:
		return
	_gorulen.add(anahtar)
	print("%s %s ana is parcacigi disindan cagrildi (is parcacigi %s), ana donguye devredildi: %s"
		% (_ETIKET, ne, threading.current_thread().name, yer))
	for satir in traceback.format_list(yigin[-6:]):
		print("%s   %s" % (_ETIKET, satir.rstrip().replace("\n", " | ")))


def _devret(fnc, *args):
	from twisted.internet import reactor
	reactor.callFromThread(fnc, *args)


def _esli_devret(fnc, *args, **kwargs):
	"""fnc'yi ana dongude calistirir, bitene kadar bekler, sonucunu dondurur."""
	from twisted.internet import reactor
	bitti = threading.Event()
	sonuc = {}

	def calis():
		try:
			sonuc["r"] = fnc(*args, **kwargs)
		except Exception as e:
			sonuc["e"] = e
			traceback.print_exc()
		finally:
			bitti.set()
	reactor.callFromThread(calis)
	if not bitti.wait(_ESLI_SURE):
		print("%s ana dongu %d sn icinde cevap vermedi, cagri sonucsuz birakildi" % (_ETIKET, _ESLI_SURE))
		return None
	if "e" in sonuc:
		raise sonuc["e"]
	return sonuc.get("r")


def _kur_session(session):
	cls = session.__class__
	if getattr(cls, "_threadguard", False):
		return
	asil_open = cls.open
	asil_inst = cls.instantiateDialog

	def open(self, screen, *args, **kwargs):
		if _ana_mi():
			return asil_open(self, screen, *args, **kwargs)
		_kaydet("Session.open (%s)" % getattr(screen, "__name__", screen))
		return _esli_devret(asil_open, self, screen, *args, **kwargs)

	def instantiateDialog(self, screen, *args, **kwargs):
		if _ana_mi():
			return asil_inst(self, screen, *args, **kwargs)
		_kaydet("Session.instantiateDialog (%s)" % getattr(screen, "__name__", screen))
		return _esli_devret(asil_inst, self, screen, *args, **kwargs)

	cls.open = open
	cls.instantiateDialog = instantiateDialog
	cls._threadguard = True
	print("%s etkin: Session.open/instantiateDialog korunuyor" % _ETIKET)


def _kur():
	from Screens.Screen import Screen
	from enigma import eTimer

	asil_close = Screen.close
	asil_start = eTimer.start
	asil_stop = eTimer.stop

	def guvenli_close(screen, retval):
		# kuyrukta beklerken ekran zaten kapanmis olabilir (ornegin kendi
		# zamanlayicisi kapatti); kapanmis ekranin __dict__'i temizlenir
		d = screen.__dict__
		if "execing" not in d or d.get("instance") is None:
			return
		session = d.get("session")
		if screen.execing and session is not None and session.current_dialog is not screen:
			print("%s %s zaten on planda degil, devredilen close atlandi" % (_ETIKET, screen.__class__.__name__))
			return
		asil_close(screen, *retval)

	def close(self, *retval):
		if _ana_mi():
			return asil_close(self, *retval)
		_kaydet("Screen.close (%s)" % self.__class__.__name__)
		_devret(guvenli_close, self, retval)

	def start(self, *args):
		if _ana_mi():
			return asil_start(self, *args)
		_kaydet("eTimer.start")
		_devret(asil_start, self, *args)

	def stop(self):
		if _ana_mi():
			return asil_stop(self)
		_kaydet("eTimer.stop")
		_devret(asil_stop, self)

	Screen.close = close
	eTimer.start = start
	eTimer.stop = stop
	print("%s etkin: Screen.close, eTimer.start/stop korunuyor" % _ETIKET)


# Eklenti listesi okunurken (ana is parcacigi, eklentiler calismadan once)
# kurulur; boylece AJPanel gibi eklentilerin ilk cagrisi da korunur.
if _ana_mi():
	try:
		_kur()
	except Exception:
		traceback.print_exc()


def _oturum_basladi(reason, session=None, **kwargs):
	# Session sinifi mytest.py'de (__main__); ornegi ancak burada eline gecer
	if reason == 0 and session is not None:
		try:
			_kur_session(session)
		except Exception:
			traceback.print_exc()


def Plugins(**kwargs):
	return [PluginDescriptor(name="ThreadGuard", where=PluginDescriptor.WHERE_SESSIONSTART, fnc=_oturum_basladi)]
