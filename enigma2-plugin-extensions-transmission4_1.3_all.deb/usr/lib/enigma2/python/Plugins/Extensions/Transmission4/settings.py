# -*- coding: utf-8 -*-
#
# Transmission4 - ayarlar
#
from Components.config import (config, ConfigSubsection, ConfigYesNo,
                               ConfigSelection, ConfigInteger, ConfigText,
                               ConfigPassword, ConfigDirectory)

try:                      # enigma2 gettext'i "_" adını builtin olarak kurar;
    _                     # test/stub ortamında kurmamış olabilir
except NameError:
    def _(txt):
        return txt

config.plugins.transmission4 = ConfigSubsection()
cfg = config.plugins.transmission4

# --- bağlantı -------------------------------------------------------------
# Varsayılan 127.0.0.1: daemon aynı kutuda. Uzaktaki bir Transmission'a da
# bağlanabilirsin (NAS, PC) -- o zaman daemon yönetimi devre dışı kalır.
cfg.host = ConfigText(default="127.0.0.1", fixed_size=False)
cfg.port = ConfigInteger(default=9091, limits=(1, 65535))
cfg.username = ConfigText(default="", fixed_size=False)
cfg.password = ConfigPassword(default="")

# --- davranış -------------------------------------------------------------
# Liste ekranı açıkken kaç ms'de bir torrent listesi çekilsin.
# 1 sn altına inme: her yenileme bir HTTP isteği ve JSON ayrıştırması.
cfg.refresh = ConfigSelection(default="2000", choices=[
    ("1000", "1 s"), ("2000", "2 s"), ("3000", "3 s"),
    ("5000", "5 s"), ("10000", "10 s"),
])

# Liste ekranı kapalıyken de arka planda yoklansın mı? Tamamlanma bildirimi
# için gerekli; kapalıysa bildirim yalnızca ekran açıkken görünür.
cfg.background_poll = ConfigYesNo(default=True)
cfg.background_refresh = ConfigSelection(default="30000", choices=[
    ("15000", "15 s"), ("30000", "30 s"), ("60000", "1 dk"),
    ("300000", "5 dk"),
])

cfg.notify_finished = ConfigYesNo(default=True)

# İndirme dizini -- torrent eklerken varsayılan olarak önerilir.
cfg.download_dir = ConfigDirectory(default="/media/hdd/torrents")

# .torrent dosyası ararken açılacak dizin
cfg.browse_dir = ConfigDirectory(default="/media/hdd")

# --- daemon yönetimi ------------------------------------------------------
# Daemon aynı kutudaysa eklenti systemd üzerinden başlatıp durdurabilir.
cfg.manage_daemon = ConfigYesNo(default=True)
cfg.service_name = ConfigText(default="transmission-daemon", fixed_size=False)

cfg.debug = ConfigYesNo(default=False)


def isLocal():
    """Daemon bu kutuda mı? Sadece o zaman systemd ile yönetilebilir."""
    return cfg.host.value in ("127.0.0.1", "localhost", "::1", "")
