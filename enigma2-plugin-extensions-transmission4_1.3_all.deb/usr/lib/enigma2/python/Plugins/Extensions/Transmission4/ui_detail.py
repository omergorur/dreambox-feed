# -*- coding: utf-8 -*-
#
# Transmission4 - torrent detayı ve dosya seçimi
#
from __future__ import print_function

import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.ScrollLabel import ScrollLabel

from enigma import (getDesktop, eListboxPythonMultiContent, gFont, eTimer,
                    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER)
from Components.MultiContent import MultiContentEntryText, MultiContentEntryProgress

from . import fmt
from .client import client, statusText
from .ui_list import rowWidth

try:
    _
except NameError:
    def _(txt):
        return txt


def isFHD():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:
        return False


PRIORITY_TEXT = {-1: _("düşük"), 0: _("normal"), 1: _("yüksek")}
COL_OFF = 0x808080
COL_DONE = 0x40C040


class FileList(MenuList):

    def __init__(self):
        MenuList.__init__(self, [], content=eListboxPythonMultiContent)
        if isFHD():
            self.l.setFont(0, gFont("Regular", 22))
            self.l.setItemHeight(52)
        else:
            self.l.setFont(0, gFont("Regular", 17))
            self.l.setItemHeight(38)
        self._w = rowWidth(isFHD())

    def build(self, files, stats):
        rows = []
        for i, f in enumerate(files):
            st = stats[i] if i < len(stats) else {}
            rows.append(self._entry(i, f, st))
        self.list = rows
        self.l.setList(rows)

    def _entry(self, index, f, st):
        fhd = isFHD()
        w = self._w
        h = 42 if fhd else 30
        wanted = bool(st.get("wanted", True))
        prio = int(st.get("priority", 0) or 0)
        total = float(f.get("length") or 0)
        done = float(st.get("bytes_completed", f.get("bytes_completed", 0)) or 0)
        pct = (done / total) if total else 0.0

        mark = "☑" if wanted else "☐"
        name = f.get("name") or ""
        # torrent içindeki tam yol uzun olur; son iki bileşen yeter
        short = "/".join(name.split("/")[-2:])

        right = "%s  %s  [%s]" % (fmt.percent(pct), fmt.size(total),
                                  PRIORITY_TEXT.get(prio, "?"))
        rightW = 380 if fhd else 260
        nameW = w - rightW - 60

        color = None if wanted else COL_OFF
        if wanted and pct >= 1.0:
            color = COL_DONE

        return [
            (index, wanted, prio),
            MultiContentEntryText(pos=(0, 0), size=(45, h), font=0,
                                  flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                  text=mark, color=color),
            MultiContentEntryText(pos=(50, 0), size=(nameW, h), font=0,
                                  flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                  text=short, color=color),
            MultiContentEntryText(pos=(w - rightW, 0), size=(rightW, h), font=0,
                                  flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER,
                                  text=right, color=color),
        ]

    def current(self):
        cur = self.getCurrent()
        return cur[0] if cur else None


def _skin():
    if isFHD():
        return """
        <screen name="Transmission4Detail" position="center,center" size="1860,1000" title="Torrent detayı">
            <widget name="name" position="25,15" size="1810,40" font="Regular;28" />
            <widget name="info" position="25,65" size="1810,270" font="Regular;23" />
            <widget name="files" position="25,350" size="1810,505" scrollbarMode="showOnDemand" scrollbarWidth="12" transparent="1" />
            <widget source="key_red" render="Label" position="25,880" size="440,45" font="Regular;26" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="480,880" size="440,45" font="Regular;26" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="935,880" size="440,45" font="Regular;26" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1390,880" size="445,45" font="Regular;26" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="Transmission4Detail" position="center,center" size="1240,680" title="Torrent detayı">
        <widget name="name" position="15,10" size="1210,28" font="Regular;20" />
        <widget name="info" position="15,42" size="1210,190" font="Regular;17" />
        <widget name="files" position="15,240" size="1210,340" scrollbarMode="showOnDemand" scrollbarWidth="12" transparent="1" />
        <widget source="key_red" render="Label" position="15,600" size="295,32" font="Regular;19" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="318,600" size="295,32" font="Regular;19" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="621,600" size="295,32" font="Regular;19" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="924,600" size="300,32" font="Regular;19" foregroundColor="blue" halign="left" />
    </screen>"""


class Transmission4Detail(Screen):

    REFRESH_MS = 3000

    def __init__(self, session, torrentId, name=""):
        self.skin = _skin()
        Screen.__init__(self, session)
        self.setTitle(_("Torrent detayı"))

        self.torrentId = torrentId
        self.torrent = {}
        self.files = []
        self.stats = []

        self["name"] = ScrollLabel(name or "")
        self["info"] = ScrollLabel("")
        self["files"] = FileList()
        self["key_red"] = StaticText(_("Kapat"))
        self["key_green"] = StaticText(_("Dosyayı aç/kapat"))
        self["key_yellow"] = StaticText(_("Öncelik"))
        self["key_blue"] = StaticText(_("Tümü aç/kapat"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "ok": self.toggleFile,
                "cancel": self.close,
                "red": self.close,
                "green": self.toggleFile,
                "yellow": self.cyclePriority,
                "blue": self.toggleAll,
            }, -1)

        self.timer = eTimer()
        # DreamOS sigc++: bağlantıyı saklamazsak callback hiç çalışmaz
        self.timer_conn = self.timer.timeout.connect(self.load)
        self.onLayoutFinish.append(self._onShown)
        self.onClose.append(self.timer.stop)

    def _onShown(self):
        self.load()
        self.timer.start(self.REFRESH_MS, False)

    # ------------------------------------------------------------ veri

    def load(self):
        client.getDetail(self.torrentId, self._loaded, self._failed)

    def _loaded(self, t):
        if not t:
            self["info"].setText(_("Torrent bulunamadı (silinmiş olabilir)."))
            self.timer.stop()
            return
        self.torrent = t
        self.files = t.get("files") or []
        self.stats = t.get("file_stats") or []

        self["name"].setText(t.get("name") or "")
        self["info"].setText(self._infoText(t))

        cur = self["files"].getSelectionIndex() if self.files else 0
        self["files"].build(self.files, self.stats)
        if self.files and cur:
            self["files"].moveToIndex(min(cur, len(self.files) - 1))

    def _failed(self, err):
        self["info"].setText(_("Bağlantı hatası: %s") % err)

    def _infoText(self, t):
        trackers = t.get("tracker_stats") or []
        trackerLine = "-"
        if trackers:
            tr = trackers[0]
            trackerLine = "%s (%s)" % (
                tr.get("host") or tr.get("announce", "?"),
                tr.get("lastAnnounceResult") or tr.get("last_announce_result")
                or _("bekliyor"))

        lines = [
            "%-22s %s" % (_("Durum:"), statusText(t)),
            "%-22s %s / %s  (%s)" % (
                _("İlerleme:"),
                fmt.size((t.get("size_when_done") or 0)
                         - (t.get("left_until_done") or 0)),
                fmt.size(t.get("size_when_done")),
                fmt.percent(t.get("percent_done"))),
            "%-22s ↓ %s   ↑ %s   %s %s" % (
                _("Hız:"), fmt.speed(t.get("rate_download")),
                fmt.speed(t.get("rate_upload")),
                _("kalan"), fmt.eta(t.get("eta"))),
            "%-22s %s (%s %s / %s %s)" % (
                _("Eşler:"), t.get("peers_connected", 0),
                "↓", t.get("peers_sending_to_us", 0),
                "↑", t.get("peers_getting_from_us", 0)),
            "%-22s %s   %s %s" % (
                _("Oran:"), fmt.ratio(t.get("upload_ratio")),
                _("gönderilen:"), fmt.size(t.get("uploaded_ever"))),
            "%-22s %s" % (_("Dizin:"), t.get("download_dir") or "-"),
            "%-22s %s" % (_("Eklendi:"), fmt.date(t.get("added_date"))),
            "%-22s %s" % (_("Tracker:"), trackerLine),
        ]
        if t.get("error"):
            lines.append("%-22s %s" % (_("HATA:"), t.get("error_string") or ""))
        return "\n".join(lines)

    # -------------------------------------------------------- dosya eylemleri

    def _currentIndex(self):
        cur = self["files"].current()
        return cur[0] if cur else None

    def toggleFile(self):
        cur = self["files"].current()
        if cur is None:
            return
        index, wanted, prio = cur
        if wanted:
            client.setFiles(self.torrentId, [], [index], done=lambda a: self.load())
        else:
            client.setFiles(self.torrentId, [index], [], done=lambda a: self.load())

    def toggleAll(self):
        if not self.files:
            return
        allIndexes = list(range(len(self.files)))
        anyOff = any(not s.get("wanted", True) for s in self.stats)
        if anyOff:
            client.setFiles(self.torrentId, allIndexes, [],
                            done=lambda a: self.load())
        else:
            # hepsini kapatmak torrenti tümüyle durdururdu; buna izin verme
            self.session.open(
                MessageBox,
                _("Tüm dosyaları kapatamazsınız. Tek tek kapatın ya da\n"
                  "torrenti durdurun."),
                MessageBox.TYPE_INFO, timeout=6)

    def cyclePriority(self):
        cur = self["files"].current()
        if cur is None:
            return
        index, wanted, prio = cur
        nxt = {-1: 0, 0: 1, 1: -1}.get(prio, 0)
        high = [index] if nxt == 1 else []
        normal = [index] if nxt == 0 else []
        low = [index] if nxt == -1 else []
        client.setPriority(self.torrentId, high, normal, low,
                           done=lambda a: self.load())
