#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Transmission RPC teshis betigi -- enigma2'den BAGIMSIZ calisir.
#
# Kutuda:
#     python /usr/lib/enigma2/python/Plugins/Extensions/Transmission4/tools/rpc_probe.py
#     python .../rpc_probe.py 192.168.2.20 9091 kullanici parola
#
# Neyi ayirt eder:
#   * daemon hic calismiyor mu (baglanti reddedildi)
#   * calisiyor ama kimlik dogrulama mi istiyor (401)
#   * CSRF el sikismasi calisiyor mu (409 -> X-Transmission-Session-Id)
#   * hangi protokol destekleniyor (legacy / JSON-RPC 2.0)
#
# "Cevap gelmedi" tek basina bilgi degildir; bu betik hangi asamada
# takildigini soyler.
#
from __future__ import print_function

import base64
import json
import sys

try:                                   # Python 2
    from urllib2 import Request, urlopen, HTTPError, URLError
except ImportError:                    # Python 3
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError

HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 9091
USER = sys.argv[3] if len(sys.argv) > 3 else ""
PASSWORD = sys.argv[4] if len(sys.argv) > 4 else ""

URL = "http://%s:%d/transmission/rpc" % (HOST, PORT)
SESSION_ID = [None]


def post(payload):
    """(http_kodu, govde, basliklar) dondurur; istisna firlatmaz."""
    body = json.dumps(payload).encode("utf-8")
    req = Request(URL, data=body)
    req.add_header("Content-Type", "application/json")
    if SESSION_ID[0]:
        req.add_header("X-Transmission-Session-Id", SESSION_ID[0])
    if USER:
        token = base64.b64encode(("%s:%s" % (USER, PASSWORD)).encode("utf-8"))
        req.add_header("Authorization", "Basic " + token.decode("ascii"))
    try:
        resp = urlopen(req, timeout=10)
        return resp.getcode(), resp.read().decode("utf-8", "replace"), resp.info()
    except HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), e.info()
    except URLError as e:
        return None, str(e.reason), None


def header(info, name):
    if info is None:
        return None
    try:
        return info.get(name) or info.getheader(name)
    except AttributeError:
        return info.get(name)


def main():
    print("Hedef: %s" % URL)
    print("")

    # 1) CSRF el sikismasi
    print("1) baglanti ve oturum kimligi")
    code, body, info = post({"method": "session-get", "tag": 1})
    if code is None:
        print("   BASARISIZ: %s" % body)
        print("")
        print("   -> Daemon calismiyor olabilir. Kontrol:")
        print("        systemctl status transmission-daemon")
        print("        systemctl start transmission-daemon")
        return 1
    if code == 409:
        sid = header(info, "X-Transmission-Session-Id")
        if not sid:
            print("   409 geldi ama X-Transmission-Session-Id basligi YOK")
            return 1
        SESSION_ID[0] = sid
        print("   409 -> oturum kimligi alindi: %s..." % sid[:16])
        code, body, info = post({"method": "session-get", "tag": 2})
    elif code == 401:
        print("   401: kimlik dogrulama gerekiyor.")
        print("   -> Kullanici adi ve parolayi arguman olarak verin:")
        print("        rpc_probe.py %s %d KULLANICI PAROLA" % (HOST, PORT))
        return 1
    else:
        print("   dogrudan HTTP %d (CSRF kapali olabilir)" % code)

    if code != 200:
        print("   BASARISIZ: HTTP %s\n   %s" % (code, body[:400]))
        return 1

    data = json.loads(body)
    args = data.get("arguments", {})
    version = args.get("version")
    rpcver = args.get("rpc-version")
    print("   TAMAM")
    print("")

    print("2) daemon bilgisi")
    print("   surum          : %s" % version)
    print("   rpc-version    : %s" % rpcver)
    print("   indirme dizini : %s" % args.get("download-dir"))
    print("   config dizini  : %s" % args.get("config-dir"))
    print("   es portu       : %s" % args.get("peer-port"))
    print("   izleme klasoru : %s (%s)" % (
        args.get("watch-dir"),
        "acik" if args.get("watch-dir-enabled") else "kapali"))
    print("")

    print("3) protokol destegi")
    print("   legacy (bespoke)   : EVET (yukaridaki cagri onunla yapildi)")
    try:
        modern_expected = int(rpcver) >= 19
    except (TypeError, ValueError):
        modern_expected = False
    code, body, info = post({"jsonrpc": "2.0", "method": "session_get",
                             "params": {"fields": ["version"]}, "id": 3})
    ok = False
    if code == 200:
        try:
            resp = json.loads(body)
            ok = "result" in resp and "error" not in resp
        except ValueError:
            ok = False
    print("   JSON-RPC 2.0       : %s%s" % (
        "EVET" if ok else "HAYIR",
        "" if ok == modern_expected
        else "   (!) rpc-version'a gore %s bekleniyordu"
             % ("EVET" if modern_expected else "HAYIR")))
    print("   eklentinin secimi  : %s" % ("JSON-RPC 2.0" if modern_expected
                                          else "legacy"))
    print("")

    print("4) torrent listesi")
    SESSION_ID[0] = SESSION_ID[0]
    code, body, info = post({
        "method": "torrent-get",
        "arguments": {"fields": ["id", "name", "status", "percentDone",
                                 "rateDownload", "errorString"]},
        "tag": 4})
    if code != 200:
        print("   BASARISIZ: HTTP %s" % code)
        return 1
    torrents = json.loads(body).get("arguments", {}).get("torrents", [])
    print("   %d torrent" % len(torrents))
    for t in torrents[:20]:
        print("   [%3s] %-52s %5.1f%%  %s" % (
            t.get("id"), (t.get("name") or "")[:52],
            (t.get("percentDone") or 0) * 100,
            t.get("errorString") or ""))
    if len(torrents) > 20:
        print("   ... (%d tane daha)" % (len(torrents) - 20))

    print("")
    print("Her sey calisiyor.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
