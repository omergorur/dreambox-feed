# -*- coding: utf-8 -*-
#
# Transmission4 - torrent listesi (ana ekran)
#
# Skin kuralı (DreamOS): liste widget'ına skin'den font/itemHeight VERİLMEZ.
# eListbox'ta setFont yoktur, skin.py/applySingleAttribute AttributeError
# fırlatır ve ekran yeşile döner. Font ve satır yüksekliği Python'dan
# eListboxPythonMultiContent üzerinde ayarlanır -- orada setFont VARDIR.
#
from __future__ import print_function

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.Label import Label

from enigma import (getDesktop, eListboxPythonMultiContent, gFont,
                    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER)
from Components.MultiContent import MultiContentEntryText, MultiContentEntryProgress

from . import fmt
from .client import (client, statusText, STATUS_STOPPED, STATUS_SEED,
                     STATUS_SEED_WAIT)
from .settings import cfg
from . import daemon

try:
    _
except NameError:
    def _(txt):
        return txt


def isFHD():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:
        return False


# renkler (0xAARRGGBB değil, enigma2 0xRRGGBB bekler)
COL_ERROR = 0xFF4040
COL_DONE = 0x40C040
COL_DIM = 0x909090

# Skin'deki liste widget'ının genişliği ve scrollbar payı.
#
# eListbox'ta scrollbar genişliğini OKUYAN bir metot yoktur (setScrollbarWidth
# var, getter yok), dolayısıyla satır genişliği çalışma zamanında
# öğrenilemez. Satırlar widget genişliğinin tamamına çizilirse scrollbar
# göründüğü anda sağa hizalı metnin son harfi kırpılır ("Gönderiliyo").
# Bu yüzden genişliği skin'de scrollbarWidth ile SABİTLEYİP payı buradan
# düşüyoruz.
SCROLLBAR_W = 12          # skin'deki scrollbarWidth ile aynı olmalı
LIST_W_FHD = 1810
LIST_W_HD = 1210


def rowWidth(fhd):
    return (LIST_W_FHD if fhd else LIST_W_HD) - SCROLLBAR_W - 6


class TorrentList(MenuList):
    """Her satır: ad + durum, ilerleme çubuğu, hız/boyut/ETA satırı."""

    def __init__(self):
        MenuList.__init__(self, [], content=eListboxPythonMultiContent)
        if isFHD():
            self.l.setFont(0, gFont("Regular", 26))      # ad
            self.l.setFont(1, gFont("Regular", 20))      # ayrıntı
            self.l.setItemHeight(92)
        else:
            self.l.setFont(0, gFont("Regular", 20))
            self.l.setFont(1, gFont("Regular", 16))
            self.l.setItemHeight(66)
        self._w = rowWidth(isFHD())

    def build(self, torrents):
        self.list = [self._entry(t) for t in torrents]
        self.l.setList(self.list)

    def _entry(self, t):
        fhd = isFHD()
        w = self._w
        h1 = 34 if fhd else 24          # ad satırı yüksekliği
        hb = 12 if fhd else 9           # çubuk
        h2 = 28 if fhd else 20          # ayrıntı satırı
        pad = 6 if fhd else 4

        name = t.get("name") or "?"
        st = statusText(t)
        done = float(t.get("percent_done") or 0)

        if t.get("error"):
            color = COL_ERROR
        elif done >= 1.0:
            color = COL_DONE
        else:
            color = None

        statusW = 320 if fhd else 220
        nameW = w - statusW - 10

        detail = "%s  %s  %s %s   %s %s   %s %s   %s %d" % (
            fmt.percent(done),
            fmt.size(t.get("size_when_done") or t.get("total_size")),
            "↓", fmt.speed(t.get("rate_download")),
            "↑", fmt.speed(t.get("rate_upload")),
            _("kalan"), fmt.eta(t.get("eta")),
            _("eş:"), int(t.get("peers_connected") or 0),
        )
        if t.get("error"):
            detail = t.get("error_string") or _("hata")

        y = pad
        entry = [t]
        entry.append(MultiContentEntryText(
            pos=(0, y), size=(nameW, h1), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=name, color=color))
        entry.append(MultiContentEntryText(
            pos=(nameW + 10, y), size=(statusW, h1), font=0,
            flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text=st, color=color))
        y += h1 + pad
        entry.append(MultiContentEntryProgress(
            pos=(0, y), size=(w, hb), percent=int(done * 100)))
        y += hb + pad
        entry.append(MultiContentEntryText(
            pos=(0, y), size=(w, h2), font=1,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=detail,
            color=COL_ERROR if t.get("error") else COL_DIM))
        return entry

    def currentTorrent(self):
        cur = self.getCurrent()
        return cur[0] if cur else None


def _skin():
    if isFHD():
        return """
        <screen name="Transmission4List" position="center,center" size="1860,1000" title="Transmission">
            <widget name="header" position="25,15" size="1810,40" font="Regular;28" />
            <widget name="list" position="25,65" size="1810,790" scrollbarMode="showOnDemand" scrollbarWidth="12" transparent="1" />
            <widget name="footer" position="25,865" size="1810,40" font="Regular;24" />
            <widget source="key_red" render="Label" position="25,925" size="440,45" font="Regular;26" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="480,925" size="440,45" font="Regular;26" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="935,925" size="440,45" font="Regular;26" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1390,925" size="445,45" font="Regular;26" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="Transmission4List" position="center,center" size="1240,680" title="Transmission">
        <widget name="header" position="15,10" size="1210,28" font="Regular;20" />
        <widget name="list" position="15,44" size="1210,530" scrollbarMode="showOnDemand" scrollbarWidth="12" transparent="1" />
        <widget name="footer" position="15,584" size="1210,28" font="Regular;18" />
        <widget source="key_red" render="Label" position="15,626" size="295,32" font="Regular;19" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="318,626" size="295,32" font="Regular;19" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="621,626" size="295,32" font="Regular;19" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="924,626" size="300,32" font="Regular;19" foregroundColor="blue" halign="left" />
    </screen>"""


class Transmission4List(Screen):

    def __init__(self, session):
        self.skin = _skin()
        Screen.__init__(self, session)
        self.setTitle(_("Transmission"))

        self["list"] = TorrentList()
        self["header"] = Label(_("Bağlanılıyor..."))
        self["footer"] = Label("")
        self["key_red"] = StaticText(_("Sil"))
        self["key_green"] = StaticText(_("Başlat/Durdur"))
        self["key_yellow"] = StaticText(_("Ekle"))
        self["key_blue"] = StaticText(_("Menü"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "MenuActions", "EPGSelectActions"],
            {
                "ok": self.openDetail,
                "cancel": self.close,
                "red": self.removeTorrent,
                "green": self.toggleTorrent,
                "yellow": self.addTorrent,
                "blue": self.openMenu,
                "menu": self.openMenu,
                "info": self.openDetail,
            }, -1)

        self.onLayoutFinish.append(self._onShown)
        self.onClose.append(self._onClosed)

    # ---------------------------------------------------------- yaşam döngüsü

    def _onShown(self):
        client.onUpdate.append(self.onData)
        client.onError.append(self.onError)
        if client.rpc is None:
            client.configure()
        if client.rpc.rpc_version is None:
            client.probe(lambda args: client.acquire(),
                         lambda err: self._noConnection(err))
        else:
            client.acquire()

    def _onClosed(self):
        if self.onData in client.onUpdate:
            client.onUpdate.remove(self.onData)
        if self.onError in client.onError:
            client.onError.remove(self.onError)
        client.release()

    # ------------------------------------------------------------- veri

    def onData(self, torrents, stats):
        # sıraya göre: indirilenler üstte, sonra kuyruk sırası
        torrents = sorted(torrents, key=lambda t: (
            t.get("status") in (STATUS_STOPPED,),
            t.get("queue_position", 0)))
        cur = self["list"].currentTorrent()
        curId = cur.get("id") if cur else None

        self["list"].build(torrents)

        # imleci aynı torrentin üzerinde tut -- liste her 2 saniyede
        # yeniden kuruluyor, yoksa seçim sürekli başa atlardı
        if curId is not None:
            for i, t in enumerate(torrents):
                if t.get("id") == curId:
                    self["list"].moveToIndex(i)
                    break

        down = stats.get("download_speed", 0)
        up = stats.get("upload_speed", 0)
        n = stats.get("torrent_count", len(torrents))
        act = stats.get("active_torrent_count", 0)
        ver = client.rpc.server_version if client.rpc else "?"
        proto = "JSON-RPC 2.0" if (client.rpc and client.rpc.modern) else "legacy"

        self["header"].setText(
            "%s %s  ↓ %s   ↑ %s   %s %d/%d" % (
                _("Transmission"), ver or "", fmt.speed(down), fmt.speed(up),
                _("etkin"), act, n))
        self["footer"].setText("%s:%d  •  %s" % (
            cfg.host.value, cfg.port.value, proto))

    def onError(self, err):
        self["header"].setText(_("Bağlantı yok: %s") % err)
        self["footer"].setText(
            _("Mavi tuş > Daemon'ı başlat, ya da ayarlardan adresi kontrol et"))

    def _noConnection(self, err):
        self.onError(err)
        if daemon.available() and daemon.installed():
            self.session.openWithCallback(
                self._startDaemonAnswer, MessageBox,
                _("Transmission daemon yanıt vermiyor.\n\nŞimdi başlatılsın mı?"),
                MessageBox.TYPE_YESNO, timeout=15)

    def _startDaemonAnswer(self, answer):
        if not answer:
            return
        daemon.start(lambda code, text: self._afterDaemonStart(code, text))

    def _afterDaemonStart(self, code, text):
        if code == 0:
            self["header"].setText(_("Daemon başlatıldı, bağlanılıyor..."))
            client.probe(lambda args: client.acquire(),
                         lambda err: self.onError(err))
        else:
            self.session.open(MessageBox,
                              _("Daemon başlatılamadı:\n%s") % text,
                              MessageBox.TYPE_ERROR)

    # ---------------------------------------------------------- eylemler

    def _current(self):
        t = self["list"].currentTorrent()
        if t is None:
            self.session.open(MessageBox, _("Seçili torrent yok."),
                              MessageBox.TYPE_INFO, timeout=4)
        return t

    def openDetail(self):
        t = self._current()
        if not t:
            return
        from .ui_detail import Transmission4Detail
        self.session.open(Transmission4Detail, t.get("id"), t.get("name"))

    def toggleTorrent(self):
        t = self._current()
        if not t:
            return
        if t.get("status") == STATUS_STOPPED:
            client.start([t["id"]])
        else:
            client.stop([t["id"]])

    def removeTorrent(self):
        t = self._current()
        if not t:
            return
        self._removing = t
        self.session.openWithCallback(
            self._removeAnswer, ChoiceBox,
            title=_("'%s' silinsin mi?") % (t.get("name") or ""),
            list=[
                (_("Listeden kaldır (dosyalar kalsın)"), "keep"),
                (_("Sil ve indirilen dosyaları da sil"), "data"),
                (_("Vazgeç"), None),
            ])

    def _removeAnswer(self, choice):
        t = getattr(self, "_removing", None)
        self._removing = None
        if not choice or not choice[1] or not t:
            return
        client.remove([t["id"]], deleteData=(choice[1] == "data"))

    def addTorrent(self):
        from .ui_add import Transmission4Add
        self.session.open(Transmission4Add)

    # ------------------------------------------------------------- menü

    def openMenu(self):
        entries = [
            (_("Ayarlar"), "setup"),
            (_("Hepsini başlat"), "startall"),
            (_("Hepsini durdur"), "stopall"),
        ]
        t = self["list"].currentTorrent()
        if t:
            entries += [
                (_("Verileri doğrula"), "verify"),
                (_("Tracker'a yeniden duyur"), "reannounce"),
                (_("Sırayı atla, hemen başlat"), "startnow"),
            ]
        if daemon.available():
            entries += [
                (_("Daemon: başlat"), "d_start"),
                (_("Daemon: durdur"), "d_stop"),
                (_("Daemon: yeniden başlat"), "d_restart"),
            ]
        self.session.openWithCallback(self._menuAnswer, ChoiceBox,
                                      title=_("Transmission"), list=entries)

    def _menuAnswer(self, choice):
        if not choice or not choice[1]:
            return
        what = choice[1]
        t = self["list"].currentTorrent()
        ids = [t["id"]] if t else []

        if what == "setup":
            from .ui_setup import Transmission4Setup
            self.session.open(Transmission4Setup)
        elif what == "startall":
            client.start([tt["id"] for tt in client.torrents])
        elif what == "stopall":
            client.stop([tt["id"] for tt in client.torrents])
        elif what == "verify" and ids:
            client.verify(ids)
        elif what == "reannounce" and ids:
            client.reannounce(ids)
        elif what == "startnow" and ids:
            client.startNow(ids)
        elif what == "d_start":
            daemon.start(self._daemonDone)
        elif what == "d_stop":
            daemon.stop(self._daemonDone)
        elif what == "d_restart":
            daemon.restart(self._daemonDone)

    def _daemonDone(self, code, text):
        if code == 0:
            self["header"].setText(_("Daemon komutu tamam, bağlanılıyor..."))
            client.probe(lambda args: client.refresh(),
                         lambda err: self.onError(err))
        else:
            self.session.open(MessageBox, text or _("Komut başarısız"),
                              MessageBox.TYPE_ERROR, timeout=8)


def openList(session, **kwargs):
    session.open(Transmission4List)
