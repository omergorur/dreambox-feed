# -*- coding: utf-8 -*-
#
# Transmission4 - veri katmanı
#
# Ekranlar RPC'yi doğrudan çağırmaz; hepsi buradaki tek istemciyi dinler.
# Böylece iki ekran açıkken daemon iki kat yoklanmaz ve arka plan yoklaması
# ekran kapanınca da sürebilir (tamamlanma bildirimi için gerekli).
#
from __future__ import print_function

import time

from enigma import eTimer

from .rpc import TransmissionRPC
from .settings import cfg

try:                      # enigma2 gettext'i "_" adını builtin olarak kurar;
    _                     # test/stub ortamında kurmamış olabilir
except NameError:
    def _(txt):
        return txt

# --- torrent durum kodları (RPC spec, 3.x'ten beri değişmedi) -------------
STATUS_STOPPED = 0
STATUS_CHECK_WAIT = 1
STATUS_CHECK = 2
STATUS_DOWNLOAD_WAIT = 3
STATUS_DOWNLOAD = 4
STATUS_SEED_WAIT = 5
STATUS_SEED = 6

STATUS_TEXT = {
    STATUS_STOPPED: _("Durduruldu"),
    STATUS_CHECK_WAIT: _("Doğrulama sırasında"),
    STATUS_CHECK: _("Doğrulanıyor"),
    STATUS_DOWNLOAD_WAIT: _("Sırada"),
    STATUS_DOWNLOAD: _("İndiriliyor"),
    STATUS_SEED_WAIT: _("Gönderim sırasında"),
    STATUS_SEED: _("Gönderiliyor"),
}

# Liste ekranının ihtiyaç duyduğu alanlar. Kısa tutmak önemli: her yenilemede
# bunların hepsi her torrent için JSON'a serileşiyor.
LIST_FIELDS = [
    "id", "name", "status", "percent_done", "rate_download", "rate_upload",
    "eta", "total_size", "size_when_done", "left_until_done", "error",
    "error_string", "is_finished", "peers_connected", "upload_ratio",
    "added_date", "download_dir", "metadata_percent_complete",
    "recheck_progress", "queue_position",
]

# Detay ekranı -- daha pahalı, yalnızca tek torrent için istenir.
DETAIL_FIELDS = LIST_FIELDS + [
    "hash_string", "comment", "creator", "date_created", "pieces_count",
    "piece_size", "downloaded_ever", "uploaded_ever", "corrupt_ever",
    "have_valid", "desired_available", "peers_sending_to_us",
    "peers_getting_from_us", "webseeds_sending_to_us", "seed_ratio_limit",
    "seed_ratio_mode", "download_limit", "download_limited", "upload_limit",
    "upload_limited", "bandwidth_priority", "activity_date", "done_date",
    "magnet_link", "tracker_stats", "files", "file_stats", "wanted",
    "priorities", "labels",
]


def log(msg):
    print("[Transmission4] %s" % msg)


def statusText(t):
    if t.get("error"):
        return _("Hata")
    st = t.get("status", -1)
    if st == STATUS_CHECK:
        return "%s %d%%" % (STATUS_TEXT[STATUS_CHECK],
                            int(t.get("recheck_progress", 0) * 100))
    if st == STATUS_DOWNLOAD and t.get("metadata_percent_complete", 1) < 1:
        return _("Meta veri alınıyor")
    return STATUS_TEXT.get(st, "?")


class TorrentClient(object):

    def __init__(self):
        self.rpc = None
        self.torrents = []
        self.stats = {}
        self.session = {}
        self.lastError = None
        self.lastUpdate = 0

        # dinleyiciler -- ekranlar açılırken ekler, kapanırken çıkarır
        self.onUpdate = []
        self.onError = []
        self.onFinished = []          # fn(torrent) -- indirme tamamlandı

        # tamamlanma tespiti için önceki durum: id -> percent_done
        self._progress = {}
        self._seenIds = set()

        self._timer = eTimer()
        # DreamOS sigc++: bağlantı nesnesi saklanmazsa callback hiç çalışmaz
        self._timer_conn = self._timer.timeout.connect(self._tick)
        self._interval = 0
        self._foreground = 0          # kaç ekran açık

        self._inflight = False

    # ------------------------------------------------------------ bağlantı

    def configure(self):
        """Ayarlardan yeni bir RPC istemcisi kurar (ayar değişince çağrılır)."""
        self.rpc = TransmissionRPC(
            host=cfg.host.value.strip() or "127.0.0.1",
            port=cfg.port.value,
            username=cfg.username.value.strip(),
            password=cfg.password.value,
        )
        self._progress = {}
        self._seenIds = set()
        self.torrents = []
        self.lastError = None
        return self.rpc

    def ensure(self):
        if self.rpc is None:
            self.configure()
        return self.rpc

    def probe(self, callback=None, errback=None):
        rpc = self.ensure()

        def ok(args):
            self.session.update(args)
            if callback:
                callback(args)

        def fail(err):
            self.lastError = err
            self._emitError(err)
            if errback:
                errback(err)

        rpc.probe(ok, fail)

    # ------------------------------------------------------------ yoklama

    def acquire(self):
        """Bir ekran açıldı: ön plan hızında yokla."""
        self._foreground += 1
        self._reschedule()
        self.refresh()

    def release(self):
        """Ekran kapandı."""
        if self._foreground > 0:
            self._foreground -= 1
        self._reschedule()

    def startBackground(self):
        self._reschedule()

    def stopAll(self):
        self._timer.stop()
        self._interval = 0

    def _reschedule(self):
        if self._foreground > 0:
            interval = int(cfg.refresh.value)
        elif cfg.background_poll.value:
            interval = int(cfg.background_refresh.value)
        else:
            interval = 0

        if interval == self._interval:
            return
        self._interval = interval
        self._timer.stop()
        if interval:
            self._timer.start(interval, False)

    def _tick(self):
        self.refresh()

    def refresh(self):
        """Torrent listesi + oturum istatistiklerini çeker."""
        rpc = self.ensure()
        if self._inflight:
            # Önceki istek hâlâ yolda. Yavaş ağda istekleri üst üste
            # yığmak daemon'ı da kutuyu da gereksiz yorar.
            return
        self._inflight = True

        def onTorrents(args):
            self._inflight = False
            self.lastError = None
            self.lastUpdate = time.time()
            torrents = args.get("torrents") or []
            self._detectFinished(torrents)
            self.torrents = torrents
            self._fetchStats()

        def onErr(err):
            self._inflight = False
            self.lastError = err
            self._emitError(err)

        rpc.call("torrent_get", {"fields": LIST_FIELDS}, onTorrents, onErr)

    def _fetchStats(self):
        def ok(args):
            self.stats = args
            self._emitUpdate()

        def fail(err):
            # istatistik gelmese de liste geçerli
            self.stats = {}
            self._emitUpdate()

        self.rpc.call("session_stats", {}, ok, fail)

    # ------------------------------------------- tamamlanma tespiti

    def _detectFinished(self, torrents):
        """percent_done'un 1.0'a GEÇTİĞİ anı yakalar.

        "is_finished" kullanılmaz: o alan yalnızca gönderim (seed) oranı
        limitine ulaşınca True olur, indirmenin bitmesiyle ilgili değildir.
        İlk yoklamada zaten bitmiş torrentler bildirilmez -- yoksa eklenti
        her açılışta eski indirmeleri yeniden duyururdu.
        """
        first = not self._seenIds
        for t in torrents:
            tid = t.get("id")
            done = float(t.get("percent_done") or 0)
            prev = self._progress.get(tid)
            self._progress[tid] = done
            if first or tid not in self._seenIds:
                self._seenIds.add(tid)
                continue
            if prev is not None and prev < 1.0 <= done:
                for fn in list(self.onFinished):
                    try:
                        fn(t)
                    except Exception as e:
                        log("bildirim hatası: %s" % e)
        self._seenIds.update(t.get("id") for t in torrents)

        # silinen torrentleri unut
        alive = set(t.get("id") for t in torrents)
        for tid in list(self._progress):
            if tid not in alive:
                del self._progress[tid]
                self._seenIds.discard(tid)

    # -------------------------------------------------------- dinleyiciler

    def _emitUpdate(self):
        for fn in list(self.onUpdate):
            try:
                fn(self.torrents, self.stats)
            except Exception as e:
                log("dinleyici hatası: %s" % e)

    def _emitError(self, err):
        for fn in list(self.onError):
            try:
                fn(err)
            except Exception as e:
                log("hata dinleyicisi hatası: %s" % e)

    # ------------------------------------------------------------ eylemler
    #
    # Hepsi "yap ve hemen yenile" biçiminde: daemon durumu anında değişir,
    # kullanıcı sonucu bir sonraki yoklamayı beklemeden görür.

    def _action(self, method, params, done=None, fail=None):
        def ok(args):
            self.refresh()
            if done:
                done(args)
        self.ensure().call(method, params, ok, fail or self._emitError)

    def start(self, ids, done=None, fail=None):
        self._action("torrent_start", {"ids": ids}, done, fail)

    def startNow(self, ids, done=None, fail=None):
        self._action("torrent_start_now", {"ids": ids}, done, fail)

    def stop(self, ids, done=None, fail=None):
        self._action("torrent_stop", {"ids": ids}, done, fail)

    def verify(self, ids, done=None, fail=None):
        self._action("torrent_verify", {"ids": ids}, done, fail)

    def reannounce(self, ids, done=None, fail=None):
        self._action("torrent_reannounce", {"ids": ids}, done, fail)

    def remove(self, ids, deleteData=False, done=None, fail=None):
        self._action("torrent_remove",
                     {"ids": ids, "delete_local_data": bool(deleteData)},
                     done, fail)

    def setFiles(self, tid, wanted, unwanted, done=None, fail=None):
        params = {"ids": [tid]}
        if wanted:
            params["files_wanted"] = wanted
        if unwanted:
            params["files_unwanted"] = unwanted
        self._action("torrent_set", params, done, fail)

    def setPriority(self, tid, high, normal, low, done=None, fail=None):
        params = {"ids": [tid]}
        if high:
            params["priority_high"] = high
        if normal:
            params["priority_normal"] = normal
        if low:
            params["priority_low"] = low
        self._action("torrent_set", params, done, fail)

    def add(self, filename=None, metainfo=None, downloadDir=None,
            paused=False, done=None, fail=None):
        """filename: magnet linki ya da .torrent yolu/URL'si.
        metainfo: base64'lenmiş .torrent içeriği.

        download_dir burada ARGÜMAN'dır; legacy protokolde adı "download-dir"
        (torrent alanı olarak ise "downloadDir"). rpc.NAMES bu ayrımı
        "download_dir_arg" anahtarıyla taşır.
        """
        params = {"paused": bool(paused)}
        if filename:
            params["filename"] = filename
        if metainfo:
            params["metainfo"] = metainfo
        if downloadDir:
            params["download_dir_arg"] = downloadDir
        self._action("torrent_add", params, done, fail)

    def getDetail(self, tid, done, fail=None):
        def ok(args):
            torrents = args.get("torrents") or []
            done(torrents[0] if torrents else None)
        self.ensure().call("torrent_get",
                           {"ids": [tid], "fields": DETAIL_FIELDS},
                           ok, fail or self._emitError)

    def sessionSet(self, params, done=None, fail=None):
        self._action("session_set", params, done, fail)

    def freeSpace(self, path, done, fail=None):
        self.ensure().call("free_space", {"path": path}, done,
                           fail or self._emitError)


# tek örnek -- tüm ekranlar bunu kullanır
client = TorrentClient()
