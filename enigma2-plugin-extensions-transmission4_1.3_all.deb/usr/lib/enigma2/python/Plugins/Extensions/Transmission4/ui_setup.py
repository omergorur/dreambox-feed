# -*- coding: utf-8 -*-
#
# Transmission4 - ayarlar ve canlı durum
#
# Durum bölümü kasten ayrıntılı: kutuya telnet'le girmeden "neden
# bağlanamıyor" sorusunu buradan yanıtlayabilmek gerekiyor.
#
from __future__ import print_function

import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.ScrollLabel import ScrollLabel
from Components.config import getConfigListEntry, configfile

from enigma import getDesktop, eTimer

from . import fmt
from . import daemon
from .client import client
from .settings import cfg, isLocal

try:
    _
except NameError:
    def _(txt):
        return txt


def isFHD():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:
        return False


def _skin():
    if isFHD():
        return """
        <screen name="Transmission4Setup" position="center,center" size="1500,960" title="Transmission ayarları">
            <widget name="config" position="25,20" size="1450,440" scrollbarMode="showOnDemand" />
            <widget name="status" position="25,480" size="1450,370" font="Regular;23" />
            <widget source="key_red" render="Label" position="25,880" size="350,45" font="Regular;26" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="385,880" size="350,45" font="Regular;26" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="745,880" size="350,45" font="Regular;26" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1105,880" size="370,45" font="Regular;26" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="Transmission4Setup" position="center,center" size="1000,640" title="Transmission ayarları">
        <widget name="config" position="15,15" size="970,290" scrollbarMode="showOnDemand" />
        <widget name="status" position="15,315" size="970,250" font="Regular;17" />
        <widget source="key_red" render="Label" position="15,585" size="235,32" font="Regular;19" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="255,585" size="235,32" font="Regular;19" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="495,585" size="235,32" font="Regular;19" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="735,585" size="250,32" font="Regular;19" foregroundColor="blue" halign="left" />
    </screen>"""


class Transmission4Setup(Screen, ConfigListScreen):

    REFRESH_MS = 3000

    def __init__(self, session):
        self.skin = _skin()
        Screen.__init__(self, session)
        self.setTitle(_("Transmission ayarları"))

        self["status"] = ScrollLabel("")
        self["key_red"] = StaticText(_("Vazgeç"))
        self["key_green"] = StaticText(_("Kaydet"))
        self["key_yellow"] = StaticText(_("Yenile"))
        self["key_blue"] = StaticText(_("Daemon"))

        ConfigListScreen.__init__(self, self._entries(), session=session)

        # "ok" bağlanmaz -- ConfigListScreen kendi haritasında kullanıyor
        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "cancel": self.keyCancel,
                "save": self.keySave,
                "red": self.keyCancel,
                "green": self.keySave,
                "yellow": self.updateStatus,
                "blue": self.daemonMenu,
            }, -1)

        self._daemonActive = None
        self._daemonText = ""

        self.timer = eTimer()
        self.timer_conn = self.timer.timeout.connect(self._tick)
        self.onLayoutFinish.append(self._onShown)
        self.onClose.append(self.timer.stop)

    def _onShown(self):
        self.updateStatus()
        self.timer.start(self.REFRESH_MS, False)

    def _tick(self):
        # Periyodik yenilemede systemctl ÇALIŞTIRILMAZ: her çağrı bir fork
        # demek ve ekran açık kaldıkça dakikada onlarca alt süreç olurdu.
        # Daemon durumu ekran açılışında, sarı tuşla yenilemede ve bir daemon
        # komutundan sonra sorulur; RPC bağlantısı zaten canlılığı gösterir.
        self.updateStatus(checkDaemon=False)

    def _entries(self):
        entries = [
            getConfigListEntry(_("Sunucu adresi"), cfg.host),
            getConfigListEntry(_("RPC portu"), cfg.port),
            getConfigListEntry(_("Kullanıcı adı (boşsa kimlik doğrulama yok)"),
                               cfg.username),
            getConfigListEntry(_("Parola"), cfg.password),
            getConfigListEntry(_("Liste yenileme aralığı"), cfg.refresh),
            getConfigListEntry(_("Arka planda da yokla"), cfg.background_poll),
        ]
        if cfg.background_poll.value:
            entries.append(getConfigListEntry(_("Arka plan aralığı"),
                                              cfg.background_refresh))
        entries += [
            getConfigListEntry(_("İndirme bitince bildir"), cfg.notify_finished),
            getConfigListEntry(_("Varsayılan indirme dizini"), cfg.download_dir),
        ]
        if isLocal():
            entries += [
                getConfigListEntry(_("Daemon'ı eklentiden yönet"),
                                   cfg.manage_daemon),
            ]
            if cfg.manage_daemon.value:
                entries.append(getConfigListEntry(_("systemd servis adı"),
                                                  cfg.service_name))
        entries.append(getConfigListEntry(_("Ayrıntılı günlük"), cfg.debug))
        return entries

    # ------------------------------------------------------------- durum

    def updateStatus(self, checkDaemon=True):
        # config listesi koşullu girdiler içeriyor; değişmişse yeniden kur
        self["config"].list = self._entries()

        if checkDaemon and daemon.available():
            daemon.isActive(self._daemonStatus)
        elif not daemon.available():
            self._daemonActive = None
            self._daemonText = ""

        # RPC durumunu tazele
        if client.rpc is None or client.rpc.host != cfg.host.value.strip() \
                or client.rpc.port != cfg.port.value:
            client.configure()
        client.probe(lambda args: self._render(), lambda err: self._render())

    def _daemonStatus(self, active, text):
        self._daemonActive = active
        self._daemonText = text
        self._render()

    def _render(self):
        lines = []

        binary = daemon.installed()
        if isLocal():
            if binary:
                lines.append(_("Daemon binary: %s") % binary)
            else:
                lines.append(_("Daemon binary BULUNAMADI -- "
                               "transmission-daemon paketi kurulu mu?"))
            if self._daemonActive is None:
                lines.append(_("systemd durumu: bilinmiyor"))
            else:
                lines.append(_("systemd durumu: %s (%s)") % (
                    _("çalışıyor") if self._daemonActive else _("durdu"),
                    self._daemonText or "-"))
        else:
            lines.append(_("Uzak sunucu: %s -- daemon yönetimi kapalı")
                         % cfg.host.value)

        lines.append("")
        rpc = client.rpc
        if rpc is not None and rpc.connected:
            lines.append(_("RPC bağlantısı: TAMAM  (%s)") % rpc.url)
            lines.append(_("Daemon sürümü: %s   rpc-version: %s   protokol: %s")
                         % (rpc.server_version, rpc.rpc_version,
                            "JSON-RPC 2.0" if rpc.modern else "legacy"))
            sess = client.session or {}
            lines.append(_("Daemon indirme dizini: %s")
                         % sess.get("download_dir", "-"))
            lines.append(_("Yapılandırma dizini: %s")
                         % sess.get("config_dir", "-"))
            lines.append(_("Eş portu: %s") % sess.get("peer_port", "-"))
            lines.append(_("Torrent sayısı: %d") % len(client.torrents))
        else:
            err = (rpc.last_error if rpc else None) or _("henüz denenmedi")
            lines.append(_("RPC bağlantısı: YOK -- %s") % err)
            lines.append(_("Adres: %s") % (rpc.url if rpc else "-"))

        lines.append("")
        target = cfg.download_dir.value
        if target and os.path.isdir(target):
            try:
                st = os.statvfs(target)
                lines.append(_("%s boş alan: %s") % (
                    target, fmt.size(st.f_bavail * st.f_frsize)))
            except OSError:
                pass
        else:
            lines.append(_("İndirme dizini yok: %s") % target)

        self["status"].setText("\n".join(lines))

    # ------------------------------------------------------------ daemon

    def daemonMenu(self):
        if not daemon.available():
            self.session.open(
                MessageBox,
                _("Daemon yönetimi yalnızca sunucu bu kutudayken ve\n"
                  "\"Daemon'ı eklentiden yönet\" açıkken kullanılabilir."),
                MessageBox.TYPE_INFO, timeout=8)
            return
        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(
            self._daemonAnswer, ChoiceBox, title=_("Transmission daemon"),
            list=[
                (_("Başlat"), "start"),
                (_("Durdur"), "stop"),
                (_("Yeniden başlat"), "restart"),
                (_("Açılışta otomatik başlat"), "enable"),
                (_("Açılışta başlatma"), "disable"),
            ])

    def _daemonAnswer(self, choice):
        if not choice or not choice[1]:
            return
        fn = {"start": daemon.start, "stop": daemon.stop,
              "restart": daemon.restart, "enable": daemon.enable,
              "disable": daemon.disable}[choice[1]]
        fn(self._daemonDone)

    def _daemonDone(self, code, text):
        if code != 0 and text:
            self.session.open(MessageBox, text, MessageBox.TYPE_ERROR,
                              timeout=8)
        self.updateStatus()

    # ---------------------------------------------------------- kaydetme

    def keySave(self):
        self.saveAll()
        configfile.save()
        # bağlantı ayarları değişmiş olabilir: istemciyi yeniden kur
        client.configure()
        client.probe(lambda args: None, lambda err: None)
        client.startBackground()
        self.close()


def openSetup(session, **kwargs):
    session.open(Transmission4Setup)
