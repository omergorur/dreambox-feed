# -*- coding: utf-8 -*-
#
# Transmission4 - sayı/zaman biçimlendirme
#
# Transmission bayt cinsinden ve SI (1000) tabanlı gösterir; burada da öyle
# yapılıyor ki eklentideki rakam web arayüzündekiyle aynı çıksın.
#
try:
    _
except NameError:
    def _(txt):
        return txt

_UNITS = ("B", "kB", "MB", "GB", "TB", "PB")


def size(num):
    try:
        num = float(num or 0)
    except (TypeError, ValueError):
        return "-"
    if num < 0:
        return "-"
    for i, unit in enumerate(_UNITS):
        if num < 1000 or i == len(_UNITS) - 1:
            if unit == "B":
                return "%d B" % int(num)
            return "%.1f %s" % (num, unit)
        num /= 1000.0
    return "-"


def speed(bytes_per_sec):
    try:
        v = float(bytes_per_sec or 0)
    except (TypeError, ValueError):
        return "0 kB/s"
    if v <= 0:
        return "0 kB/s"
    return "%s/s" % size(v)


def eta(seconds):
    """Transmission -1 = bilinmiyor, -2 = hiç (sonsuz) demektir."""
    try:
        s = int(seconds)
    except (TypeError, ValueError):
        return "-"
    if s < 0:
        return "-"
    if s < 60:
        return "%d sn" % s
    if s < 3600:
        return "%d dk" % (s // 60)
    if s < 86400:
        return "%d sa %d dk" % (s // 3600, (s % 3600) // 60)
    return "%d gün %d sa" % (s // 86400, (s % 86400) // 3600)


def percent(fraction):
    try:
        return "%.1f%%" % (float(fraction or 0) * 100.0)
    except (TypeError, ValueError):
        return "0.0%"


def ratio(value):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "-"
    if v < 0:
        return "-"
    return "%.2f" % v


def date(timestamp):
    import time
    try:
        ts = int(timestamp)
    except (TypeError, ValueError):
        return "-"
    if ts <= 0:
        return "-"
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(ts))
