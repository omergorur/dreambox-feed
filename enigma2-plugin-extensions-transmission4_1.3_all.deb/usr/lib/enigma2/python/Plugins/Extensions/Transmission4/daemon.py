# -*- coding: utf-8 -*-
#
# Transmission4 - yerel daemon yönetimi (systemd)
#
# ÖNEMLİ: enigma2 içinde twisted'ın süreç API'si (reactor.spawnProcess,
# twisted.internet.utils.getProcessOutputAndValue) KULLANILAMAZ.
#
# mytest.py:211 reactor'ı şöyle başlatır:
#
#     reactor.run(installSignalHandlers=False)
#
# yani twisted'ın SIGCHLD işleyicisi hiç kurulmaz. Sonuç zinciri:
#
#   1. spawnProcess ile başlatılan systemctl biter ama reap EDİLMEZ
#      -> "systemctl <defunct>" zombie'leri birikir (parent: enigma2),
#   2. sürecin stdout/stderr pipe'ları reactor'da kayıtlı kalır; süreç
#      ölünce POLLHUP/POLLERR gelir ve kimse işlemez,
#   3. enigma2'nin ana döngüsü her turda
#         poll: unhandled POLLHUP for fd 431 pipe:[22003]
#      basar -- saniyede onlarca satır,
#   4. systemd-journald (ForwardToSyslog=yes olduğu için syslogd de) CPU'yu
#      yer; journald %99'a çıkar ve OSD gözle görülür şekilde kasar.
#
# Bu yüzden alt süreç burada subprocess.Popen ile başlatılıp eTimer ile
# yoklanıyor: pipe'lar reactor'a hiç kaydedilmiyor ve poll() süreci reap
# ediyor. Ana döngü yine bloke olmuyor.
#
from __future__ import print_function

import os
import subprocess

from enigma import eTimer

from .settings import cfg, isLocal

SYSTEMCTL = "/bin/systemctl"
CONFIG_DIR = "/root/.config/transmission-daemon"
LEGACY_CONFIG_DIR = "/root/.transmission-daemon"

POLL_MS = 200            # alt sürecin bitip bitmediğine bakma aralığı
TIMEOUT_MS = 20000       # bu süreyi aşan komut öldürülür
MAX_OUTPUT = 64 * 1024   # pipe'ı taşırmamak için üst sınır

# Çalışan komutlar. Referans tutulmazsa çöp toplayıcı eTimer'ı da bağlantı
# nesnesini de alır ve callback hiç çalışmaz (DreamOS sigc++ kuralı).
_running = set()


def log(msg):
    print("[Transmission4][daemon] %s" % msg)


def available():
    """Yerel daemon yönetimi mümkün mü?"""
    return isLocal() and cfg.manage_daemon.value and os.path.exists(SYSTEMCTL)


class _Command(object):
    """Tek bir systemctl çağrısı: non-blocking, zombie bırakmaz."""

    def __init__(self, args, callback):
        self.callback = callback
        self.elapsed = 0
        self.proc = None
        try:
            self.proc = subprocess.Popen(
                [SYSTEMCTL] + list(args),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                close_fds=True)
        except (OSError, ValueError) as e:
            self._done(-1, str(e))
            return

        _running.add(self)
        self.timer = eTimer()
        self.timer_conn = self.timer.timeout.connect(self._check)
        self.timer.start(POLL_MS, False)
        self._check()          # kısa komutlar ilk turda bitmiş olabilir

    def _check(self):
        code = self.proc.poll()          # poll() aynı zamanda reap eder
        if code is None:
            self.elapsed += POLL_MS
            if self.elapsed >= TIMEOUT_MS:
                self._kill()
                self._finish(-1, "zaman aşımı")
            return
        # Süreç bitti: pipe'ta EOF var, read() bloke olmaz.
        try:
            out = self.proc.stdout.read(MAX_OUTPUT)
        except (IOError, OSError):
            out = b""
        self._closePipe()
        self._finish(code, out)

    def _kill(self):
        try:
            self.proc.kill()
            self.proc.wait()             # zombie bırakma
        except (OSError, AttributeError):
            pass
        self._closePipe()

    def _closePipe(self):
        try:
            if self.proc.stdout:
                self.proc.stdout.close()
        except (IOError, OSError):
            pass

    def _finish(self, code, out):
        try:
            self.timer.stop()
        except AttributeError:
            pass
        _running.discard(self)
        if not isinstance(out, str):
            out = out.decode("utf-8", "replace")
        self._done(code, out.strip())

    def _done(self, code, text):
        if self.callback:
            try:
                self.callback(code, text)
            except Exception as e:
                log("callback hatası: %s" % e)


def _run(args, callback=None):
    """systemctl'i non-blocking çalıştırır. callback(çıkış_kodu, çıktı)."""
    if not os.path.exists(SYSTEMCTL):
        if callback:
            callback(127, "systemctl yok")
        return
    _Command(args, callback)


def isActive(callback):
    """callback(True/False, ham_metin)"""
    def done(code, text):
        callback(text.startswith("active"), text)
    _run(["is-active", cfg.service_name.value], done)


def isEnabled(callback):
    def done(code, text):
        callback(text.startswith("enabled"), text)
    _run(["is-enabled", cfg.service_name.value], done)


def start(callback=None):
    _run(["start", cfg.service_name.value], callback)


def stop(callback=None):
    _run(["stop", cfg.service_name.value], callback)


def restart(callback=None):
    _run(["restart", cfg.service_name.value], callback)


def enable(callback=None):
    _run(["enable", cfg.service_name.value], callback)


def disable(callback=None):
    _run(["disable", cfg.service_name.value], callback)


def shutdown():
    """Eklenti kapanırken: bekleyen komut kalmasın."""
    for cmd in list(_running):
        cmd._kill()
        _running.discard(cmd)


def installed():
    """Daemon binary'si kutuda var mı?"""
    for p in ("/usr/bin/transmission-daemon",
              "/usr/local/bin/transmission-daemon"):
        if os.path.exists(p):
            return p
    return None


def configDir():
    """Daemon'ın settings.json'ının bulunduğu dizin.

    Transmission önce $XDG_CONFIG_HOME/transmission-daemon'a bakar; eski
    kurulumlardan kalan ~/.transmission-daemon da hâlâ kullanılır.
    """
    for p in (CONFIG_DIR, LEGACY_CONFIG_DIR):
        if os.path.isdir(p):
            return p
    return CONFIG_DIR
