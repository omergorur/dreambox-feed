# -*- coding: utf-8 -*-
#
# Transmission4 - torrent ekleme (magnet / .torrent dosyası / URL)
#
from __future__ import print_function

import base64
import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.FileList import FileList
from Components.config import (getConfigListEntry, ConfigText, ConfigYesNo,
                               ConfigSelection, ConfigSubsection, config,
                               NoSave)

from enigma import getDesktop

from .client import client
from .settings import cfg
from . import fmt

try:
    _
except NameError:
    def _(txt):
        return txt


def isFHD():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:
        return False


# --------------------------------------------------------------- dosya seçici

def _browserSkin():
    if isFHD():
        return """
        <screen name="Transmission4FileBrowser" position="center,center" size="1400,900" title=".torrent dosyası seç">
            <widget name="list" position="25,20" size="1350,780" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="25,825" size="440,45" font="Regular;26" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="480,825" size="440,45" font="Regular;26" foregroundColor="green" halign="left" />
        </screen>"""
    return """
    <screen name="Transmission4FileBrowser" position="center,center" size="900,600" title=".torrent dosyası seç">
        <widget name="list" position="15,15" size="870,510" scrollbarMode="showOnDemand" />
        <widget source="key_red" render="Label" position="15,540" size="290,32" font="Regular;19" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="315,540" size="290,32" font="Regular;19" foregroundColor="green" halign="left" />
    </screen>"""


class Transmission4FileBrowser(Screen):
    """Yalnızca .torrent dosyalarını gösteren basit gezgin."""

    def __init__(self, session, directory="/media/hdd"):
        self.skin = _browserSkin()
        Screen.__init__(self, session)
        self.setTitle(_(".torrent dosyası seç"))

        if not os.path.isdir(directory):
            directory = "/media/hdd" if os.path.isdir("/media/hdd") else "/"

        self["list"] = FileList(directory, matchingPattern=r"(?i)^.*\.torrent$")
        self["key_red"] = StaticText(_("Vazgeç"))
        self["key_green"] = StaticText(_("Seç"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "ok": self.ok,
                "cancel": self.cancel,
                "red": self.cancel,
                "green": self.ok,
            }, -1)

    def ok(self):
        if self["list"].canDescent():
            self["list"].descent()
            return
        path = self["list"].getCurrentDirectory()
        name = self["list"].getFilename()
        if not name:
            return
        self.close(os.path.join(path or "", name))

    def cancel(self):
        self.close(None)


# ------------------------------------------------------------- ekleme ekranı

def _addSkin():
    if isFHD():
        return """
        <screen name="Transmission4Add" position="center,center" size="1400,720" title="Torrent ekle">
            <widget name="config" position="25,20" size="1350,360" scrollbarMode="showOnDemand" />
            <widget name="hint" position="25,400" size="1350,220" font="Regular;24" />
            <widget source="key_red" render="Label" position="25,645" size="330,45" font="Regular;26" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="365,645" size="330,45" font="Regular;26" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="705,645" size="330,45" font="Regular;26" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1045,645" size="330,45" font="Regular;26" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="Transmission4Add" position="center,center" size="960,520" title="Torrent ekle">
        <widget name="config" position="15,15" size="930,250" scrollbarMode="showOnDemand" />
        <widget name="hint" position="15,275" size="930,160" font="Regular;18" />
        <widget source="key_red" render="Label" position="15,460" size="225,32" font="Regular;19" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="245,460" size="225,32" font="Regular;19" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="475,460" size="225,32" font="Regular;19" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="705,460" size="230,32" font="Regular;19" foregroundColor="blue" halign="left" />
    </screen>"""


class Transmission4Add(Screen, ConfigListScreen):

    def __init__(self, session, preset=None):
        self.skin = _addSkin()
        Screen.__init__(self, session)
        self.setTitle(_("Torrent ekle"))

        # NoSave: bunlar kalıcı ayar değil, tek seferlik giriş
        self.source = NoSave(ConfigSelection(default="magnet", choices=[
            ("magnet", _("Magnet linki / URL")),
            ("file", _(".torrent dosyası")),
        ]))
        self.link = NoSave(ConfigText(default=preset or "", fixed_size=False))
        self.path = NoSave(ConfigText(default="", fixed_size=False))
        self.target = NoSave(ConfigText(default=cfg.download_dir.value,
                                        fixed_size=False))
        self.paused = NoSave(ConfigYesNo(default=False))

        self["hint"] = Label("")
        self["key_red"] = StaticText(_("Vazgeç"))
        self["key_green"] = StaticText(_("Ekle"))
        self["key_yellow"] = StaticText(_("Dosya seç"))
        self["key_blue"] = StaticText(_("Dizin seç"))

        ConfigListScreen.__init__(self, [], session=session,
                                  on_change=self._changed)
        self._build()

        # "ok" BAĞLANMAZ: ConfigListScreen kendi haritasında kullanıyor,
        # bağlarsak ConfigText düzenleme bozulur (bkz. geliştirme notları §3)
        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "cancel": self.close,
                "save": self.doAdd,
                "red": self.close,
                "green": self.doAdd,
                "yellow": self.browse,
                "blue": self.chooseDir,
            }, -1)

        self.onLayoutFinish.append(self._updateHint)

    def _build(self):
        entries = [getConfigListEntry(_("Kaynak"), self.source)]
        if self.source.value == "magnet":
            entries.append(getConfigListEntry(_("Magnet / URL"), self.link))
        else:
            entries.append(getConfigListEntry(_(".torrent yolu"), self.path))
        entries.append(getConfigListEntry(_("İndirme dizini"), self.target))
        entries.append(getConfigListEntry(_("Duraklatılmış eklensin"),
                                          self.paused))
        self["config"].list = entries
        self.list = entries

    def _changed(self):
        # kaynak değişince liste yeniden kurulmalı
        self._build()
        self._updateHint()

    def _updateHint(self):
        lines = [
            _("Sarı: dosya sistemine göz at   Mavi: indirme dizinini seç"),
            _("Yeşil: ekle"),
            "",
        ]
        target = self.target.value
        if target and os.path.isdir(target):
            try:
                st = os.statvfs(target)
                free = st.f_bavail * st.f_frsize
                lines.append(_("%s içinde boş alan: %s") % (target,
                                                            fmt.size(free)))
            except OSError:
                pass
        else:
            lines.append(_("Dizin yok, ekleme sırasında oluşturulacak: %s")
                         % target)
        self["hint"].setText("\n".join(lines))

    # ---------------------------------------------------------- yardımcılar

    def browse(self):
        self.source.value = "file"
        self._build()
        start = self.path.value and os.path.dirname(self.path.value) \
            or cfg.browse_dir.value
        self.session.openWithCallback(self._browsed, Transmission4FileBrowser,
                                      start)

    def _browsed(self, path):
        if path:
            self.path.value = path
            cfg.browse_dir.value = os.path.dirname(path)
            self._build()

    def chooseDir(self):
        self.session.openWithCallback(
            self._dirChosen, LocationBox,
            text=_("İndirme dizini"),
            currDir=self.target.value or "/media/hdd",
            minFree=100)

    def _dirChosen(self, path):
        if path:
            self.target.value = path
            self._updateHint()

    # ---------------------------------------------------------------- ekle

    def doAdd(self):
        target = (self.target.value or "").strip() or None

        if self.source.value == "magnet":
            link = (self.link.value or "").strip()
            if not link:
                self._error(_("Magnet linki ya da URL girin."))
                return
            client.add(filename=link, downloadDir=target,
                       paused=self.paused.value,
                       done=self._added, fail=self._failed)
            return

        path = (self.path.value or "").strip()
        if not path or not os.path.isfile(path):
            self._error(_("Geçerli bir .torrent dosyası seçin."))
            return
        try:
            with open(path, "rb") as fh:
                blob = fh.read()
        except (IOError, OSError) as e:
            self._error(_("Dosya okunamadı: %s") % e)
            return

        # metainfo gönderiyoruz, "filename" değil: daemon başka bir makinede
        # olabilir ve o zaman yerel yolu göremezdi
        client.add(metainfo=base64.b64encode(blob).decode("ascii"),
                   downloadDir=target, paused=self.paused.value,
                   done=self._added, fail=self._failed)

    def _added(self, args):
        if "torrent_duplicate" in args:
            name = (args["torrent_duplicate"] or {}).get("name", "")
            self.session.open(MessageBox,
                              _("Bu torrent zaten listede:\n%s") % name,
                              MessageBox.TYPE_INFO, timeout=6)
            self.close()
            return
        added = args.get("torrent_added") or {}
        self.session.open(MessageBox,
                          _("Eklendi:\n%s") % added.get("name", ""),
                          MessageBox.TYPE_INFO, timeout=5)
        self.close()

    def _failed(self, err):
        self._error(_("Eklenemedi: %s") % err)

    def _error(self, text):
        self.session.open(MessageBox, text, MessageBox.TYPE_ERROR, timeout=8)
