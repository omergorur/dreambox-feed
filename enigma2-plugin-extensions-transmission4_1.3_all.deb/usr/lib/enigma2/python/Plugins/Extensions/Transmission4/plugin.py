# -*- coding: utf-8 -*-
#
# Transmission4 -- Transmission 4.x için enigma2 istemcisi (DreamOS)
#
# Piyasadaki eklentiler Transmission 3.00'a takılı kalmıştı: opendreambox
# 2.6 (Yocto pyro) OpenSSL 1.0.2 / libevent 2.0 / libstdc++ 6.0.22 taşıyor,
# Transmission 4 ise OpenSSL >= 1.1, libevent >= 2.1 ve C++17 istiyor.
# Çözüm daemon'ı statik derlemek; bu eklenti de yalnızca RPC konuşur, yani
# daemon'ın nasıl kurulduğundan bağımsızdır.
#
# Ekranlar: Plugins/Extensions/Transmission4/ui_*.py
# RPC:      rpc.py (JSON-RPC 2.0 + legacy, otomatik seçim)
#
from __future__ import print_function

VERSION = "1.3"

from Plugins.Plugin import PluginDescriptor

from .settings import cfg
from .client import client

try:
    _
except NameError:
    def _(txt):
        return txt

_session = None


def log(msg):
    print("[Transmission4] %s" % msg)


def notify(text):
    """Kısa bildirim. toastManager DreamOS'ta var; yoksa günlüğe düş."""
    global _session
    if _session is None:
        log(text)
        return
    try:
        _session.toastManager.showToast(text)
    except Exception:
        try:
            from Screens.MessageBox import MessageBox
            _session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=8)
        except Exception:
            log(text)


def onFinished(torrent):
    if not cfg.notify_finished.value:
        return
    notify(_("İndirme tamamlandı: %s") % (torrent.get("name") or ""))


def sessionstart(reason, session=None, **kwargs):
    global _session
    if reason == 0:
        _session = session
        client.configure()
        if onFinished not in client.onFinished:
            client.onFinished.append(onFinished)
        # Arka plan yoklaması: tamamlanma bildirimi için gerekli. İlk
        # yoklamada mevcut torrentler "yeni bitmiş" sayılmaz (bkz.
        # client._detectFinished).
        client.startBackground()
        log("v%s başlatıldı" % VERSION)
    elif reason == 1:
        client.stopAll()
        if onFinished in client.onFinished:
            client.onFinished.remove(onFinished)
        # bekleyen systemctl varsa geride bırakma
        from . import daemon
        daemon.shutdown()
        _session = None


def openList(session, **kwargs):
    from .ui_list import Transmission4List
    session.open(Transmission4List)


def openSetup(session, **kwargs):
    from .ui_setup import Transmission4Setup
    session.open(Transmission4Setup)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Transmission4",
            description="Transmission 4.x RPC istemcisi -- arka plan yoklaması",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            needsRestart=False,
            fnc=sessionstart),
        PluginDescriptor(
            name=_("Transmission"),
            description=_("Torrent indirmelerini yönet (Transmission 4.x)"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            needsRestart=False,
            fnc=openList),
        PluginDescriptor(
            name=_("Transmission"),
            description=_("Torrent listesi"),
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            needsRestart=False,
            fnc=openList),
    ]
