# -*- coding: utf-8 -*-
#
# Transmission RPC istemcisi -- bağımlılıksız, tam non-blocking.
#
# Neden kendi istemcimiz: feed'deki python-transmissionrpc 0.11 (2013) RPC
# sürüm 15'e kadar biliyor ve blocking urllib2 kullanıyor; enigma2'nin ana
# döngüsünü kilitler. Burada twisted.web.client.Agent kullanılıyor -- kutuda
# twisted 20.3.0 hazır, ekstra paket gerekmiyor.
#
# İKİ PROTOKOL VARDIR:
#
#   legacy   Transmission 3.x ve 4.0.x'in tek protokolü, 4.1'de hâlâ çalışıyor
#            ama "deprecated". Zarf: {"method":"torrent-get",
#            "arguments":{...}, "tag":N}. Alan adları kebab-case ve camelCase
#            karışık (spec'in kendi ifadesi).
#
#   modern   Transmission 4.1.0+ ile gelen JSON-RPC 2.0. Zarf:
#            {"jsonrpc":"2.0","method":"torrent_get","params":{...},"id":N}.
#            Alan adlarının tamamı snake_case.
#
# Bu modül İÇERİDE HEP snake_case (modern) isimleri kullanır. Karşı taraf eski
# ise isimler NAMES tablosundan çevrilir. Tablo otomatik türetilmez -- legacy
# adlandırma tutarsız olduğu için (torrent alanları camelCase, argümanlar
# kebab-case) tahmin sessizce yanlış istek üretirdi.
#
from __future__ import print_function

import base64
import json
from io import BytesIO

from twisted.internet import reactor
from twisted.web.client import Agent, readBody, FileBodyProducer
from twisted.web.http_headers import Headers

SESSION_HEADER = b"X-Transmission-Session-Id"

# Python 2'de json.loads HER string'i unicode dondurur. enigma2'nin C++
# tarafi (eLabel.setText, MultiContentEntryText) ise utf-8 kodlanmis BYTE
# string bekler; unicode verilince liste satirinda "<not-a-string>" yazar ve
# setText SWIG TypeError firlatir. Bu yuzden gelen veri native str'e,
# giden veri (json.dumps ascii disi baytlari kendisi kacamaz) unicode'a
# cevrilir. Python 3'te iki donusum de islevsizdir.
_PY2 = str is bytes

# rpc-version >= bu ise karşı taraf JSON-RPC 2.0 konuşabiliyor demektir.
# 16 = Transmission 3.00, 17 = 4.0.x, 19 = 4.1.x
RPC_VERSION_JSONRPC2 = 19


def log(msg):
    print("[Transmission4][rpc] %s" % msg)


# --- isim eşlemesi: modern (snake_case) -> legacy -------------------------
#
# Yalnızca bu eklentinin kullandığı adlar. Tabloda olmayan bir ad legacy
# modda olduğu gibi gönderilir; yeni bir alan kullanacaksan buraya da eklemen
# gerekir.
NAMES = {
    # metotlar
    "torrent_get": "torrent-get",
    "torrent_add": "torrent-add",
    "torrent_start": "torrent-start",
    "torrent_start_now": "torrent-start-now",
    "torrent_stop": "torrent-stop",
    "torrent_remove": "torrent-remove",
    "torrent_set": "torrent-set",
    "torrent_verify": "torrent-verify",
    "torrent_reannounce": "torrent-reannounce",
    "session_get": "session-get",
    "session_set": "session-set",
    "session_stats": "session-stats",
    "free_space": "free-space",
    # torrent alanları (legacy'de camelCase)
    "percent_done": "percentDone",
    "rate_download": "rateDownload",
    "rate_upload": "rateUpload",
    "total_size": "totalSize",
    "size_when_done": "sizeWhenDone",
    "left_until_done": "leftUntilDone",
    "peers_connected": "peersConnected",
    "peers_sending_to_us": "peersSendingToUs",
    "peers_getting_from_us": "peersGettingFromUs",
    "error_string": "errorString",
    "download_dir": "downloadDir",
    "upload_ratio": "uploadRatio",
    "added_date": "addedDate",
    "done_date": "doneDate",
    "is_finished": "isFinished",
    "hash_string": "hashString",
    "magnet_link": "magnetLink",
    "tracker_stats": "trackerStats",
    "seed_ratio_limit": "seedRatioLimit",
    "seed_ratio_mode": "seedRatioMode",
    "download_limit": "downloadLimit",
    "download_limited": "downloadLimited",
    "upload_limit": "uploadLimit",
    "upload_limited": "uploadLimited",
    "recheck_progress": "recheckProgress",
    "bandwidth_priority": "bandwidthPriority",
    "activity_date": "activityDate",
    "corrupt_ever": "corruptEver",
    "downloaded_ever": "downloadedEver",
    "uploaded_ever": "uploadedEver",
    "have_valid": "haveValid",
    "have_unchecked": "haveUnchecked",
    "desired_available": "desiredAvailable",
    "file_stats": "fileStats",
    "bytes_completed": "bytesCompleted",
    "metadata_percent_complete": "metadataPercentComplete",
    "webseeds_sending_to_us": "webseedsSendingToUs",
    # torrent-add / torrent-set argümanları (legacy'de kebab-case).
    # "download_dir" hem torrent ALANI (camelCase) hem argüman (kebab-case)
    # olduğu için argüman biçimi ayrı bir anahtarla tutulur.
    "download_dir_arg": "download-dir",
    "files_wanted": "files-wanted",
    "files_unwanted": "files-unwanted",
    "priority_high": "priority-high",
    "priority_normal": "priority-normal",
    "priority_low": "priority-low",
    "delete_local_data": "delete-local-data",
    "torrent_added": "torrent-added",
    "torrent_duplicate": "torrent-duplicate",
    # session alanları (legacy'de kebab-case)
    "rpc_version": "rpc-version",
    "rpc_version_semver": "rpc-version-semver",
    "speed_limit_down": "speed-limit-down",
    "speed_limit_down_enabled": "speed-limit-down-enabled",
    "speed_limit_up": "speed-limit-up",
    "speed_limit_up_enabled": "speed-limit-up-enabled",
    "alt_speed_enabled": "alt-speed-enabled",
    "alt_speed_down": "alt-speed-down",
    "alt_speed_up": "alt-speed-up",
    "peer_port": "peer-port",
    "peer_limit_global": "peer-limit-global",
    "peer_limit_per_torrent": "peer-limit-per-torrent",
    "watch_dir": "watch-dir",
    "watch_dir_enabled": "watch-dir-enabled",
    "incomplete_dir": "incomplete-dir",
    "incomplete_dir_enabled": "incomplete-dir-enabled",
    "start_added_torrents": "start-added-torrents",
    "rename_partial_files": "rename-partial-files",
    "config_dir": "config-dir",
    "download_queue_enabled": "download-queue-enabled",
    "download_queue_size": "download-queue-size",
    "version": "version",
    # session-stats
    "torrent_count": "torrentCount",
    "active_torrent_count": "activeTorrentCount",
    "paused_torrent_count": "pausedTorrentCount",
    "download_speed": "downloadSpeed",
    "upload_speed": "uploadSpeed",
    "cumulative_stats": "cumulative-stats",
    "current_stats": "current-stats",
    "uploaded_bytes": "uploadedBytes",
    "downloaded_bytes": "downloadedBytes",
    "files_added": "filesAdded",
    "session_count": "sessionCount",
    "seconds_active": "secondsActive",
}

# ters tablo: legacy yanıtı -> modern ad
_LEGACY_TO_MODERN = {}
for _modern, _legacy in NAMES.items():
    # "download_dir_arg" gibi yapay ayrımlar geri çevrilirken gerçek adı
    # ("download_dir") gölgelemesin
    if _modern.endswith("_arg"):
        continue
    _LEGACY_TO_MODERN.setdefault(_legacy, _modern)


def to_legacy(name):
    return NAMES.get(name, name)


def _keys_to_legacy(obj):
    if isinstance(obj, dict):
        return dict((to_legacy(k), _keys_to_legacy(v)) for k, v in obj.items())
    if isinstance(obj, list):
        return [_keys_to_legacy(v) for v in obj]
    return obj


def _keys_to_modern(obj):
    if isinstance(obj, dict):
        return dict((_LEGACY_TO_MODERN.get(k, k), _keys_to_modern(v))
                    for k, v in obj.items())
    if isinstance(obj, list):
        return [_keys_to_modern(v) for v in obj]
    return obj


def convert_strings(obj, from_type, convert):
    """İç içe JSON yapısındaki string'leri dönüştürür.

    Sözlük ANAHTARLARI da dönüştürülür; aksi halde Py2'de t["name"] araması
    u"name" anahtarını bulamazdı. Tip parametre olarak alınıyor ki Python 3
    üzerinde de sınanabilsin (bkz. _tools/test_transmission4.py) -- Py2
    davranışı ancak böyle test edilebiliyor."""
    if isinstance(obj, from_type):
        return convert(obj)
    if isinstance(obj, dict):
        return dict((convert_strings(k, from_type, convert),
                     convert_strings(v, from_type, convert))
                    for k, v in obj.items())
    if isinstance(obj, list):
        return [convert_strings(v, from_type, convert) for v in obj]
    return obj


def to_native(obj):
    """Gelen veri: unicode -> utf-8 byte string (yalnızca Python 2'de)."""
    if not _PY2:
        return obj
    return convert_strings(obj, unicode,                  # noqa: F821 (Py2)
                           lambda s: s.encode("utf-8"))


def to_json_safe(obj):
    """Giden veri: utf-8 byte string -> unicode (yalnızca Python 2'de).

    Py2'de json.dumps bir byte string'e rastlarsa onu ASCII sanar; Türkçe
    karakterli bir dizin yolu UnicodeDecodeError ile patlardı."""
    if not _PY2:
        return obj
    return convert_strings(obj, str, lambda s: s.decode("utf-8", "replace"))


def fields_to_legacy(fields):
    """torrent_get "fields" listesi -- değer olduğu için _keys_to_legacy
    dokunmaz, ayrıca çevrilmesi gerekir."""
    return [to_legacy(f) for f in fields]


class RPCError(Exception):
    pass


class _BytesProducer(object):
    """FileBodyProducer'in ince sarmalayicisi -- govde zaten bellekte."""

    def __init__(self, data):
        self._producer = FileBodyProducer(BytesIO(data))
        self.length = self._producer.length

    def startProducing(self, consumer):
        return self._producer.startProducing(consumer)

    def pauseProducing(self):
        self._producer.pauseProducing()

    def resumeProducing(self):
        self._producer.resumeProducing()

    def stopProducing(self):
        self._producer.stopProducing()


class TransmissionRPC(object):
    """Tek daemon'a bağlanan RPC istemcisi.

    Kullanım:
        rpc = TransmissionRPC("127.0.0.1", 9091)
        rpc.call("torrent_get", {"fields": ["id", "name"]},
                 lambda args: ..., lambda err: ...)

    Yanıt callback'i her zaman modern (snake_case) anahtarlarla gelir; karşı
    taraf eskiyse çeviri burada yapılır.
    """

    def __init__(self, host="127.0.0.1", port=9091, path="/transmission/rpc",
                 username="", password="", timeout=15):
        self.host = host
        self.port = int(port)
        self.path = path if path.startswith("/") else "/" + path
        self.username = username or ""
        self.password = password or ""
        self.timeout = timeout

        self._session_id = None
        self._tag = 0
        self._agent = Agent(reactor, connectTimeout=timeout)

        # None = henüz bilinmiyor. İlk probe() ile belirlenir.
        self.rpc_version = None
        self.server_version = None
        self.modern = False

        self.last_error = None
        self.connected = False

    # ------------------------------------------------------------ yardımcı

    @property
    def url(self):
        return "http://%s:%d%s" % (self.host, self.port, self.path)

    def _headers(self):
        h = {
            b"Content-Type": [b"application/json"],
            b"Accept": [b"application/json"],
            b"User-Agent": [b"Transmission4-enigma2"],
        }
        if self._session_id:
            h[SESSION_HEADER] = [self._session_id]
        if self.username:
            raw = "%s:%s" % (self.username, self.password)
            token = base64.b64encode(raw.encode("utf-8")).strip()
            h[b"Authorization"] = [b"Basic " + token]
        return Headers(h)

    def _envelope(self, method, params):
        self._tag += 1
        params = params or {}
        if self.modern:
            return {"jsonrpc": "2.0", "method": method,
                    "params": params, "id": self._tag}
        args = _keys_to_legacy(params)
        if "fields" in args and isinstance(args["fields"], list):
            args["fields"] = fields_to_legacy(params["fields"])
        return {"method": to_legacy(method), "arguments": args,
                "tag": self._tag}

    # --------------------------------------------------------------- çağrı

    def call(self, method, params=None, callback=None, errback=None,
             _retried=False):
        """method: modern ad ("torrent_get"). params: modern anahtarlar."""
        envelope = to_json_safe(self._envelope(method, params))
        body = json.dumps(envelope).encode("utf-8")

        d = self._agent.request(b"POST", self.url.encode("ascii"),
                                self._headers(), _BytesProducer(body))

        def onResponse(response):
            # CSRF el sıkışması: 409 + doğru oturum kimliği başlıkta gelir.
            if response.code == 409:
                ids = response.headers.getRawHeaders(SESSION_HEADER)
                if ids and not _retried:
                    sid = ids[0]
                    self._session_id = sid if isinstance(sid, bytes) \
                        else sid.encode("ascii")
                    # gövde tüketilmeden yeni istek açmak bağlantıyı sızdırır
                    dd = readBody(response)
                    dd.addBoth(lambda _ignored: self.call(
                        method, params, callback, errback, _retried=True))
                    return dd
                raise RPCError("409: oturum kimliği alınamadı")

            if response.code == 401:
                raise RPCError("401: kullanıcı adı/parola hatalı")

            body_d = readBody(response)
            body_d.addCallback(lambda raw: self._parse(response.code, raw))
            return body_d

        def onOk(result):
            # Yeniden denenen çağrıda callback zaten çalıştı; sonuç None gelir.
            if result is None:
                return None
            self.connected = True
            self.last_error = None
            if callback:
                callback(result)
            return result

        def onErr(failure):
            self.connected = False
            self.last_error = failure.getErrorMessage()
            if errback:
                errback(self.last_error)
            else:
                log("hata: %s" % self.last_error)
            return None

        d.addCallback(onResponse)
        d.addCallback(onOk)
        d.addErrback(onErr)
        return d

    def _parse(self, code, raw):
        if code != 200:
            raise RPCError("HTTP %d" % code)
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except ValueError:
            raise RPCError("geçersiz JSON yanıtı")

        # Py2'de json.loads her string'i unicode verir; enigma2 utf-8 byte
        # string bekler (bkz. to_native)
        data = to_native(data)

        if self.modern:
            # JSON-RPC 2.0: hata "error" nesnesinde, sonuç "result" içinde
            if "error" in data:
                err = data["error"]
                raise RPCError(err.get("message", str(err))
                               if isinstance(err, dict) else str(err))
            return data.get("result") or {}

        if data.get("result") != "success":
            raise RPCError(str(data.get("result", "bilinmeyen hata")))
        return _keys_to_modern(data.get("arguments") or {})

    # ---------------------------------------------------- sürüm tespiti

    def probe(self, callback=None, errback=None):
        """Karşı tarafın sürümünü öğrenir ve protokolü ona göre seçer.

        Yoklama HEP legacy ile yapılır: legacy istek her sürümde çalışır.
        Ters sıra (önce JSON-RPC 2.0) 4.0.x'te anlaşılmaz bir hata verirdi.
        """
        self.modern = False

        def ok(args):
            self.rpc_version = args.get("rpc_version")
            self.server_version = args.get("version")
            try:
                self.modern = int(self.rpc_version) >= RPC_VERSION_JSONRPC2
            except (TypeError, ValueError):
                self.modern = False
            log("daemon %s, rpc-version %s -> %s protokol"
                % (self.server_version, self.rpc_version,
                   "JSON-RPC 2.0" if self.modern else "legacy"))
            if callback:
                callback(args)

        self.call("session_get",
                  {"fields": ["version", "rpc_version", "download_dir",
                              "config_dir", "peer_port"]},
                  ok, errback)
