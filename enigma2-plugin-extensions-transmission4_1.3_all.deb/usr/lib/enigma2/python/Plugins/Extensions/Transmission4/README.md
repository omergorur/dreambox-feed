# Transmission4

Transmission **4.x** için enigma2 istemcisi — DreamOS / opendreambox 2.6
(Dreambox One / Two, aarch64).

Piyasadaki enigma2 Transmission eklentileri Transmission **3.00**'a takılı
kalmıştır. Sebebi eklentiler değil, imajdır:

| Kutuda (opendreambox 2.6 / Yocto pyro) | Transmission 4 ne istiyor |
|---|---|
| OpenSSL 1.0.2 | ≥ 1.1.0 |
| libevent 2.0.21 | ≥ 2.1.0 |
| libstdc++ 6.0.22 (GCC 6) | C++17 |
| glibc 2.25 | — |

Sistem kütüphaneleriyle Transmission 4 derlenemez. Çözüm daemon'ı **tam
statik** (musl) derlemektir; o zaman kutunun kütüphane sürümleri tamamen
önemsiz hale gelir. Bu eklenti ise daemon ile yalnızca **RPC** üzerinden
konuşur, yani daemon'ın nasıl kurulduğundan bağımsızdır.

## Protokol

Transmission 4.1 ile RPC ikiye ayrıldı:

- **legacy (bespoke)** — `{"method":"torrent-get","arguments":{…},"tag":N}`,
  alan adları kebab-case ve camelCase karışık. 3.00 ve 4.0.x'in tek
  protokolü; 4.1'de hâlâ çalışıyor ama *deprecated*.
- **JSON-RPC 2.0** — `{"jsonrpc":"2.0","method":"torrent_get","params":{…},
  "id":N}`, adların tamamı snake_case. 4.1.0+.

Eklenti açılışta `session-get` ile `rpc-version` sorar ve **19 ve üzeriyse**
JSON-RPC 2.0'a geçer. Böylece hem güncel hem eski daemon'larla çalışır.
Kod içinde her zaman snake_case kullanılır; legacy modda isimler
`rpc.NAMES` tablosundan çevrilir (tablo otomatik türetilmez — legacy
adlandırma tutarsız olduğu için tahmin sessizce yanlış istek üretirdi).

İki protokolde de aynı CSRF el sıkışması var: ilk istek **409** döner,
cevaptaki `X-Transmission-Session-Id` alınıp istek tekrarlanır.

## Özellikler

- Torrent listesi: ad, durum, ilerleme çubuğu, ↓/↑ hız, ETA, eş sayısı
- Başlat / durdur / sil (dosyalarla birlikte veya sadece listeden)
- Ekleme: magnet linki, URL, `.torrent` dosyası (dosya gezgini ile)
- Detay ekranı: tracker durumu, oran, eş dağılımı, hata mesajı
- Dosya seçimi: torrent içindeki dosyaları tek tek aç/kapat, öncelik ver
- İzleme klasörü (daemon'ın `watch-dir`'i) ve indirme bitince ekran bildirimi
- Daemon'ı eklentiden başlat / durdur / açılışta etkinleştir (systemd)
- Ayrıntılı durum ekranı — kutuya telnet'le girmeden teşhis

## Ekranlar

| Dosya | İş |
|---|---|
| `rpc.py` | RPC istemcisi (twisted Agent, 409 el sıkışması, protokol çevirisi) |
| `client.py` | tek yoklama noktası, tamamlanma tespiti, eylemler |
| `daemon.py` | systemd üzerinden daemon yönetimi (non-blocking) |
| `ui_list.py` | ana liste |
| `ui_detail.py` | detay + dosya seçimi |
| `ui_add.py` | torrent ekleme + dosya gezgini |
| `ui_setup.py` | ayarlar + canlı durum |
| `tools/rpc_probe.py` | enigma2'den bağımsız teşhis betiği |

## Teşhis

```sh
python /usr/lib/enigma2/python/Plugins/Extensions/Transmission4/tools/rpc_probe.py
```

Hangi aşamada takıldığını söyler: bağlantı yok mu, 401 mi, 409 el sıkışması
mı, hangi protokol destekleniyor, kaç torrent var.

## Notlar (DreamOS tuzakları)

- Liste widget'larına skin'den `font=` **verilmez**: DreamOS'ta `eListbox`'ta
  `setFont` yoktur, `skin.py/applySingleAttribute` `AttributeError` fırlatır
  ve ekran yeşile döner. Font Python'dan `eListboxPythonMultiContent` üzerinde
  ayarlanır — orada `setFont` vardır.
- `eTimer.timeout.connect()` dönen bağlantı nesnesi saklanmazsa çöp toplayıcı
  bağlantıyı koparır ve callback hiç çalışmaz.
- `ConfigListScreen` kendi ActionMap'inde `ok`'u kullanır; kendi haritamızda
  `ok` bağlanmaz, yoksa `ConfigText` düzenleme bozulur.
- Ağ istekleri ve `systemctl` çağrıları twisted üzerinden yapılır; hiçbiri
  enigma2'nin ana döngüsünü bloke etmez.

## Test

```sh
python _tools/test_transmission4.py            # protokol çevirisi, tespit, biçim
python _tools/test_skin_attrs_transmission4.py # yeşil ekran denetimi
```
