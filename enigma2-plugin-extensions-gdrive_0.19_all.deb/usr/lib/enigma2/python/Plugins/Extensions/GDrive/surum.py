# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_gdrive.py); depoda yok.
SURUM = "0.19"
COMMIT = "f7edc0b"
