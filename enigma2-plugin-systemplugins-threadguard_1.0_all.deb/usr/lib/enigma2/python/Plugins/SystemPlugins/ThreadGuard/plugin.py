# -*- coding: utf-8 -*-
"""
ThreadGuard -- arka plan is parcaciklarindan yapilan GUI cagrilarini ana
is parcacigina devreder.

NEDEN: enigma2'de ekranlar ve zamanlayicilar (eTimer) yalnizca ana is
parcacigindan kullanilabilir. Bazi eklentiler (olculdu: AJPanel, dizi
kategorisi yuklerken sunucu bir sayfada hata verince) ilerleme ekranini
arka plan is parcacigindan kapatiyor: Screen.close -> Session.close ->
execEnd + delay_timer.start. Bu sirada ana is parcacigi Python kilidini
(GIL) birakmis, poll() icinde bekliyor; sonuc: tum is parcaciklari GIL'i
bekler, enigma2 donar, kumanda cevap vermez.

Bu eklenti Screen.close, eTimer.start ve eTimer.stop'u sarmalar: ana is
parcacigindan gelen cagrilar oldugu gibi gecer; baska is parcacigindan
gelenler twisted reactor.callFromThread ile ana donguye kuyruklanir ve
cagiran yer (dosya:satir) bir kez gunluge yazilir:
    journalctl -u enigma2 | grep ThreadGuard
Sistem dosyalarina dokunmaz; sarmalama calisma zamanindadir.
"""
import threading
import traceback

from Plugins.Plugin import PluginDescriptor

_ETIKET = "[ThreadGuard]"
_gorulen = set()


def _ana_mi():
	return isinstance(threading.current_thread(), threading._MainThread)


def _kaydet(ne):
	yigin = traceback.extract_stack()[:-2]
	# cagiran: sarmalayicinin disindaki en yakin cerceve
	yer = "%s:%d %s" % yigin[-1][:3] if yigin else "?"
	anahtar = (ne, yer)
	if anahtar in _gorulen:
		return
	_gorulen.add(anahtar)
	print("%s %s ana is parcacigi disindan cagrildi (is parcacigi %s), ana donguye devredildi: %s"
		% (_ETIKET, ne, threading.current_thread().name, yer))
	for satir in traceback.format_list(yigin[-6:]):
		print("%s   %s" % (_ETIKET, satir.rstrip().replace("\n", " | ")))


def _devret(fnc, *args):
	from twisted.internet import reactor
	reactor.callFromThread(fnc, *args)


def _kur():
	from Screens.Screen import Screen
	from enigma import eTimer

	asil_close = Screen.close
	asil_start = eTimer.start
	asil_stop = eTimer.stop

	def guvenli_close(screen, retval):
		# kuyrukta beklerken ekran zaten kapanmis olabilir (ornegin kendi
		# zamanlayicisi kapatti); kapanmis ekranin __dict__'i temizlenir
		d = screen.__dict__
		if "execing" not in d or d.get("instance") is None:
			return
		session = d.get("session")
		if screen.execing and session is not None and session.current_dialog is not screen:
			print("%s %s zaten on planda degil, devredilen close atlandi" % (_ETIKET, screen.__class__.__name__))
			return
		asil_close(screen, *retval)

	def close(self, *retval):
		if _ana_mi():
			return asil_close(self, *retval)
		_kaydet("Screen.close (%s)" % self.__class__.__name__)
		_devret(guvenli_close, self, retval)

	def start(self, *args):
		if _ana_mi():
			return asil_start(self, *args)
		_kaydet("eTimer.start")
		_devret(asil_start, self, *args)

	def stop(self):
		if _ana_mi():
			return asil_stop(self)
		_kaydet("eTimer.stop")
		_devret(asil_stop, self)

	Screen.close = close
	eTimer.start = start
	eTimer.stop = stop
	print("%s etkin: Screen.close, eTimer.start/stop korunuyor" % _ETIKET)


# Eklenti listesi okunurken (ana is parcacigi, eklentiler calismadan once)
# kurulur; boylece AJPanel gibi eklentilerin ilk cagrisi da korunur.
if _ana_mi():
	try:
		_kur()
	except Exception:
		traceback.print_exc()


def Plugins(**kwargs):
	return [PluginDescriptor(name="ThreadGuard", where=PluginDescriptor.WHERE_AUTOSTART, fnc=lambda **kw: None)]
