# -*- coding: utf-8 -*-
"""
GDrive -- Google Drive API istemcisi (saf Python; enigma2'siz calisir).

YALNIZCA OKUMA (kullanici karari, 2026-10-12): kapsam drive.readonly, Drive'a
yalnizca GET yapilir (tek giris noktasi _al). Tek POST oauth2 belirtec ucudur;
Drive icerigine dokunmaz. Yazma/silme/duzenleme/tasima/paylasma metodu YOKTUR,
eklenmeyecek.

Python 2.7 (DreamOS, requests 2.13) ve 3 (PC'de deneme) ortak. Ag islemleri
ana is parcacigindan CAGRILMAMALI (arka.py kuyruklar, vekil kendi is parcaciginda).

Giris (Masaustu OAuth istemcisi + PKCE + loopback yonlendirme):
    d = Drive(kimlik_yolu)                  # /etc/enigma2/gdrive.json
    d.istemci_ayarla(client_id, client_secret)
    adres = d.giris_adresi()                # telefonda acilir
    d.giris_tamamla(yapistirilan_adres)     # 127.0.0.1:8765/?code=... ya da yalniz kod
Kullanim:
    ogeler, sonraki = d.klasor("root")
    ogeler, sonraki = d.paylasilanlar()
    suruculer = d.suruculer()
    ogeler, sonraki = d.ara(u"film")
    srt = d.altyazi_bul(klasor_id, u"Film.2020.mkv")
    url, basliklar = d.icerik_istegi(dosya_id)      # vekil kullanir
"""
from __future__ import print_function

import base64
import hashlib
import json
import os
import threading
import time

try:
    from urllib.parse import urlencode, urlparse, parse_qs
except ImportError:  # Python 2
    from urllib import urlencode
    from urlparse import urlparse, parse_qs

import requests

KAPSAM = "https://www.googleapis.com/auth/drive.readonly"
YONLENDIRME = "http://127.0.0.1:8765"
YETKI_UCU = "https://accounts.google.com/o/oauth2/v2/auth"
BELIRTEC_UCU = "https://oauth2.googleapis.com/token"
API = "https://www.googleapis.com/drive/v3"

KLASOR_MIME = "application/vnd.google-apps.folder"
VIDEO_UZANTILARI = (".mkv", ".mp4", ".m4v", ".avi", ".mov", ".ts", ".m2ts", ".mts", ".wmv",
                    ".mpg", ".mpeg", ".webm", ".flv", ".3gp", ".vob", ".divx", ".ogv")
ALTYAZI_UZANTILARI = (".srt",)
ALANLAR = ("id,name,mimeType,size,modifiedTime,parents,driveId,shortcutDetails,"
           "videoMediaMetadata(width,height,durationMillis),thumbnailLink")
# Klasor ve video olabilecek her sey (uzantisi .mkv olup mime'i octet-stream gelenler dahil);
# kesin ayiklama istemci tarafinda _video_mu ile.
_SUZGEC = ("(mimeType = '%s' or mimeType contains 'video/' or mimeType = 'application/octet-stream'"
           " or mimeType = 'application/vnd.google-apps.shortcut')" % KLASOR_MIME)
ZAMAN_ASIMI = 10
SAYFA = 200


class DriveHatasi(Exception):
    pass


def hata_metni(e):
    """Istisnanin metni, her zaman unicode. py2'de 'str % e' Turkce iletide UnicodeEncodeError verir
    (except blogunda patlar, is parcacigi olur); bayt iletili istisnada unicode(e) de patlar."""
    try:
        return u"%s" % (e,)
    except UnicodeError:
        pass
    try:
        return str(e).decode("utf-8", "replace")
    except Exception:  # noqa: BLE001
        return repr(e)


class GirisGerekli(DriveHatasi):
    pass


def _b64(veri):
    s = base64.urlsafe_b64encode(veri)
    if not isinstance(s, str):
        s = s.decode("ascii")
    return s.rstrip("=")


def _tirnak(metin):
    """q ifadesi icin tek tirnakli dize."""
    return metin.replace("\\", "\\\\").replace("'", "\\'")


def uzanti(ad):
    return os.path.splitext(ad or u"")[1].lower()


def klasor_mu(oge):
    return oge.get("mimeType") == KLASOR_MIME


def video_mu(oge):
    mime = oge.get("mimeType") or ""
    return mime.startswith("video/") or uzanti(oge.get("name")) in VIDEO_UZANTILARI


def _kisayol_coz(oge):
    """Kisayolu hedefinin kimligi/turuyle degistirir (ad kisayolunki kalir)."""
    k = oge.get("shortcutDetails")
    if oge.get("mimeType") == "application/vnd.google-apps.shortcut" and k:
        oge = dict(oge)
        oge["kisayol_id"] = oge["id"]
        oge["id"] = k.get("targetId")
        oge["mimeType"] = k.get("targetMimeType") or ""
    return oge


def ayikla(dosyalar):
    """Klasorler + videolar; klasorler once. Kisayollar cozulur."""
    sonuc = []
    for o in dosyalar:
        o = _kisayol_coz(o)
        if klasor_mu(o) or video_mu(o):
            sonuc.append(o)
    return sonuc


class Drive(object):
    def __init__(self, kimlik_yolu, gunluk=None, zaman_asimi=ZAMAN_ASIMI):
        self.kimlik_yolu = kimlik_yolu
        self.gunluk = gunluk or (lambda m: None)
        self.zaman_asimi = zaman_asimi
        self._kilit = threading.Lock()
        self._yerel = threading.local()      # is parcacigi basina requests.Session (Session paylasilmaz)
        self._dogrulayici = None
        self.kimlik = {}
        self._erisim = None
        self._bitis = 0
        self.yukle()

    @property
    def _oturum(self):
        o = getattr(self._yerel, "oturum", None)
        if o is None:
            o = self._yerel.oturum = requests.Session()
        return o

    # --- kimlik dosyasi ----------------------------------------------------
    def yukle(self):
        try:
            with open(self.kimlik_yolu) as f:
                self.kimlik = json.load(f)
        except (IOError, OSError, ValueError):
            self.kimlik = {}

    def _kaydet(self):
        gecici = self.kimlik_yolu + ".tmp"
        eski = os.umask(0o077)
        try:
            with open(gecici, "w") as f:
                json.dump(self.kimlik, f, indent=1, sort_keys=True)
        finally:
            os.umask(eski)
        os.chmod(gecici, 0o600)
        # py2'de os.replace yok; Linux'ta rename zaten ustune yazar (Windows'ta yazmaz)
        getattr(os, "replace", os.rename)(gecici, self.kimlik_yolu)

    def istemci_var(self):
        return bool(self.kimlik.get("client_id") and self.kimlik.get("client_secret"))

    def giris_var(self):
        return self.istemci_var() and bool(self.kimlik.get("refresh_token"))

    def eposta(self):
        return self.kimlik.get("email") or u""

    def istemci_ayarla(self, client_id, client_secret):
        client_id, client_secret = (client_id or "").strip(), (client_secret or "").strip()
        if not client_id.endswith(".apps.googleusercontent.com") or not client_secret:
            raise DriveHatasi(u"İstemci kimliği ya da sırrı geçersiz")
        if client_id != self.kimlik.get("client_id"):
            self.kimlik.pop("refresh_token", None)
            self.kimlik.pop("email", None)
        self.kimlik["client_id"], self.kimlik["client_secret"] = client_id, client_secret
        self._kaydet()

    def istemci_json(self, metin):
        """Cloud Console'dan indirilen client_secret_*.json icerigi."""
        try:
            d = json.loads(metin)
        except ValueError:
            raise DriveHatasi(u"JSON okunamadı")
        d = d.get("installed") or d.get("web") or d
        self.istemci_ayarla(d.get("client_id"), d.get("client_secret"))

    def cikis(self):
        for k in ("refresh_token", "email"):
            self.kimlik.pop(k, None)
        self._erisim, self._bitis = None, 0
        self._kaydet()

    # --- OAuth ---------------------------------------------------------------
    def giris_adresi(self):
        if not self.istemci_var():
            raise DriveHatasi(u"Önce istemci kimliği girilmeli")
        self._dogrulayici = _b64(os.urandom(48))
        meydan = _b64(hashlib.sha256(self._dogrulayici.encode("ascii")).digest())
        p = {"client_id": self.kimlik["client_id"], "redirect_uri": YONLENDIRME,
             "response_type": "code", "scope": KAPSAM, "access_type": "offline",
             "prompt": "consent", "code_challenge": meydan, "code_challenge_method": "S256"}
        return YETKI_UCU + "?" + urlencode(p)

    def giris_tamamla(self, yapistirilan):
        """Yonlendirme adresinin tamami ya da yalnizca kod. E-postayi dondurur."""
        metin = (yapistirilan or "").strip()
        kod = metin
        if "=" in metin:
            q = parse_qs(urlparse(metin if "://" in metin else "http://x/?" + metin.split("?")[-1]).query)
            if q.get("error"):
                raise DriveHatasi(u"Google girişi reddetti: %s" % q["error"][0])
            kod = (q.get("code") or [""])[0]
        if not kod:
            raise DriveHatasi(u"Adreste kod yok")
        if not self._dogrulayici:
            raise DriveHatasi(u"Giriş bağlantısı bu oturumda üretilmedi; formu yenileyip yeniden deneyin")
        veri = {"code": kod, "client_id": self.kimlik["client_id"],
                "client_secret": self.kimlik["client_secret"], "redirect_uri": YONLENDIRME,
                "grant_type": "authorization_code", "code_verifier": self._dogrulayici}
        j = self._belirtec_istegi(veri)
        if not j.get("refresh_token"):
            raise DriveHatasi(u"Google yenileme belirteci vermedi")
        if KAPSAM not in (j.get("scope") or "").split():
            raise DriveHatasi(u"Salt okunur Drive izni verilmedi (onay kutusu işaretlenmeli)")
        self.kimlik["refresh_token"] = j["refresh_token"]
        self._erisim_ayarla(j)
        self._dogrulayici = None
        self.kimlik["email"] = self.hakkinda().get("emailAddress", u"")
        self._kaydet()
        return self.kimlik["email"]

    def _belirtec_istegi(self, veri):
        # Tek POST: belirtec ucu. Drive icerigine dokunmaz.
        try:
            r = self._oturum.post(BELIRTEC_UCU, data=veri, timeout=self.zaman_asimi)
        except requests.RequestException as e:
            raise DriveHatasi(u"Google'a bağlanılamadı: %s" % hata_metni(e))
        try:
            j = r.json()
        except ValueError:
            j = {}
        if r.status_code != 200:
            hata = j.get("error") or r.status_code
            if hata == "invalid_grant":
                raise GirisGerekli(u"Google oturumu geçersiz (izin geri alınmış ya da süresi dolmuş); yeniden giriş yapın")
            raise DriveHatasi(u"Belirteç alınamadı: %s %s" % (hata, j.get("error_description") or ""))
        return j

    def _erisim_ayarla(self, j):
        self._erisim = j["access_token"]
        self._bitis = time.time() + int(j.get("expires_in", 3600))

    def erisim(self, zorla=False):
        """Gecerli erisim belirteci; suresi 2 dk icinde doluyorsa yeniler. Is parcacigi guvenli."""
        with self._kilit:
            if not zorla and self._erisim and time.time() < self._bitis - 120:
                return self._erisim
            if not self.giris_var():
                raise GirisGerekli(u"Google hesabına giriş yapılmamış")
            j = self._belirtec_istegi({"client_id": self.kimlik["client_id"],
                                       "client_secret": self.kimlik["client_secret"],
                                       "refresh_token": self.kimlik["refresh_token"],
                                       "grant_type": "refresh_token"})
            self._erisim_ayarla(j)
            self.gunluk("erisim belirteci yenilendi")
            return self._erisim

    # --- okuma (tek giris noktasi: GET) --------------------------------------
    def _al(self, yol, params=None):
        """Drive API'ye GET. 401'de belirteci yenileyip bir kez; 429/5xx'te 1/2 s bekleyip yineler."""
        params = dict(params or {})
        zorla = False
        for deneme in range(3):
            basliklar = {"Authorization": "Bearer " + self.erisim(zorla)}
            try:
                r = self._oturum.get(API + yol, params=params, headers=basliklar, timeout=self.zaman_asimi)
            except requests.RequestException as e:
                if deneme == 2:
                    raise DriveHatasi(u"Drive'a bağlanılamadı: %s" % hata_metni(e))
                time.sleep(1 + deneme)
                continue
            if r.status_code == 401 and not zorla:
                zorla = True
                continue
            if r.status_code in (429, 500, 502, 503, 504) and deneme < 2:
                time.sleep(1 + deneme)
                continue
            if r.status_code != 200:
                try:
                    mesaj = r.json()["error"]["message"]
                except (ValueError, KeyError, TypeError):
                    mesaj = r.text[:200]
                raise DriveHatasi(u"Drive %d: %s" % (r.status_code, mesaj))
            zorla = False
            return r.json()
        raise DriveHatasi(u"Drive yanıt vermedi")

    def hakkinda(self):
        return self._al("/about", {"fields": "user(emailAddress,displayName),storageQuota"}).get("user", {})

    def _dosyalar(self, q, sayfa_belirteci=None, siralama="folder,name_natural", **ek):
        p = {"q": q, "fields": "nextPageToken,files(%s)" % ALANLAR, "pageSize": SAYFA,
             "orderBy": siralama, "supportsAllDrives": "true", "includeItemsFromAllDrives": "true"}
        p.update(ek)
        if sayfa_belirteci:
            p["pageToken"] = sayfa_belirteci
        j = self._al("/files", p)
        return ayikla(j.get("files", [])), j.get("nextPageToken")

    def klasor(self, klasor_id="root", sayfa_belirteci=None, surucu_id=None):
        q = "'%s' in parents and trashed = false and %s" % (_tirnak(klasor_id), _SUZGEC)
        ek = {"corpora": "drive", "driveId": surucu_id} if surucu_id else {}
        return self._dosyalar(q, sayfa_belirteci, **ek)

    def paylasilanlar(self, sayfa_belirteci=None):
        return self._dosyalar("sharedWithMe and trashed = false and " + _SUZGEC, sayfa_belirteci)

    def suruculer(self):
        sonuc, belirtec = [], None
        while True:
            p = {"pageSize": 100, "fields": "nextPageToken,drives(id,name)"}
            if belirtec:
                p["pageToken"] = belirtec
            j = self._al("/drives", p)
            sonuc.extend(j.get("drives", []))
            belirtec = j.get("nextPageToken")
            if not belirtec:
                return sonuc

    def ara(self, metin, sayfa_belirteci=None):
        q = "name contains '%s' and trashed = false and %s" % (_tirnak(metin), _SUZGEC)
        return self._dosyalar(q, sayfa_belirteci, siralama="folder,modifiedTime desc", corpora="allDrives")

    def dosya(self, dosya_id):
        return self._al("/files/" + dosya_id, {"fields": ALANLAR, "supportsAllDrives": "true"})

    def altyazi_bul(self, klasor_id, video_adi):
        """Video adiyla baslayan .srt'ler (Film.mkv -> Film.srt, Film.tr.srt), en iyisi once.
        Once videonun klasorunde; klasor yoksa (paylasilan dosyalarda Drive ebeveyni vermez) ya da
        orada yoksa Drive genelinde ad aramasiyla (kullanici kendi Drive'ina koyabilsin; 0.3)."""
        kok = os.path.splitext(video_adi)[0]
        if not kok:
            return []
        adaylar = []
        if klasor_id:
            adaylar = self._altyazi_ara("'%s' in parents and trashed = false and name contains '.srt'" % _tirnak(klasor_id), kok)
        if not adaylar:
            ilk = kok.split()[0] if kok.split() else kok      # 'contains' sozcuk onekiyle eslesir; suzme istemcide
            adaylar = self._altyazi_ara("name contains '%s' and trashed = false and name contains '.srt'" % _tirnak(ilk), kok,
                                        corpora="allDrives")
        # tam ad (Film.srt) once, sonra .tr. icerenler, sonra digerleri
        def puan(f):
            ad = f["name"].lower()
            return (ad != (kok + ".srt").lower(), ".tr." not in ad and ".tur." not in ad, ad)
        return sorted(adaylar, key=puan)

    def _altyazi_ara(self, q, kok, **ek):
        p = {"q": q, "fields": "files(id,name,size)", "pageSize": 200,
             "supportsAllDrives": "true", "includeItemsFromAllDrives": "true"}
        p.update(ek)
        try:
            j = self._al("/files", p)
        except DriveHatasi as e:
            self.gunluk(u"altyazi aranamadi: %s" % hata_metni(e))
            return []
        return [f for f in j.get("files", []) if uzanti(f["name"]) in ALTYAZI_UZANTILARI
                and f["name"].lower().startswith(kok.lower())]

    def icerik_istegi(self, dosya_id, zorla=False):
        """Vekil icin: (adres, basliklar). Vekil GET yapar ve Range'i ekler."""
        adres = "%s/files/%s?alt=media&supportsAllDrives=true" % (API, dosya_id)
        return adres, {"Authorization": "Bearer " + self.erisim(zorla)}

    def icerik_indir(self, dosya_id, sinir=4 * 1024 * 1024):
        """Kucuk dosya (altyazi) icerigi, bayt. Sinir asilirsa hata."""
        adres, basliklar = self.icerik_istegi(dosya_id)
        r = self._oturum.get(adres, headers=basliklar, timeout=self.zaman_asimi, stream=True)
        if r.status_code == 401:
            r.close()
            adres, basliklar = self.icerik_istegi(dosya_id, zorla=True)
            r = self._oturum.get(adres, headers=basliklar, timeout=self.zaman_asimi, stream=True)
        if r.status_code != 200:
            r.close()
            raise DriveHatasi(u"İndirilemedi: HTTP %d" % r.status_code)
        parcalar, toplam = [], 0
        for p in r.iter_content(64 * 1024):
            toplam += len(p)
            if toplam > sinir:
                r.close()
                raise DriveHatasi(u"Dosya çok büyük")
            parcalar.append(p)
        return b"".join(parcalar)
