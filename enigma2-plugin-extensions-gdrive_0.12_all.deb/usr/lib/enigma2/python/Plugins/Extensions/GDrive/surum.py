# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_gdrive.py); depoda yok.
SURUM = "0.12"
COMMIT = "f96aa35"
