# -*- coding: utf-8 -*-
"""
GDrive -- yerel oynatma vekili.

GStreamer (souphttpsrc) http://127.0.0.1:<port>/f/<dosya_id>/<ad> adresini acar;
vekil Drive'a Authorization basligiyla GET yapar, Range'i aynen iletir, yaniti
(206/Content-Range dahil) akitir. Erisim belirteci 1 saat; 401'de yenileyip bir
kez yineler, boylece uzun filmde sarma da calisir.

YALNIZCA OKUMA: yalnizca GET ve HEAD; diger yontemlere 405. Yalnizca 127.0.0.1'e
baglanir (agdan erisilemez).

Kendi is parcaciklarinda calisir (ThreadingMixIn); enigma2 ana dongusune ve
ekranlara dokunmaz.
"""
from __future__ import print_function

import re
import socket
import threading

try:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urllib import quote
except ImportError:  # Python 3
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import quote

import requests

from .drive import hata_metni

VARSAYILAN_PORT = 8766
PARCA = 256 * 1024
_YOL = re.compile(r"^/f/([A-Za-z0-9_-]{10,})(?:/|$)")
_ILETILEN = ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified", "ETag")


class _Sunucu(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, istek, adres):
        # GStreamer sarmada baglantiyi keser; finish()'teki Broken pipe yigin izi gunlugu kirletmesin
        import sys
        e = sys.exc_info()[1]
        if isinstance(e, (socket.error, IOError)) and getattr(e, "errno", None) in (32, 104):
            return
        self.vekil.gunluk(u"vekil: istek hatasi: %s" % hata_metni(e))


class _Isleyici(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"
    server_version = "GDrive"

    def log_message(self, bicim, *args):  # stderr'e degil, eklenti gunlugune (yalniz hata)
        pass

    def _yasak(self):
        self.send_response(405)
        self.send_header("Allow", "GET, HEAD")
        self.send_header("Content-Length", "0")
        self.end_headers()

    do_POST = do_PUT = do_DELETE = do_PATCH = do_OPTIONS = _yasak

    def do_HEAD(self):
        self._aktar(govde=False)

    def do_GET(self):
        self._aktar(govde=True)

    def _aktar(self, govde):
        vekil = self.server.vekil
        m = _YOL.match(self.path)
        if not m:
            self.send_error(404)
            return
        dosya_id = m.group(1)
        aralik = self.headers.get("Range")
        r = None
        try:
            for zorla in (False, True):
                adres, basliklar = vekil.drive.icerik_istegi(dosya_id, zorla)
                if aralik:
                    basliklar["Range"] = aralik
                r = vekil.oturum.get(adres, headers=basliklar, stream=True, timeout=(10, 30))
                if r.status_code != 401:
                    break
                r.close()
            if r.status_code not in (200, 206):
                vekil.gunluk("vekil: %s Range=%s -> HTTP %d" % (dosya_id, aralik, r.status_code))
            self.send_response(r.status_code)
            for b in _ILETILEN:
                if b in r.headers:
                    self.send_header(b, r.headers[b])
            if "Accept-Ranges" not in r.headers and r.status_code in (200, 206):
                self.send_header("Accept-Ranges", "bytes")
            self.send_header("Connection", "close")
            self.end_headers()
            if govde:
                for p in r.iter_content(PARCA):
                    self.wfile.write(p)
        except (socket.error, IOError) as e:
            # GStreamer sarmada baglantiyi keser; olagan
            if getattr(e, "errno", None) not in (32, 104):
                vekil.gunluk(u"vekil: baglanti: %s" % hata_metni(e))
        except requests.RequestException as e:
            vekil.gunluk(u"vekil: Drive: %s" % hata_metni(e))
            try:
                self.send_error(502)
            except Exception:  # noqa: BLE001
                pass
        except Exception as e:  # noqa: BLE001 -- GirisGerekli vb.
            vekil.gunluk(u"vekil: %s" % hata_metni(e))
            try:
                self.send_error(502)
            except Exception:  # noqa: BLE001
                pass
        finally:
            if r is not None:
                r.close()


class Vekil(object):
    def __init__(self, drive, port=VARSAYILAN_PORT, gunluk=None):
        self.drive = drive
        self.port = port
        self.gunluk = gunluk or (lambda m: None)
        self.oturum = requests.Session()
        self._sunucu = None

    def baslat(self):
        if self._sunucu:
            return
        s = _Sunucu(("127.0.0.1", self.port), _Isleyici)
        s.vekil = self
        t = threading.Thread(target=s.serve_forever, name="gdrive_vekil")
        t.daemon = True
        t.start()
        self._sunucu = s
        self.gunluk("vekil 127.0.0.1:%d" % self.port)

    def durdur(self):
        if self._sunucu:
            self._sunucu.shutdown()
            self._sunucu.server_close()
            self._sunucu = None

    def adres(self, dosya_id, ad=u"video"):
        """Her zaman yerel dizge (py2: bayt). eServiceReference std::string ister; JSON'dan gelen
        unicode kimlik adresi unicode yapiyordu -> TypeError, oynatici acilmadi (olculdu 0.1)."""
        if isinstance(ad, type(u"")):
            ad = ad.encode("utf-8")
        adres = "http://127.0.0.1:%d/f/%s/%s" % (self.port, dosya_id, quote(ad, safe=""))
        if str is bytes and isinstance(adres, type(u"")):
            adres = adres.encode("ascii")      # kimlik [A-Za-z0-9_-], ad quote'lu: hep ASCII
        return adres
