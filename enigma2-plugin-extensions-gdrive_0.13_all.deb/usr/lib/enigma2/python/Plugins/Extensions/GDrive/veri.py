# -*- coding: utf-8 -*-
"""
GDrive -- kalici veri (SQLite): kaldigi yer / izlendi, arama gecmisi.

Dosya: /data/gdrive/gdrive.db (kutuda; Drive'a ASLA yazilmaz -- eklenti salt okunur).
Tek baglanti, kilitli; arka plan is parcacigindan ve ana dongudan cagrilabilir.
Anahtar Drive dosya kimligidir (hesaptan bagimsiz, kalici).
"""
from __future__ import print_function

import os
import sqlite3
import threading
import time

IZLENDI_YUZDE = 90
# Temanin yazi tipinde (DroidSans) ▶ ✔ yok; » √ var (StalkerTV'de olculdu)
ISARET_BITTI = u"√"      # √
ISARET_DEVAM = u"»"      # »

SEMA = """
CREATE TABLE IF NOT EXISTS izleme (
    dosya_id    TEXT PRIMARY KEY,
    ad          TEXT,
    klasor_id   TEXT,
    konum_sn    INTEGER NOT NULL DEFAULT 0,
    sure_sn     INTEGER NOT NULL DEFAULT 0,
    bitti       INTEGER NOT NULL DEFAULT 0,
    boyut       INTEGER NOT NULL DEFAULT 0,
    tarih       INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS izleme_tarih ON izleme (tarih);
CREATE TABLE IF NOT EXISTS arama (
    metin       TEXT PRIMARY KEY,       -- kucuk harf, kirpilmis
    sayac       INTEGER NOT NULL DEFAULT 1,
    tarih       INTEGER NOT NULL
);
"""


def _u(s):
    if s is None:
        return None
    if isinstance(s, bytes):
        return s.decode("utf-8", "replace")
    return s


class Veri(object):
    def __init__(self, yol):
        d = os.path.dirname(yol)
        if d and not os.path.isdir(d):
            os.makedirs(d)
        self._kilit = threading.Lock()
        self._db = sqlite3.connect(yol, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.executescript(SEMA)
        self._db.commit()

    def _calistir(self, sql, p=(), tek=False, yaz=False):
        with self._kilit:
            c = self._db.execute(sql, p)
            if yaz:
                self._db.commit()
                return c.rowcount
            sonuc = c.fetchone() if tek else c.fetchall()
        if tek:
            return dict(sonuc) if sonuc else None
        return [dict(r) for r in sonuc]

    # --- izleme ---
    def izleme_yaz(self, dosya_id, konum_sn, sure_sn, ad=None, klasor_id=None, boyut=0, bitti=None):
        """bitti None: sureye gore (IZLENDI_YUZDE); True/False: zorla."""
        if bitti is None:
            bitti = bool(sure_sn and konum_sn >= sure_sn * IZLENDI_YUZDE // 100)
        eski = self.izleme_al(dosya_id)
        if eski and eski["bitti"] and not bitti and konum_sn < 60:
            bitti = True        # bitmis dosya yeniden acilip hemen kapatildiysa isaret kalsin
        self._calistir(
            "INSERT OR REPLACE INTO izleme (dosya_id, ad, klasor_id, konum_sn, sure_sn, bitti, boyut, tarih) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (_u(dosya_id), _u(ad) or (eski or {}).get("ad"), _u(klasor_id) or (eski or {}).get("klasor_id"),
             int(konum_sn or 0), int(sure_sn or (eski or {}).get("sure_sn") or 0), 1 if bitti else 0,
             int(boyut or (eski or {}).get("boyut") or 0), int(time.time())), yaz=True)

    def izlendi_isaretle(self, dosya_id, ad=None, deger=True):
        if deger:
            eski = self.izleme_al(dosya_id) or {}
            self.izleme_yaz(dosya_id, 0, eski.get("sure_sn", 0), ad, bitti=True)
        else:
            self._calistir("DELETE FROM izleme WHERE dosya_id = ?", (_u(dosya_id),), yaz=True)

    def izleme_al(self, dosya_id):
        return self._calistir("SELECT * FROM izleme WHERE dosya_id = ?", (_u(dosya_id),), tek=True)

    def izleme_haritasi(self, kimlikler):
        """{dosya_id: kayit} -- liste ekrani tek sorguda."""
        kimlikler = [_u(k) for k in kimlikler if k]
        sonuc = {}
        for i in range(0, len(kimlikler), 400):
            parca = kimlikler[i:i + 400]
            for r in self._calistir("SELECT * FROM izleme WHERE dosya_id IN (%s)" % ",".join("?" * len(parca)), parca):
                sonuc[r["dosya_id"]] = r
        return sonuc

    def son_izlenenler(self, limit=50):
        return self._calistir("SELECT * FROM izleme ORDER BY tarih DESC LIMIT ?", (int(limit),))

    def izleme_sayisi(self):
        return self._calistir("SELECT COUNT(*) AS n FROM izleme", tek=True)["n"]

    # --- arama ---
    def arama_ekle(self, metin):
        m = _u(metin).strip().lower()
        if not m:
            return
        self._calistir("INSERT INTO arama (metin, sayac, tarih) VALUES (?, 1, ?) "
                       "ON CONFLICT(metin) DO UPDATE SET sayac = sayac + 1, tarih = excluded.tarih"
                       if sqlite3.sqlite_version_info >= (3, 24) else
                       "INSERT OR REPLACE INTO arama (metin, sayac, tarih) VALUES "
                       "(?, COALESCE((SELECT sayac FROM arama WHERE metin = ?), 0) + 1, ?)",
                       (m, int(time.time())) if sqlite3.sqlite_version_info >= (3, 24) else (m, m, int(time.time())),
                       yaz=True)
        self._calistir("DELETE FROM arama WHERE metin NOT IN (SELECT metin FROM arama ORDER BY tarih DESC LIMIT 50)", yaz=True)

    def aramalar(self, sinir=7):
        return self._calistir("SELECT * FROM arama ORDER BY tarih DESC LIMIT ?", (int(sinir),))

    def arama_sil(self):
        self._calistir("DELETE FROM arama", yaz=True)
