# -*- coding: utf-8 -*-
"""
GDrive -- ekranlar.

Gorsel dil ve bilesenler StalkerTV/ekranlar.py'den (Tablo, Secenekler, Klavye, Deger,
ServisBilgisi, Ayarlar); kurallar ayni (DREAMOS-PLUGIN-GELISTIRME-NOTLARI.md §2, §35):
  - eListbox'a skin'den font verilmez; font Python'da (eListboxPythonMultiContent).
  - Ekran basligi skin'e gomulmez; setTitle/setText py2'de bayt ister (s_).
  - Ag isleri arka.gonder ile is parcaciginda; ekrana yalnizca ana dongude.
  - Gecikmeli her geri cagri once getattr(self, "canli", False) bakar (kapanmis ekran).
  - Metinler T() ile unicode'a cevrilip birlestirilir, widget sinirinda s_() ile bayta.

YALNIZCA OKUMA: Drive'da hicbir sey degistirilmez; "izlendi" isareti kutudaki SQLite'ta.
"""
from __future__ import print_function

import io
import os
import re
import socket
import sys
import time

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, configfile
from Components.MultiContent import MultiContentEntryText
from enigma import (getDesktop, eListboxPythonMultiContent, gFont, eListbox,
                    RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER)

from . import arka
from . import oynatici
from . import veri as veri_mod
from .veri import ISARET_BITTI, ISARET_DEVAM
from .drive import Drive, DriveHatasi, klasor_mu, video_mu, hata_metni
from .settings import cfg, tema as tema_sec, KIMLIK_DOSYASI, VERI_DIZINI, ALTYAZI_DIZINI

try:
    _
except NameError:
    def _(txt):
        return txt

PY2 = sys.version_info[0] < 3
L, R, C = RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER

# --- renk paleti (StalkerTV ile ayni; enigma2: "#AARRGGBB", AA=00 opak) -------------------
ZEMIN_INT = 0x111419
SECIM = "#00243646"
VURGU = "#003aa0a8"
VURGU_INT = 0x3AA0A8


def ZEMIN():
    try:
        opak = int(cfg.opaklik.value)
    except Exception:  # noqa: BLE001
        opak = 100
    return "#%02x%06x" % (int((100 - opak) * 255 / 100), ZEMIN_INT)


def tema_uygula():
    global ZEMIN_INT, SECIM, VURGU, VURGU_INT
    z, s, v = tema_sec()
    ZEMIN_INT = int(z, 16)
    SECIM = "#00" + s
    VURGU = "#00" + v
    VURGU_INT = int(v, 16)
    oynatici.tema_uygula(z, s, v)


tema_uygula()
METIN = 0xE6E9EC
METIN_SOLUK = 0x8A94A0
RENK_IZLENDI = 0x5CC48A
RENK_DEVAM = 0xE0B84A
RENK_KLASOR = 0x9EC3E6
CIP = {"red": "#00a84a46", "green": "#003d8a5a", "yellow": "#00b0923a", "blue": "#004a6fb3"}

PENCERE_W, PENCERE_H = 1500, 960
KENAR = 40
SATIR_H = 64
SCROLLBAR_W = 8


def fhd():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:  # noqa: BLE001
        return False


def o(px):
    return px if fhd() else int(px * 2 / 3)


def s_(metin):
    """enigma2 (py2) widget'lari utf-8 bayt dizgesi ister."""
    if metin is None:
        return ""
    if PY2 and isinstance(metin, type(u"")):
        return metin.encode("utf-8")
    if not PY2 and isinstance(metin, bytes):
        return metin.decode("utf-8", "replace")
    return metin


def u_(metin):
    if metin is None:
        return u""
    if isinstance(metin, bytes):
        return metin.decode("utf-8", "replace")
    if not isinstance(metin, type(u"")):
        return u"%s" % metin
    return metin


def T(metin):
    """Ceviri + unicode: py2'de _() bayt dondurur; unicode ile birlestirmeden once."""
    return u_(_(metin))


# --- bicimler -------------------------------------------------------------------------------
def boyut_metni(bayt):
    try:
        b = int(bayt or 0)
    except (TypeError, ValueError):
        return u""
    if b <= 0:
        return u""
    if b >= 1024 ** 3:
        return u"%.1f GB" % (b / (1024.0 ** 3))
    if b >= 1024 ** 2:
        return u"%d MB" % (b // (1024 ** 2))
    return u"%d KB" % max(1, b // 1024)


def sure_metni(sn):
    sn = int(sn or 0)
    if sn <= 0:
        return u""
    if sn >= 3600:
        return u"%d:%02d:%02d" % (sn // 3600, sn // 60 % 60, sn % 60)
    return u"%d:%02d" % (sn // 60, sn % 60)


def oge_suresi(oge):
    try:
        return int((oge.get("videoMediaMetadata") or {}).get("durationMillis") or 0) // 1000
    except (TypeError, ValueError):
        return 0


def tarih_metni(iso):
    m = re.match(r"(\d{4})-(\d\d)-(\d\d)", u_(iso))
    return u"%s.%s.%s" % (m.group(3), m.group(2), m.group(1)) if m else u""


def ad_goster(ad):
    """Videolarda uzanti gosterilmez (.mkv); klasor adlari oldugu gibi."""
    ad = u_(ad)
    kok, uz = os.path.splitext(ad)
    return kok if uz.lower() in (".mkv", ".mp4", ".avi", ".m4v", ".mov", ".ts", ".webm", ".wmv", ".mpg", ".mpeg", ".m2ts") else ad


# --- ortak nesneler ---------------------------------------------------------------------------
_drive = [None]
_vekil = [None]
_veri = [None]


def drive():
    if _drive[0] is None:
        _drive[0] = Drive(KIMLIK_DOSYASI, gunluk=arka.gunluk, zaman_asimi=int(cfg.zaman_asimi.value))
    _drive[0].zaman_asimi = int(cfg.zaman_asimi.value)
    return _drive[0]


def vekil():
    """Yerel oynatma vekili: ilk oynatmada baslar, oturum boyunca acik kalir (bosta is parcacigi uyur)."""
    if _vekil[0] is None:
        from .vekil import Vekil, VARSAYILAN_PORT
        son_hata = None
        for port in range(VARSAYILAN_PORT, VARSAYILAN_PORT + 10):
            v = Vekil(drive(), port=port, gunluk=arka.gunluk)
            try:
                v.baslat()
            except socket.error as e:
                son_hata = e
                continue
            _vekil[0] = v
            break
        if _vekil[0] is None:
            raise DriveHatasi(u"Yerel vekil başlatılamadı: %s" % son_hata)
    return _vekil[0]


def veri():
    if _veri[0] is None:
        veri_mod.IZLENDI_YUZDE = int(cfg.izlendi_yuzde.value)
        _veri[0] = veri_mod.Veri(os.path.join(VERI_DIZINI, "gdrive.db"))
    return _veri[0]


def altyazi_hazirla(oge):
    """Is parcaciginda: ayni adli .srt'yi (once ayni klasor, yoksa Drive geneli) bulur, UTF-8'e cevirip
    /tmp'ye yazar; yol ya da ''. Turkce .srt'ler cogunlukla windows-1254; GStreamer'in tahminine birakilmaz."""
    ebeveyn = (oge.get("parents") or [None])[0]
    adaylar = drive().altyazi_bul(ebeveyn, oge.get("name") or u"")
    if not adaylar:
        return u""
    secilen = adaylar[0]
    try:
        from Plugins.SystemPlugins.SubtitleStyle.cizici import utf8_kaydet
    except ImportError:
        arka.gunluk("altyazi: SubtitleStyle kurulu degil, .srt kullanilmiyor")
        return u""
    ham = drive().icerik_indir(secilen["id"])
    yol = os.path.join(ALTYAZI_DIZINI, "%s.srt" % secilen["id"])
    kodlama = utf8_kaydet(ham, yol)
    arka.gunluk("altyazi: %s (%s, %d bayt)" % (secilen["name"], kodlama, len(ham)))
    return yol


# --- tablo bileseni (StalkerTV) ---------------------------------------------------------------
class Tablo(MenuList):
    """Tek satirlik tablo. kolonlar: [(baslik, genislik_FHD | None=esnek, hiza)].
    Satir: (nesne, [hucre, ...]) -- hucre metin ya da (metin, renk)."""

    def __init__(self, kolonlar, genislik, satir_h=SATIR_H):
        MenuList.__init__(self, [], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.kolonlar = kolonlar
        self.l.setFont(0, gFont("Regular", o(30)))
        self.yuk = o(satir_h)
        self.l.setItemHeight(self.yuk)
        self.xw = _kolon_konumlari(kolonlar, genislik)

    def kur(self, satirlar):
        self.list = [self._satir(*s) for s in satirlar]
        self.l.setList(self.list)

    def _satir(self, nesne, hucreler):
        girdi = [nesne]
        for i, hucre in enumerate(hucreler):
            if i >= len(self.xw):
                break
            metin, renk = (hucre if isinstance(hucre, tuple) else (hucre, None))
            x, w = self.xw[i]
            girdi.append(MultiContentEntryText(pos=(x, 0), size=(w, self.yuk), font=0,
                                               flags=self.kolonlar[i][2] | RT_VALIGN_CENTER,
                                               text=s_(metin), color=renk, color_sel=0xFFFFFF if renk is None else renk))
        return girdi

    def secili(self):
        c = self.getCurrent()
        return c[0] if c else None


def _kolon_konumlari(kolonlar, genislik):
    w_toplam = genislik - o(SCROLLBAR_W) - o(16)
    sabit = sum(o(k[1]) for k in kolonlar if k[1])
    esnek = [i for i, k in enumerate(kolonlar) if not k[1]]
    bosluk = o(16)
    kalan = max(o(120), w_toplam - o(24) - sabit - bosluk * (len(kolonlar) - 1))
    esnek_w = kalan // max(1, len(esnek))
    xw = []
    x = o(24)
    for i, k in enumerate(kolonlar):
        w = esnek_w if i in esnek else o(k[1])
        xw.append((x, w))
        x += w + bosluk
    return xw


def _cipler(k, icw, y, w, h, f):
    bosluk = (icw - 4 * w) // 3
    sonuc = ""
    for i, renk in enumerate(("red", "green", "yellow", "blue")):
        sonuc += ('<widget name="key_%s" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" '
                  'backgroundColor="%s" halign="center" valign="center" cornerRadius="%d" />'
                  % (renk, k + i * (w + bosluk), y, w, h, f, CIP[renk], o(12)))
    return sonuc


def _liste_skin(ad, kolonlar):
    W, H = o(PENCERE_W), o(PENCERE_H)
    k = o(KENAR)
    icw = W - 2 * k
    hiza = {L: "left", R: "right", C: "center"}
    konumlar = _kolon_konumlari(kolonlar, icw)
    kolon_etiketleri = ""
    for i, (_baslik, _g, h) in enumerate(kolonlar):
        x, w = konumlar[i]
        kolon_etiketleri += ('<widget name="kolon%d" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8a94a0" '
                             'backgroundColor="transparent" transparent="1" halign="%s" valign="center" />'
                             % (i, k + x, o(108), w, o(40), o(24), hiza.get(h, "left")))
    return """
    <screen name="%(ad)s" position="center,center" size="%(W)d,%(H)d" backgroundColor="%(zemin)s" flags="wfNoBorder">
        <widget name="baslik" position="%(k)d,%(by)d" size="%(bw)d,%(bh)d" font="Regular;%(bf)d" foregroundColor="#ffffff" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        <widget name="ustbilgi" position="%(ux)d,%(uy)d" size="%(uw)d,%(uh)d" font="Regular;%(uf)d" foregroundColor="#8a94a0" backgroundColor="%(zemin)s" transparent="1" halign="right" noWrap="1" />
        <eLabel position="%(k)d,%(cy)d" size="%(icw)d,%(ch)d" backgroundColor="%(vurgu)s" />
        %(kolon_etiketleri)s
        <eLabel position="%(k)d,%(ay2)d" size="%(icw)d,1" backgroundColor="#00243646" />
        <widget name="liste" position="%(k)d,%(ly)d" size="%(icw)d,%(lh)d" backgroundColor="%(zemin)s" foregroundColor="#e6e9ec" backgroundColorSelected="%(secim)s" foregroundColorSelected="#ffffff" selectionRadius="%(sr)d" scrollbarMode="showOnDemand" scrollbarWidth="%(sw)d" transparent="1" />
        <widget name="altbilgi" position="%(k)d,%(ay)d" size="%(icw)d,%(ah)d" font="Regular;%(af)d" foregroundColor="#8a94a0" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        %(cipler)s
    </screen>""" % dict(ad=ad, W=W, H=H, zemin=ZEMIN(), k=k, icw=icw, vurgu=VURGU, secim=SECIM,
                        cipler=_cipler(k, icw, o(876), o(330), o(56), o(26)),
                        kolon_etiketleri=kolon_etiketleri, ay2=o(150),
                        by=o(26), bw=o(900), bh=o(50), bf=o(36),
                        ux=k + o(900), uy=o(36), uw=icw - o(900), uh=o(40), uf=o(26),
                        cy=o(92), ch=o(3), ly=o(156), lh=o(SATIR_H) * 10, sr=o(12), sw=o(SCROLLBAR_W),
                        ay=o(820), ah=o(40), af=o(24))


# --- secenek kutusu (StalkerTV) ---------------------------------------------------------------
def _secenek_skin(satir_sayisi):
    W = o(720)
    sh = o(60)
    H = o(120) + satir_sayisi * sh + o(40)
    return """
    <screen name="GDriveSecenekler" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">
        <widget name="baslik" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" />
        <eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" />
        <widget name="liste" position="%d,%d" size="%d,%d" backgroundColor="%s" foregroundColor="#e6e9ec" backgroundColorSelected="%s" foregroundColorSelected="#ffffff" selectionRadius="%d" scrollbarMode="showNever" transparent="1" />
    </screen>""" % (W, H, ZEMIN(),
                    o(32), o(26), W - o(64), o(44), o(30), ZEMIN(),
                    o(32), o(84), W - o(64), o(2), VURGU,
                    o(20), o(104), W - o(40), satir_sayisi * sh, ZEMIN(), SECIM, o(10))


class _Sureli(object):
    """Ekrani sure saniye sonra kapatan zamanlayici. onLayoutFinish'e BAGLI METOT verilir
    (lambda -> DreamOS GUISkin exec() -> TypeError -> yesil ekran; StalkerTV 0.39)."""

    def __init__(self, ekran, sure, kapat, guncelle=None):
        self.kalan = int(sure)
        self.kapat = kapat
        self.guncelle = guncelle
        self.z, self.baglanti = arka.zamanlayici(self.tik)
        ekran.onLayoutFinish.append(self.basla)
        ekran.onClose.append(self.durdur)

    def basla(self):
        self.z.start(1000, False)

    def durdur(self):
        self.z.stop()

    def tik(self):
        self.kalan -= 1
        if self.kalan <= 0:
            self.z.stop()
            self.kapat()
        elif self.guncelle:
            self.guncelle(self.kalan)


def _sureli_kapat(ekran, sure, kapat, guncelle=None):
    if sure:
        ekran._sureli = _Sureli(ekran, sure, kapat, guncelle)


class Secenekler(Screen):
    """liste [(metin, anahtar[, kisayol])]; OK -> close(anahtar), Exit -> close(None); 1-9 dogrudan."""

    def __init__(self, session, baslik, liste, sure=0):
        self.liste = [(u_(x[0]), x[1], u_(x[2]) if len(x) > 2 else u"") for x in liste][:9]
        self.skin = _secenek_skin(len(self.liste))
        Screen.__init__(self, session)
        self.baslik_metni = u_(baslik)
        _sureli_kapat(self, sure, lambda: self.close(None), self._sayac)
        self["baslik"] = Label(s_(self.baslik_metni if not sure else u"%s  ·  %d sn" % (self.baslik_metni, sure)))
        self["liste"] = Tablo([("", 56, R), ("", None, L), ("", 140, R)], o(720) - o(40), satir_h=60)
        self["liste"].kur([(a, [(u"%d" % (i + 1), METIN_SOLUK), m, (k, METIN_SOLUK)]) for i, (m, a, k) in enumerate(self.liste)])
        eylemler = {"ok": self.sec, "cancel": lambda: self.close(None)}
        for i in range(len(self.liste)):
            eylemler[str(i + 1)] = (lambda n=i: self.close(self.liste[n][1]))
        self["actions"] = ActionMap(["OkCancelActions", "NumberActions"], eylemler, -1)

    def _sayac(self, kalan):
        self["baslik"].setText(s_(u"%s  ·  %d sn" % (self.baslik_metni, kalan)))

    def sec(self):
        self.close(self["liste"].secili())


# --- ekran klavyesi (StalkerTV) ---------------------------------------------------------------
_K_SIL, _K_TEMIZLE, _K_BOSLUK, _K_BUYUK, _K_TAMAM = "sil", "temizle", "bosluk", "buyuk", "tamam"
KLAVYE_SUTUN = 11
KLAVYE_DUZEN = [
    list(u"1234567890") + [_K_SIL],
    list(u"qwertyuıopğ"),
    list(u"asdfghjklşi"),
    list(u"zxcvbnmöüç."),
    [_K_BUYUK, _K_BOSLUK, u"-", u":", u"/", u"'", u"&", u",", u"_", _K_TEMIZLE, _K_TAMAM],
]
KLAVYE_OZEL = {_K_SIL: u"Sil", _K_TEMIZLE: u"Temizle", _K_BOSLUK: u"Boşluk", _K_BUYUK: u"Büyük", _K_TAMAM: u"Tamam"}
KLAVYE_T9 = {u"0": u" 0", u"1": u"1.,-:/'&_", u"2": u"abcç2", u"3": u"def3", u"4": u"ghiığ4", u"5": u"jkl5",
             u"6": u"mnoö6", u"7": u"pqrsş7", u"8": u"tuvü8", u"9": u"wxyz9"}
T9_SURE_MS = 1200


def _buyut(h):
    if h == u"i":
        return u"İ"
    if h == u"ı":
        return u"I"
    return h.upper()


def _tus_zemini():
    r, g, b = (ZEMIN_INT >> 16) & 0xFF, (ZEMIN_INT >> 8) & 0xFF, ZEMIN_INT & 0xFF
    return (min(255, r + 12) << 16) | (min(255, g + 12) << 8) | min(255, b + 12)


class _KlavyeIzgara(MenuList):
    def __init__(self, hucre_w, hucre_h):
        MenuList.__init__(self, [], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.hucre_w, self.hucre_h = hucre_w, hucre_h
        self.l.setFont(0, gFont("Regular", o(30)))
        self.l.setFont(1, gFont("Regular", o(22)))
        self.l.setItemHeight(hucre_h)

    def postWidgetCreate(self, instance):
        MenuList.postWidgetCreate(self, instance)
        instance.setMode(eListbox.layoutGrid)
        instance.setItemWidth(self.hucre_w)
        instance.setItemHeight(self.hucre_h)

    def kur(self, buyuk):
        self.list = [self._karo(t, buyuk) for satir in KLAVYE_DUZEN for t in satir]
        self.l.setList(self.list)

    def _karo(self, tus, buyuk):
        ozel = tus in KLAVYE_OZEL
        if ozel:
            metin = u"küçük" if (tus == _K_BUYUK and buyuk) else KLAVYE_OZEL[tus]
        else:
            metin = _buyut(tus) if buyuk else tus
        b = o(4)
        return [tus, MultiContentEntryText(pos=(b, b), size=(self.hucre_w - 2 * b, self.hucre_h - 2 * b),
                                           font=1 if ozel else 0, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                           text=s_(metin), color=METIN_SOLUK if ozel else METIN, color_sel=ZEMIN_INT,
                                           backcolor=_tus_zemini(), backcolor_sel=VURGU_INT)]

    def sol(self):
        self.instance.moveSelection(self.instance.moveLeft)

    def sag(self):
        self.instance.moveSelection(self.instance.moveRight)

    def secili(self):
        c = self.getCurrent()
        return c[0] if c else None


def _klavye_skin():
    W = o(1200)
    k = o(30)
    icw = W - 2 * k
    hw = icw // KLAVYE_SUTUN
    hh = o(66)
    ty = o(216)
    cip_y = ty + len(KLAVYE_DUZEN) * hh + o(60)
    H = cip_y + o(50) + o(30)
    return """
    <screen name="GDriveKlavye" position="center,center" size="%(W)d,%(H)d" backgroundColor="%(zemin)s" flags="wfNoBorder">
        <widget name="baslik" position="%(k)d,%(by)d" size="%(icw)d,%(bh)d" font="Regular;%(bf)d" foregroundColor="#ffffff" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        <eLabel position="%(k)d,%(cy)d" size="%(icw)d,%(ch)d" backgroundColor="%(vurgu)s" />
        <widget name="metin" position="%(k)d,%(my)d" size="%(icw)d,%(mh)d" font="Regular;%(mf)d" foregroundColor="#ffffff" backgroundColor="%(secim)s" cornerRadius="%(mr)d" valign="center" noWrap="1" />
        <widget name="oneri" position="%(k)d,%(oy)d" size="%(icw)d,%(oh)d" font="Regular;%(of)d" foregroundColor="#8a94a0" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        <widget name="tuslar" position="%(k)d,%(ty)d" size="%(tw)d,%(th)d" backgroundColor="%(zemin)s" foregroundColor="#e6e9ec" backgroundColorSelected="%(zemin)s" foregroundColorSelected="#ffffff" scrollbarMode="showNever" transparent="1" />
        <widget name="ipucu" position="%(k)d,%(iy)d" size="%(icw)d,%(ih)d" font="Regular;%(if)d" foregroundColor="#8a94a0" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        %(cipler)s
    </screen>""" % dict(W=W, H=H, zemin=ZEMIN(), k=k, icw=icw, vurgu=VURGU, secim=SECIM,
                        cipler=_cipler(k, icw, cip_y, o(240), o(50), o(24)),
                        by=o(22), bh=o(44), bf=o(30), cy=o(76), ch=o(2),
                        my=o(96), mh=o(64), mf=o(34), mr=o(10),
                        oy=o(170), oh=o(36), of=o(24),
                        ty=ty, tw=hw * KLAVYE_SUTUN, th=len(KLAVYE_DUZEN) * hh,
                        iy=ty + len(KLAVYE_DUZEN) * hh + o(12), ih=o(34), **{"if": o(22)})


class Klavye(Screen):
    """close(metin) ya da Exit -> close(None). OK: tus; rakamlar SMS gibi; Kirmizi sil, Yesil tamam,
    Sari bosluk, Mavi arama gecmisinden oneriler."""

    def __init__(self, session, baslik, varsayilan=u""):
        self.skin = _klavye_skin()
        Screen.__init__(self, session)
        self.metin = u_(varsayilan or u"")
        self.buyuk = False
        self.t9_tus = None
        self.t9_konum = 0
        self.t9_acik = False
        self.t9_zaman, self.t9_baglanti = arka.zamanlayici(self._t9_bitir)
        self.oneriler = []
        self["baslik"] = Label(s_(u_(baslik)))
        self["metin"] = Label("")
        self["oneri"] = Label("")
        self["ipucu"] = Label(s_(T("OK: tuş     Rakamlar: SMS gibi yazar     Exit: vazgeç")))
        for k, m in (("key_red", "Sil"), ("key_green", "Tamam"), ("key_yellow", "Boşluk"), ("key_blue", "Öneriler")):
            self[k] = Label(s_(T(m)))
        self["tuslar"] = _KlavyeIzgara((o(1200) - 2 * o(30)) // KLAVYE_SUTUN, o(66))
        eylemler = {"ok": self.bas, "cancel": self.vazgec, "red": self.sil, "green": self.tamam,
                    "yellow": self.bosluk, "blue": self.oneri_ac, "deleteBackward": self.sil,
                    "up": self["tuslar"].up, "down": self["tuslar"].down,
                    "left": self["tuslar"].sol, "right": self["tuslar"].sag}
        for d in u"0123456789":
            eylemler[str(d)] = (lambda n=d: self.t9(n))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "NumberActions", "TextEntryActions"], eylemler, -1)
        self.onLayoutFinish.append(self._kur)
        self.onClose.append(self._kapanis)

    def _kur(self):
        self["tuslar"].kur(self.buyuk)
        self["tuslar"].moveToIndex(KLAVYE_SUTUN)
        self._goster()

    def _kapanis(self):
        self.t9_zaman.stop()

    def _goster(self):
        self["metin"].setText(s_(u"  " + self.metin + u"|"))
        self.oneriler = self._oneri_bul()
        if self.oneriler:
            self["oneri"].setText(s_(T("Mavi: öneriler") + u"   ·   " + u"   ·   ".join(self.oneriler[:3])))
        else:
            self["oneri"].setText("")

    def _oneri_bul(self):
        yazilan = self.metin.strip().lower()
        try:
            gecmis = [u_(g["metin"]) for g in veri().aramalar(50)]
        except Exception:  # noqa: BLE001
            return []
        if not yazilan:
            return gecmis[:9]
        bas = [g for g in gecmis if g.startswith(yazilan) and g != yazilan]
        ic = [g for g in gecmis if yazilan in g and g not in bas and g != yazilan]
        return (bas + ic)[:9]

    def _harf(self, h):
        return _buyut(h) if self.buyuk else h

    def bas(self):
        tus = self["tuslar"].secili()
        if tus is None:
            return
        self._t9_bitir()
        if tus == _K_SIL:
            self.metin = self.metin[:-1]
        elif tus == _K_TEMIZLE:
            self.metin = u""
        elif tus == _K_BOSLUK:
            self.metin += u" "
        elif tus == _K_BUYUK:
            self.buyuk = not self.buyuk
            i = self["tuslar"].getSelectedIndex()
            self["tuslar"].kur(self.buyuk)
            self["tuslar"].moveToIndex(i)
        elif tus == _K_TAMAM:
            self.tamam()
            return
        else:
            self.metin += self._harf(tus)
        self._goster()

    def sil(self):
        self._t9_bitir()
        self.metin = self.metin[:-1]
        self._goster()

    def bosluk(self):
        self._t9_bitir()
        self.metin += u" "
        self._goster()

    def tamam(self):
        self._t9_bitir()
        self.close(self.metin.strip())

    def vazgec(self):
        self.close(None)

    def oneri_ac(self):
        self._t9_bitir()
        if self.oneriler:
            self.session.openWithCallback(self._oneri_secildi, Secenekler, T("Öneriler"), [(m, m) for m in self.oneriler[:9]])

    def _oneri_secildi(self, secim):
        if secim and getattr(self, "metin", None) is not None:
            self.metin = u_(secim)
            self._goster()

    def t9(self, n):
        harfler = KLAVYE_T9[n]
        if self.t9_acik and self.t9_tus == n:
            self.t9_konum = (self.t9_konum + 1) % len(harfler)
            self.metin = self.metin[:-1] + self._harf(harfler[self.t9_konum])
        else:
            self._t9_bitir()
            self.t9_tus = n
            self.t9_konum = 0
            self.metin += self._harf(harfler[0])
        self.t9_acik = True
        self.t9_zaman.start(T9_SURE_MS, True)
        self._goster()

    def _t9_bitir(self):
        self.t9_acik = False
        self.t9_tus = None
        self.t9_zaman.stop()


# --- deger ve servis bilgisi (StalkerTV; oynatici.servis_bilgisi kullanir) --------------------------
def _deger_skin(satir):
    W = o(1200)
    H = o(150) + satir * o(40) + o(70)
    return """
    <screen name="GDriveDeger" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">
        <widget name="baslik" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" noWrap="1" />
        <eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" />
        <widget name="deger" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#e6e9ec" backgroundColor="%s" transparent="1" />
        <widget name="altbilgi" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8a94a0" backgroundColor="%s" transparent="1" noWrap="1" />
    </screen>""" % (W, H, ZEMIN(),
                    o(32), o(26), W - o(64), o(44), o(30), ZEMIN(),
                    o(32), o(84), W - o(64), o(2), VURGU,
                    o(32), o(108), W - o(64), satir * o(40), o(28), ZEMIN(),
                    o(32), H - o(56), W - o(64), o(36), o(22), ZEMIN())


class Deger(Screen):
    """Uzun bir metin / bilgi kutusu; OK / Exit kapatir; sure > 0 ise kendiliginden kapanir."""

    def __init__(self, session, etiket, deger, sure=0):
        metin = u_(deger)
        satir = 0
        for parca in metin.split(u"\n"):
            satir += max(1, (len(parca) + 69) // 70)
        satir = min(max(satir, 1), 14)
        self.skin = _deger_skin(satir)
        Screen.__init__(self, session)
        self["baslik"] = Label(s_(u_(etiket)))
        self["deger"] = Label(s_(metin))
        self["altbilgi"] = Label("")
        self._altbilgi_koy(sure)
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.close, "cancel": self.close}, -1)
        _sureli_kapat(self, sure, self.close, self._altbilgi_koy)

    def _altbilgi_koy(self, kalan):
        metin = T("OK / Exit: kapat")
        if kalan:
            metin += u"  ·  " + T("%d sn sonra kendiliğinden kapanır") % kalan
        self["altbilgi"].setText(s_(metin))


def _bilgi_skin():
    W, H = o(1500), o(900)
    k = o(40)
    return """
    <screen name="GDriveServisBilgisi" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">
        <widget name="baslik" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" noWrap="1" />
        <eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" />
        <widget name="liste" position="%d,%d" size="%d,%d" backgroundColor="%s" foregroundColor="#e6e9ec" backgroundColorSelected="%s" foregroundColorSelected="#ffffff" selectionRadius="%d" scrollbarMode="showOnDemand" scrollbarWidth="%d" transparent="1" />
        <widget name="altbilgi" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8a94a0" backgroundColor="%s" transparent="1" noWrap="1" />
    </screen>""" % (W, H, ZEMIN(),
                    k, o(26), W - 2 * k, o(50), o(36), ZEMIN(),
                    k, o(92), W - 2 * k, o(3), VURGU,
                    k, o(108), W - 2 * k, o(52) * 13, ZEMIN(), SECIM, o(12), o(SCROLLBAR_W),
                    k, o(820), W - 2 * k, o(40), o(24), ZEMIN())


class ServisBilgisi(Screen):
    """Etiket/deger satirlari; OK: degerin tamami."""

    def __init__(self, session, baslik, satirlar):
        self.skin = _bilgi_skin()
        Screen.__init__(self, session)
        self.satirlar = satirlar
        self["baslik"] = Label(s_(u_(baslik)))
        self["liste"] = Tablo([("", 400, L), ("", None, L)], o(1500) - 2 * o(40), satir_h=52)
        self._kur()
        self["altbilgi"] = Label(s_(T("OK: değerin tamamı  ·  Exit: kapat")))
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.tamami, "cancel": self.close,
            "up": self["liste"].up, "down": self["liste"].down,
            "left": self["liste"].pageUp, "right": self["liste"].pageDown,
        }, -1)

    def _kur(self):
        self["liste"].kur([((a, b), [(u_(a), METIN_SOLUK), u_(b)]) for a, b in self.satirlar])

    def satir_guncelle(self, etiket, deger):
        if not getattr(self, "satirlar", None):
            return
        self.satirlar = [(a, deger if a == etiket else b) for a, b in self.satirlar]
        i = self["liste"].getSelectedIndex()
        self._kur()
        try:
            self["liste"].moveToIndex(i)
        except Exception:  # noqa: BLE001
            pass

    def tamami(self):
        s = self["liste"].secili()
        if s:
            self.session.open(Deger, s[0], s[1])


def devam_sor(session, baslangic, geri, iptal=None):
    """baslangic > 0 ise ayara gore sorar; geri(baslangic_sn). Exit -> iptal()."""
    if baslangic <= 0 or cfg.devam.value == "bastan":
        geri(0)
        return
    if cfg.devam.value == "devam":
        geri(baslangic)
        return
    session.openWithCallback(lambda c: (geri(c) if c is not None else (iptal() if iptal else None)), Secenekler,
                             T("Kaldığı yerden devam?"),
                             [(T("Kaldığı yerden devam (%s)") % sure_metni(baslangic), baslangic), (T("Baştan başla"), 0)])


# --- temel ekran --------------------------------------------------------------------------------
class TemelEkran(Screen):
    """Ortak iskelet: baslik, sutun basliklari, tablo, alt satir, tus cipleri, arka plan isleri, oynatma."""
    SKIN_AD = "GDrive"
    KOLONLAR = [("", None, L)]
    BASLATMA_SINIRI_SN = 25

    def __init__(self, session, baslik=u"GDrive", yol=u""):
        self.canli = True        # Screen.__init__'ten ONCE (erken geri cagri; StalkerTV dersi)
        self.isler = []
        self.skin = _liste_skin(self.SKIN_AD, self.KOLONLAR)
        Screen.__init__(self, session)
        self["liste"] = Tablo(self.KOLONLAR, o(PENCERE_W) - 2 * o(KENAR))
        for i, kolon in enumerate(self.KOLONLAR):
            self["kolon%d" % i] = Label(s_(T(kolon[0])) if kolon[0] else "")
        self["baslik"] = Label("")
        self["ustbilgi"] = Label("")
        self["altbilgi"] = Label("")
        for k in ("key_red", "key_green", "key_yellow", "key_blue"):
            self[k] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions", "EPGSelectActions", "DirectionActions", "MoviePlayerActions"], {
            "ok": self.sec, "cancel": self.kapat, "red": self.kirmizi, "green": self.yesil,
            "yellow": self.sari, "blue": self.mavi, "menu": self.menu, "info": self.bilgi,
            "up": self["liste"].up, "down": self["liste"].down,
            "left": self["liste"].pageUp, "right": self["liste"].pageDown,
            "leavePlayer": self.arkadakini_durdur,
        }, -1)
        self.onLayoutFinish.append(self._tus_gizle)
        self.onShown.append(self._arkadaki_bilgi)
        self.onClose.append(self._kapanis)
        self.baslik_koy(baslik, yol)

    def baslik_koy(self, baslik, yol=u""):
        metin = u_(baslik) if not yol else u"%s  ›  %s" % (u_(yol), u_(baslik))
        self["baslik"].setText(s_(metin))
        try:
            self.setTitle(s_(u_(baslik)))
        except Exception:  # noqa: BLE001
            pass

    def ust(self, metin):
        self["ustbilgi"].setText(s_(u_(metin)))

    def alt(self, metin):
        try:
            self["altbilgi"].setText(s_(u_(metin)))
        except KeyError:
            pass

    def tus(self, kirmizi=u"", yesil=u"", sari=u"", mavi=u""):
        self._tuslar = (kirmizi, yesil, sari, mavi)
        for ad, metin in zip(("key_red", "key_green", "key_yellow", "key_blue"), self._tuslar):
            self[ad].setText(s_(u_(metin)))
        self._tus_gizle()

    def _tus_gizle(self):
        for ad, metin in zip(("key_red", "key_green", "key_yellow", "key_blue"), getattr(self, "_tuslar", (u"", u"", u"", u""))):
            try:
                (self[ad].show if metin else self[ad].hide)()
            except Exception:  # noqa: BLE001
                pass

    def gonder(self, fnc, args=(), geri=None, hata=None, yol=None):
        def _geri(sonuc):
            if getattr(self, "canli", False) and geri:
                geri(sonuc)

        def _hata(metin):
            if getattr(self, "canli", False):
                (hata or self.hata)(metin)
        is_ = (yol or arka.gonder)(fnc, args, _geri, _hata)
        self.isler.append(is_)
        return is_

    def _kapanis(self):
        self.canli = False
        for is_ in self.isler:
            is_.iptal_et()

    def _arkadaki_bilgi(self):
        a = oynatici.arkadaki_oynatma()
        if a:
            self.alt(u"%s %s  %s  ·  %s" % (ISARET_DEVAM, u_(a.baslik), T("arkada oynuyor"), T("Stop: durdur")))

    def arkadakini_durdur(self):
        if oynatici.arkadaki_oynatma():
            oynatici.arkadakini_durdur(self.session)
            self.alt(T("Arkadaki oynatma durduruldu"))
            self.goster()

    def hata(self, metin):
        metin = u_(metin)
        self.alt(T("Hata: %s") % metin)

    def mesaj(self, baslik, metin, sure=8):
        self.session.open(Deger, baslik, metin, sure)

    def klavye(self, baslik, varsayilan, geri):
        self.session.openWithCallback(geri, Klavye, baslik, varsayilan)

    # --- arama: once gecmis (1-9), sonra klavye ---
    def arama_baslat(self):
        gecmis = veri().aramalar(7)
        if not gecmis:
            self.klavye(T("Drive'da ara"), u"", self.arama_yap)
            return
        liste = [(u_(g["metin"]), ("ara", u_(g["metin"])), u"%d×" % g["sayac"]) for g in gecmis]
        liste.append((T("Yeni arama (klavye)"), ("yeni", None)))
        liste.append((T("Geçmişi temizle"), ("sil", None)))
        self.session.openWithCallback(self._arama_secildi, Secenekler, T("Drive'da ara"), liste)

    def _arama_secildi(self, secim):
        if not secim or not getattr(self, "canli", False):
            return
        if secim[0] == "yeni":
            self.klavye(T("Drive'da ara"), u"", self.arama_yap)
        elif secim[0] == "sil":
            veri().arama_sil()
            self.alt(T("Arama geçmişi silindi"))
        else:
            self.arama_yap(secim[1])

    def arama_yap(self, metin):
        metin = u_(metin or u"").strip()
        if len(metin) < 2 or not getattr(self, "canli", False):
            return
        veri().arama_ekle(metin)
        self.session.open(Klasor, "ara", None, u"“%s”" % metin, T("Arama"), metin=metin)

    # --- oynatma: tek yol (StalkerTV 0.91 dersi: istek sirasi, kilit, gec sonuc) ---
    def oynatma_iste(self, oge):
        d = getattr(self, "_baslatma", None)
        if d and time.time() - d["t"] < self.BASLATMA_SINIRI_SN:
            self.alt(T("Bekleyin: %s (%d sn)") % (d["asama"], int(time.time() - d["t"])))
            return
        sira = getattr(self, "_baslatma_sira", 0) + 1
        self._baslatma_sira = sira
        self._baslatma = {"t": time.time(), "asama": T("hazırlanıyor"), "sira": sira}
        anahtar = ("gdrive", u_(oge.get("id")))
        a = oynatici.arkadaki_oynatma()
        if a and a.anahtar == anahtar:
            self._baslatma["asama"] = T("oynatıcı açık")
            oynatici.arkadakine_don(self.session, geri=lambda *s: self._oynatma_bitti(sira, *s))
            return
        kayit = veri().izleme_al(oge.get("id"))
        baslangic = kayit["konum_sn"] if (kayit and not kayit["bitti"] and kayit["konum_sn"] > 10) else 0
        self._baslatma["asama"] = T("kaldığı yer sorusu")
        devam_sor(self.session, baslangic, lambda bas: self._altyazi_al(sira, oge, bas),
                  iptal=lambda: self._baslatma_bitir(sira))

    def _baslatma_guncel(self, sira):
        return getattr(self, "canli", False) and sira == getattr(self, "_baslatma_sira", 0)

    def _baslatma_bitir(self, sira):
        if sira == getattr(self, "_baslatma_sira", 0):
            self._baslatma = None

    def _altyazi_al(self, sira, oge, baslangic):
        if not self._baslatma_guncel(sira):
            return
        if not cfg.altyazi_dosyasi.value:
            self._oynat(sira, oge, baslangic, u"")
            return
        self._baslatma["asama"] = T("altyazı aranıyor")
        self.alt(T("Altyazı aranıyor..."))

        def hata(metin):
            arka.gunluk(u"altyazi alinamadi: %s" % u_(metin))
            self._oynat(sira, oge, baslangic, u"")
        self.gonder(altyazi_hazirla, (oge,), lambda yol: self._oynat(sira, oge, baslangic, yol), hata, yol=arka.gonder_oynatma)

    def _oynat(self, sira, oge, baslangic, altyazi):
        if not self._baslatma_guncel(sira):
            arka.gunluk("gec gelen oynatma hazirligi yok sayildi (istek %d)" % sira)
            return
        try:
            adres = vekil().adres(oge["id"], oge.get("name") or u"video")
        except DriveHatasi as e:
            self._baslatma_bitir(sira)
            self.hata(hata_metni(e))
            return
        dosya_id, ad = oge["id"], u_(oge.get("name"))
        klasor = (oge.get("parents") or [None])[0]
        boyut = oge.get("size") or 0
        sure = oge_suresi(oge)
        veri().izleme_yaz(dosya_id, baslangic, sure, ad, klasor, boyut, bitti=False if baslangic or not veri().izleme_al(dosya_id) else None)

        def kaydet(konum, sure_sn, bitti):
            veri().izleme_yaz(dosya_id, konum, sure_sn, ad, klasor, boyut, bitti if bitti else None)
        self._baslatma["asama"] = T("oynatıcı açık")
        self.alt(T("Altyazı: %s") % os.path.basename(altyazi) if altyazi else u"")
        try:
            oynatici.oynat(self.session, adres, s_(ad_goster(ad)), kaydet, baslangic,
                           geri=lambda *s: self._oynatma_bitti(sira, *s),
                           anahtar=("gdrive", u_(dosya_id)), oge=oge, altyazi=s_(altyazi) if altyazi else None)
        except Exception as e:  # noqa: BLE001 -- kilit 25 s takili kalmasin, hata gorunsun (0.1'de oldu)
            import traceback
            arka.gunluk(traceback.format_exc())
            self._baslatma_bitir(sira)
            self.hata(T("oynatıcı açılamadı: %s") % hata_metni(e))

    def _oynatma_bitti(self, sira, *sonuc):
        self._baslatma_bitir(sira)
        if not getattr(self, "canli", False):
            return
        self.goster()
        if sonuc and sonuc[0] == "hata":
            konum = sonuc[1] if len(sonuc) > 1 else 0
            if konum < 30:
                self.mesaj(T("Hata"), T("Video açılamadı. Dosya bozuk, desteklenmeyen biçimde ya da Drive erişimi reddedilmiş olabilir (oynatıcı çubuğundaki EOF kodu: 403 = izin/kota, 404 = dosya yok)."), 12)
            else:
                self.mesaj(T("Hata"), T("Oynatma %s konumunda koptu ve yeniden açılamadı. Kaldığın yer kaydedildi.") % sure_metni(konum), 10)

    # --- alt siniflar ezer ---
    def goster(self):
        pass

    def sec(self):
        pass

    def kapat(self):
        self.close()

    def kirmizi(self):
        pass

    def yesil(self):
        pass

    def sari(self):
        pass

    def mavi(self):
        pass

    def menu(self):
        self.session.openWithCallback(self._ayar_kapandi, Ayarlar)

    def _ayar_kapandi(self, *a):
        if getattr(self, "canli", False):
            self.goster()

    def bilgi(self):
        pass


def _oturum_hatasi(metin):
    return T("Google oturumu geçersiz. Ana menüde 'Google hesabı' ile yeniden giriş yapın.") if (u"giriş" in metin.lower() or u"oturum" in metin.lower()) else metin


# --- ana menu -----------------------------------------------------------------------------------
class AnaMenu(TemelEkran):
    SKIN_AD = "GDriveAnaMenu"
    KOLONLAR = [("", 460, L), ("", None, L)]

    def __init__(self, session):
        TemelEkran.__init__(self, session, u"Google Drive")
        self.tus(T("Çıkış"), T("Ara"), u"", T("Ayarlar"))
        self.onLayoutFinish.append(self.goster)

    def goster(self):
        d = drive()
        d.yukle()
        if d.giris_var():
            self.ust(d.eposta())
            satirlar = [
                ("klasor", [T("Drive'ım"), (T("klasörler ve videolar"), METIN_SOLUK)]),
                ("paylasilan", [T("Benimle paylaşılanlar"), (T("başkalarının paylaştığı dosya ve klasörler"), METIN_SOLUK)]),
                ("suruculer", [T("Paylaşılan Drive'lar"), (T("ekip/kuruluş drive'ları"), METIN_SOLUK)]),
                ("son", [T("Son izlenenler"), (T("kaldığın yerden devam"), METIN_SOLUK)]),
                ("ara", [T("Ara"), (T("tüm Drive'da dosya adına göre"), METIN_SOLUK)]),
                ("hesap", [T("Google hesabı"), (T("yeniden giriş / hesap değiştir"), METIN_SOLUK)]),
            ]
            self.alt(T("Yalnızca okuma: eklenti Drive'da hiçbir şeyi değiştiremez"))
        else:
            self.ust(T("giriş yapılmadı"))
            satirlar = [("hesap", [T("Google hesabına giriş"), (T("telefon ya da bilgisayardan, bir kez"), METIN_SOLUK)])]
            self.alt(T("Önce Google hesabına giriş yapılmalı"))
        i = self["liste"].getSelectedIndex() if self["liste"].list else 0
        self["liste"].kur(satirlar)
        self["liste"].moveToIndex(min(i, len(satirlar) - 1))
        self._arkadaki_bilgi()

    def sec(self):
        a = self["liste"].secili()
        if a == "klasor":
            self.session.open(Klasor, "klasor", "root", T("Drive'ım"))
        elif a == "paylasilan":
            self.session.open(Klasor, "paylasilan", None, T("Benimle paylaşılanlar"))
        elif a == "suruculer":
            self.session.open(Klasor, "suruculer", None, T("Paylaşılan Drive'lar"))
        elif a == "son":
            self.session.openWithCallback(self._ayar_kapandi, SonIzlenenler)
        elif a == "ara":
            self.arama_baslat()
        elif a == "hesap":
            self.session.openWithCallback(self._ayar_kapandi, Giris)

    def yesil(self):
        if drive().giris_var():
            self.arama_baslat()

    def kirmizi(self):
        self.close()

    def mavi(self):
        self.menu()


# --- klasor / liste -----------------------------------------------------------------------------
_SIRALAMALAR = ("ad", "tarih", "boyut")
_SIRA_ADI = {"ad": u"Ad", "tarih": u"Tarih", "boyut": u"Boyut"}


def _sirala(ogeler, olcut):
    klasorler = [x for x in ogeler if klasor_mu(x)]
    videolar = [x for x in ogeler if not klasor_mu(x)]
    if olcut == "tarih":
        anahtar = lambda x: x.get("modifiedTime") or u""
        ters = True
    elif olcut == "boyut":
        anahtar = lambda x: int(x.get("size") or 0)
        ters = True
    else:
        anahtar = lambda x: u_(x.get("name")).lower()
        ters = False
    klasorler.sort(key=lambda x: u_(x.get("name")).lower())
    videolar.sort(key=anahtar, reverse=ters)
    return klasorler + videolar


class Klasor(TemelEkran):
    """kip: 'klasor' (kimlik, surucu_id), 'paylasilan', 'suruculer', 'ara' (metin).
    Sayfalar (200 oge) arka planda sirayla gelir, liste dolarken gezinilebilir."""
    SKIN_AD = "GDriveKlasor"
    KOLONLAR = [("Ad", None, L), ("Süre", 140, R), ("Boyut", 130, R), ("Tarih", 170, R), ("", 150, R)]

    def __init__(self, session, kip, kimlik, ad, yol=u"", surucu_id=None, metin=None):
        self.kip, self.kimlik, self.ad, self.surucu_id, self.metin = kip, kimlik, u_(ad), surucu_id, metin
        self.yol = u_(yol)
        self.ogeler = []
        self.yukleniyor = False
        self.izleme = {}
        TemelEkran.__init__(self, session, self.ad, self.yol)
        self.tus(T("Sırala"), T("Ara"), T("İzlendi"), T("Yenile"))
        self.onLayoutFinish.append(self.yukle)

    def _yol_alt(self):
        """Alt klasorler icin baslik yolu: son iki kademe."""
        parcalar = [p for p in (self.yol.split(u"  ›  ") if self.yol else []) + [self.ad] if p]
        return u"  ›  ".join(parcalar[-2:])

    def yukle(self):
        self.ogeler = []
        self.yukleniyor = True
        self.alt(T("Yükleniyor..."))
        self["liste"].kur([])
        self._sayfa(None)

    def _sayfa(self, belirtec):
        kip, kimlik, surucu, metin = self.kip, self.kimlik, self.surucu_id, self.metin

        def al():
            d = drive()
            if kip == "klasor":
                return d.klasor(kimlik, belirtec, surucu)
            if kip == "paylasilan":
                return d.paylasilanlar(belirtec)
            if kip == "ara":
                return d.ara(metin, belirtec)
            if kip == "suruculer":
                return ([{"id": s["id"], "name": s["name"], "mimeType": "application/vnd.google-apps.folder", "surucu": True}
                         for s in d.suruculer()], None)
            return [], None

        def geldi(sonuc):
            ogeler, sonraki = sonuc
            self.ogeler.extend(ogeler)
            self.izleme.update(veri().izleme_haritasi([x.get("id") for x in ogeler if not klasor_mu(x)]))
            self.goster()
            if sonraki:
                self.alt(T("%d öğe, yükleniyor...") % len(self.ogeler))
                self._sayfa(sonraki)
            else:
                self.yukleniyor = False
                self.goster()

        def hata(m):
            self.yukleniyor = False
            self.hata(_oturum_hatasi(u_(m)))
        self.gonder(al, (), geldi, hata)

    def goster(self):
        if not getattr(self, "canli", False):
            return
        secili = self["liste"].secili()
        if not self.yukleniyor:
            self.izleme = veri().izleme_haritasi([x.get("id") for x in self.ogeler if not klasor_mu(x)])
        sirali = _sirala(self.ogeler, cfg.siralama.value)
        satirlar = [(x, self._hucreler(x)) for x in sirali]
        self["liste"].kur(satirlar)
        if secili is not None:
            for i, (x, _h) in enumerate(satirlar):
                if x.get("id") == secili.get("id"):
                    self["liste"].moveToIndex(i)
                    break
        n_k = len([x for x in self.ogeler if klasor_mu(x)])
        n_v = len(self.ogeler) - n_k
        self.ust(T("%d klasör · %d video · sıra: %s") % (n_k, n_v, T(_SIRA_ADI[cfg.siralama.value])))
        if not self.yukleniyor:
            if not self.ogeler:
                self.alt(T("Burada klasör ya da video yok") if self.kip != "ara" else T("Sonuç yok"))
            else:
                self.alt(T("OK: aç/oynat  ·  Info: dosya bilgisi  ·  Menu: ayarlar"))
                self._arkadaki_bilgi()

    def _hucreler(self, x):
        if klasor_mu(x):
            return [(u"[ %s ]" % u_(x.get("name")), RENK_KLASOR), u"", u"", (tarih_metni(x.get("modifiedTime")), METIN_SOLUK), u""]
        k = self.izleme.get(x.get("id"))
        sure = oge_suresi(x)
        durum = u""
        renk = None
        if k:
            if k["bitti"]:
                durum, renk = ISARET_BITTI, RENK_IZLENDI
            elif k["konum_sn"] > 10:
                s = k["sure_sn"] or sure
                durum = (u"%s %%%d" % (ISARET_DEVAM, k["konum_sn"] * 100 // s)) if s else (u"%s %d dk" % (ISARET_DEVAM, k["konum_sn"] // 60))
                renk = RENK_DEVAM
        return [ad_goster(x.get("name")), (sure_metni(sure), METIN_SOLUK), (boyut_metni(x.get("size")), METIN_SOLUK),
                (tarih_metni(x.get("modifiedTime")), METIN_SOLUK), (durum, renk) if renk else durum]

    def sec(self):
        x = self["liste"].secili()
        if not x:
            return
        if klasor_mu(x):
            if x.get("surucu"):
                self.session.open(Klasor, "klasor", x["id"], x["name"], self._yol_alt(), surucu_id=x["id"])
            else:
                self.session.open(Klasor, "klasor", x["id"], x["name"], self._yol_alt(), surucu_id=x.get("driveId"))
        elif video_mu(x):
            self.oynatma_iste(x)

    def kirmizi(self):
        i = _SIRALAMALAR.index(cfg.siralama.value) if cfg.siralama.value in _SIRALAMALAR else 0
        cfg.siralama.value = _SIRALAMALAR[(i + 1) % len(_SIRALAMALAR)]
        cfg.siralama.save()
        configfile.save()
        self.goster()

    def yesil(self):
        self.arama_baslat()

    def sari(self):
        """Izlendi isaretini degistir -- yalnizca kutudaki kayit; Drive'a dokunulmaz."""
        x = self["liste"].secili()
        if not x or klasor_mu(x):
            return
        k = veri().izleme_al(x["id"])
        veri().izlendi_isaretle(x["id"], x.get("name"), deger=not (k and k["bitti"]))
        self.goster()

    def mavi(self):
        if not self.yukleniyor:
            self.yukle()

    def bilgi(self):
        x = self["liste"].secili()
        if not x:
            return
        vm = x.get("videoMediaMetadata") or {}
        satirlar = [(T("Ad"), u_(x.get("name"))), (T("Tür"), u_(x.get("mimeType")))]
        if not klasor_mu(x):
            satirlar += [(T("Boyut"), boyut_metni(x.get("size")) or u"-"), (T("Süre"), sure_metni(oge_suresi(x)) or u"-"),
                         (T("Çözünürlük"), (u"%sx%s" % (vm.get("width"), vm.get("height"))) if vm.get("width") else u"-")]
            k = veri().izleme_al(x["id"])
            if k:
                satirlar.append((T("Kaldığı yer"), T("izlendi") if k["bitti"] else sure_metni(k["konum_sn"]) or u"0:00"))
        satirlar += [(T("Değiştirilme"), u_(x.get("modifiedTime"))[:16].replace(u"T", u" ") or u"-"), (T("Drive kimliği"), u_(x.get("id")))]
        self.session.open(ServisBilgisi, ad_goster(x.get("name")), satirlar)


# --- son izlenenler -----------------------------------------------------------------------------
class SonIzlenenler(TemelEkran):
    SKIN_AD = "GDriveSon"
    KOLONLAR = [("Ad", None, L), ("Kaldığı yer", 220, R), ("Tarih", 170, R), ("", 110, R)]

    def __init__(self, session):
        TemelEkran.__init__(self, session, T("Son izlenenler"))
        self.tus(T("Kapat"), u"", T("İzlendi"), u"")
        self.onLayoutFinish.append(self.goster)

    def goster(self):
        if not getattr(self, "canli", False):
            return
        satirlar = []
        for k in veri().son_izlenenler(100):
            oge = {"id": k["dosya_id"], "name": k["ad"] or k["dosya_id"], "parents": [k["klasor_id"]] if k["klasor_id"] else [],
                   "size": k["boyut"], "videoMediaMetadata": {"durationMillis": (k["sure_sn"] or 0) * 1000}}
            if k["bitti"]:
                durum, renk = ISARET_BITTI, RENK_IZLENDI
            else:
                durum, renk = ISARET_DEVAM, RENK_DEVAM
            yer = u"%s / %s" % (sure_metni(k["konum_sn"]) or u"0:00", sure_metni(k["sure_sn"]) or u"?")
            satirlar.append((oge, [ad_goster(k["ad"]), (yer, METIN_SOLUK),
                                   (time.strftime("%d.%m.%Y", time.localtime(k["tarih"])), METIN_SOLUK), (durum, renk)]))
        i = self["liste"].getSelectedIndex() if self["liste"].list else 0
        self["liste"].kur(satirlar)
        if satirlar:
            self["liste"].moveToIndex(min(i, len(satirlar) - 1))
        self.ust(T("%d kayıt") % len(satirlar))
        self.alt(T("OK: kaldığın yerden oynat") if satirlar else T("Henüz izlenen video yok"))
        self._arkadaki_bilgi()

    def sec(self):
        x = self["liste"].secili()
        if x:
            self.oynatma_iste(x)

    def kirmizi(self):
        self.close()

    def sari(self):
        x = self["liste"].secili()
        if not x:
            return
        k = veri().izleme_al(x["id"])
        veri().izlendi_isaretle(x["id"], x.get("name"), deger=not (k and k["bitti"]))
        self.goster()


# --- google girisi (telefonla) -------------------------------------------------------------------
class Giris(Screen):
    """Telefondan/PC'den Google girisi: kutunun 8790'daki formu acik kalir, durum ekranda.
    Basarida 3 sn sonra kendiliginden kapanir. Exit: formu kapatir."""

    def __init__(self, session):
        W, H = o(1500), o(900)
        k = o(50)
        self.skin = """
    <screen name="GDriveGiris" position="center,center" size="%(W)d,%(H)d" backgroundColor="%(zemin)s" flags="wfNoBorder">
        <widget name="baslik" position="%(k)d,%(by)d" size="%(icw)d,%(bh)d" font="Regular;%(bf)d" foregroundColor="#ffffff" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        <eLabel position="%(k)d,%(cy)d" size="%(icw)d,%(ch)d" backgroundColor="%(vurgu)s" />
        <widget name="ipucu" position="%(k)d,%(iy)d" size="%(icw)d,%(ih)d" font="Regular;%(fi)d" foregroundColor="#e6e9ec" backgroundColor="%(zemin)s" transparent="1" />
        <widget name="adres" position="%(k)d,%(ay)d" size="%(icw)d,%(ah)d" font="Regular;%(af)d" foregroundColor="#ffffff" backgroundColor="%(secim)s" cornerRadius="%(r)d" halign="center" valign="center" noWrap="1" />
        <widget name="adimlar" position="%(k)d,%(sy)d" size="%(icw)d,%(sh)d" font="Regular;%(sf)d" foregroundColor="#8a94a0" backgroundColor="%(zemin)s" transparent="1" />
        <widget name="durum" position="%(k)d,%(dy)d" size="%(icw)d,%(dh)d" font="Regular;%(df)d" foregroundColor="#e0b84a" backgroundColor="%(zemin)s" transparent="1" noWrap="1" />
        <widget name="key_red" position="%(k)d,%(ky)d" size="%(kw)d,%(kh)d" font="Regular;%(kf)d" foregroundColor="#ffffff" backgroundColor="%(kirmizi)s" halign="center" valign="center" cornerRadius="%(r)d" />
    </screen>""" % dict(W=W, H=H, zemin=ZEMIN(), k=k, icw=W - 2 * k, vurgu=VURGU, secim=SECIM, kirmizi=CIP["red"], r=o(12),
                        by=o(30), bh=o(50), bf=o(36), cy=o(96), ch=o(3),
                        iy=o(130), ih=o(50), fi=o(30),
                        ay=o(196), ah=o(110), af=o(56),
                        sy=o(340), sh=o(360), sf=o(27),
                        dy=o(730), dh=o(50), df=o(30),
                        ky=o(810), kw=o(330), kh=o(56), kf=o(26))
        Screen.__init__(self, session)
        self.canli = True
        self.form = None
        self["baslik"] = Label(s_(T("Google hesabına giriş")))
        self["ipucu"] = Label(s_(T("Aynı ağdaki telefon ya da bilgisayarda şu adresi açın:")))
        self["adres"] = Label("")
        self["adimlar"] = Label(s_(u"\n".join([
            T("1.  OAuth istemcisi: Google Cloud'dan indirilen client_secret JSON'unu yapıştırıp Kaydet."),
            T("2.  'Google ile giriş yap' → hesabı seç → 'doğrulanmamış uygulama' uyarısında Gelişmiş → devam."),
            T("3.  Tarayıcı 127.0.0.1:8765 adresine gidip 'bağlanılamıyor' der: bu normal."),
            T("     Adres çubuğundaki adresin tamamını kopyalayıp formun 3. adımına yapıştırın."),
            u"",
            T("İzin yalnızca okumadır (drive.readonly): eklenti Drive'da hiçbir şeyi değiştiremez."),
        ])))
        self["durum"] = Label("")
        self["key_red"] = Label(s_(T("Kapat")))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {"cancel": self.kapat, "red": self.kapat, "ok": lambda: None}, -1)
        self.kapat_z, self.kapat_b = arka.zamanlayici(self.kapat)
        self.onLayoutFinish.append(self.baslat)
        self.onClose.append(self._kapanis)

    def baslat(self):
        from .giris import GirisFormu
        d = drive()
        if d.giris_var():
            self._durum(T("Şu an bağlı: %s  ·  yeniden giriş hesabı değiştirir") % d.eposta())
        try:
            self.form = GirisFormu(d, lambda m, son: arka._ana_donguye(self._form_durum, m, son))
            self["adres"].setText(s_(u_(self.form.baslat())))
        except socket.error as e:
            self.form = None
            self["adres"].setText(s_(T("Form açılamadı")))
            self._durum(T("8790 portu kullanımda: %s") % hata_metni(e))

    def _durum(self, metin):
        self["durum"].setText(s_(u_(metin)))

    def _form_durum(self, metin, son):
        if not getattr(self, "canli", False):
            return
        self._durum(metin)
        if son:
            self.kapat_z.start(3000, True)

    def _kapanis(self):
        self.canli = False
        self.kapat_z.stop()
        if self.form:
            try:
                self.form.durdur()
            except Exception as e:  # noqa: BLE001
                arka.gunluk(u"giris formu kapatma: %s" % hata_metni(e))
            self.form = None

    def kapat(self):
        self.close()


# --- ayarlar ------------------------------------------------------------------------------------
def surum_metni():
    try:
        from .surum import SURUM, COMMIT
        return u"v%s - %s" % (u_(SURUM), u_(COMMIT)) if COMMIT else u"v%s" % u_(SURUM)
    except ImportError:
        return u""


def _ayar_skin():
    W, H = o(1400), o(860)
    k = o(40)
    return """
    <screen name="GDriveAyarlar" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">
        <widget name="baslik" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" />
        <widget name="surum" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8a94a0" backgroundColor="%s" transparent="1" halign="right" valign="center" />
        <eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" />
        <widget name="config" position="%d,%d" size="%d,%d" backgroundColor="%s" backgroundColorSelected="%s" foregroundColorSelected="#ffffff" selectionRadius="%d" scrollbarMode="showOnDemand" transparent="1" />
        <widget name="durum" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#8a94a0" backgroundColor="%s" transparent="1" />
        <widget name="key_red" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" halign="center" valign="center" cornerRadius="%d" />
        <widget name="key_green" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" halign="center" valign="center" cornerRadius="%d" />
        <widget name="key_yellow" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" halign="center" valign="center" cornerRadius="%d" />
        <widget name="key_blue" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" backgroundColor="%s" halign="center" valign="center" cornerRadius="%d" />
    </screen>""" % (W, H, ZEMIN(),
                    k, o(26), W - 2 * k - o(420), o(50), o(36), ZEMIN(),
                    W - k - o(400), o(26), o(400), o(50), o(24), ZEMIN(),
                    k, o(92), W - 2 * k, o(3), VURGU,
                    k, o(112), W - 2 * k, o(560), ZEMIN(), SECIM, o(12),
                    k, o(680), W - 2 * k, o(80), o(22), ZEMIN(),
                    k, o(776), o(330), o(56), o(26), CIP["red"], o(12),
                    k + o(360), o(776), o(330), o(56), o(26), CIP["green"], o(12),
                    k + o(720), o(776), o(270), o(56), o(22), CIP["yellow"], o(12),
                    k + o(1010), o(776), o(310), o(56), o(24), CIP["blue"], o(12))


class Ayarlar(Screen, ConfigListScreen):
    def __init__(self, session):
        self.skin = _ayar_skin()
        Screen.__init__(self, session)
        self["surum"] = Label(s_(surum_metni()))
        girdiler = [
            getConfigListEntry(s_(T("Renk teması")), cfg.tema),
            getConfigListEntry(s_(T("Ana menüde göster (enigma2 yeniden başlatılmalı)")), cfg.ana_menu),
            getConfigListEntry(s_(T("Eklentiler menüsünde göster (yeniden başlatılmalı)")), cfg.eklentiler_menu),
            getConfigListEntry(s_(T("Liste sıralaması")), cfg.siralama),
            getConfigListEntry(s_(T("Aynı klasördeki .srt altyazıyı yükle")), cfg.altyazi_dosyasi),
            getConfigListEntry(s_(T("Ses/altyazı dilini GDrive seçsin")), cfg.iz_secimi),
            getConfigListEntry(s_(T("   Ses dili tercihi")), cfg.ses_dilleri),
            getConfigListEntry(s_(T("   Gömülü altyazı")), cfg.altyazi_dilleri),
            getConfigListEntry(s_(T("   Seçim gecikmesi (akış oturduktan sonra)")), cfg.iz_gecikme),
            getConfigListEntry(s_(T("Duraklatmada tampon büyüme sınırı (bellek koruması)")), cfg.durak_siniri),
            getConfigListEntry(s_(T("Kopan oynatmayı kendiliğinden yeniden aç")), cfg.yeniden_ac),
            getConfigListEntry(s_(T("Kaldığı yer varsa")), cfg.devam),
            getConfigListEntry(s_(T("İzlendi sayılma eşiği")), cfg.izlendi_yuzde),
            getConfigListEntry(s_(T("Oynatıcı bilgi çubuğu süresi")), cfg.cubuk_sure),
            getConfigListEntry(s_(T("Sarma tuşu adımı (← → ◀◀ ▶▶)")), cfg.sarma_adim),
            getConfigListEntry(s_(T("Sarma onay bekleme süresi")), cfg.sarma_bekleme),
            getConfigListEntry(s_(T("Panel opaklığı")), cfg.opaklik),
            getConfigListEntry(s_(T("Drive bağlantı zaman aşımı")), cfg.zaman_asimi),
            getConfigListEntry(s_(T("Hata ayıklama satırı (oynatıcıda TXT tuşu)")), cfg.hata_ayiklama),
        ]
        ConfigListScreen.__init__(self, girdiler, session=session)
        self["baslik"] = Label(s_(T("Ayarlar")))
        self["durum"] = Label("")
        self["key_red"] = Label(s_(T("İptal")))
        self["key_green"] = Label(s_(T("Kaydet")))
        self["key_yellow"] = Label(s_(T("Google oturumunu kapat")))
        self["key_blue"] = Label(s_(T("Altyazı görünümü")))
        self["actions"] = ActionMap(["ColorActions", "SetupActions"], {
            "cancel": self.keyCancel, "save": self.kaydet, "red": self.keyCancel,
            "green": self.kaydet, "yellow": self.cikis_sor, "blue": self.altyazi_gorunumu,
        }, -1)
        self.onLayoutFinish.append(self.durum)
        self.onLayoutFinish.append(self._sarmala)

    def durum(self):
        d = drive()
        try:
            n = veri().izleme_sayisi()
        except Exception:  # noqa: BLE001
            n = 0
        v = _vekil[0]
        self["durum"].setText(s_(T("Hesap: %s   ·   kimlik: %s\nİzleme kaydı: %d   ·   vekil: %s   ·   izin: yalnızca okuma (drive.readonly)") % (
            d.eposta() or T("giriş yok"), KIMLIK_DOSYASI, n, (u"127.0.0.1:%d" % v.port) if v else T("kapalı"))))

    def _sarmala(self):
        try:
            self["config"].instance.setWrapAround(True)
        except Exception:  # noqa: BLE001
            pass

    def kaydet(self):
        self.saveAll()
        configfile.save()
        veri_mod.IZLENDI_YUZDE = int(cfg.izlendi_yuzde.value)
        tema_uygula()
        self.close(True)

    def keyCancel(self):
        if not self["config"].isChanged():
            self.close(False)
            return
        self.session.openWithCallback(self._iptal_cevap, Secenekler, T("Kaydetmeden çıkılsın mı?"),
                                      [(T("Evet, değişiklikleri at"), "evet"), (T("Hayır, ayarlara dön"), "hayir")])

    def _iptal_cevap(self, cevap):
        if cevap != "evet":
            return
        for x in self["config"].list:
            x[1].cancel()
        self.close(False)

    def altyazi_gorunumu(self):
        try:
            from Plugins.SystemPlugins.SubtitleStyle.ekran import AltyaziStiliAyarlari
        except ImportError:
            self["durum"].setText(s_(T("Altyazı stili eklentisi (SubtitleStyle) kurulu değil")))
            return
        self.session.open(AltyaziStiliAyarlari)

    def cikis_sor(self):
        if not drive().giris_var():
            return
        self.session.openWithCallback(self._cikis, Secenekler, T("Google oturumu kapatılsın mı?"),
                                      [(T("Evet: Google iznini geri al ve çıkış yap"), "evet"), (T("Hayır"), "hayir")])

    def _cikis(self, cevap):
        if cevap != "evet":
            return
        try:
            self["durum"].setText(s_(T("Google izni geri alınıyor...")))
        except KeyError:
            pass
        d = drive()

        def kos():
            return d.izni_geri_al()     # ag: is parcaciginda

        def bitti(tamam):
            d.cikis()                   # yerel belirtec her durumda silinir
            try:
                self.durum()
                if not tamam:
                    self["durum"].setText(s_(T("Çıkış yapıldı, ancak Google'daki izin geri alınamadı (ağ?).\n"
                                               "Elle kaldırmak için: myaccount.google.com/permissions")))
            except KeyError:            # ekran kapanmis
                pass
        arka.gonder(kos, (), bitti, lambda m: bitti(False))
