# -*- coding: utf-8 -*-
"""GDrive -- ayarlar (config.plugins.gdrive)."""
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection

try:
    _
except NameError:
    def _(txt):
        return txt

config.plugins.gdrive = ConfigSubsection()
cfg = config.plugins.gdrive

# --- menu yerlesimi ----------------------------------------------------------
cfg.ana_menu = ConfigYesNo(default=False)
cfg.eklentiler_menu = ConfigYesNo(default=True)

# --- liste -------------------------------------------------------------------
cfg.siralama = ConfigSelection(default="ad", choices=[("ad", _("Ada göre")), ("tarih", _("Tarihe göre (yeni önce)")), ("boyut", _("Boyuta göre (büyük önce)"))])
cfg.zaman_asimi = ConfigSelection(default="10", choices=[("5", "5 s"), ("10", "10 s"), ("20", "20 s")])

# --- oynatici (StalkerTV'den; ayni anlam) --------------------------------------
cfg.oynatici = ConfigSelection(default="4097", choices=[("4097", "GStreamer (4097)")])
cfg.altyazi_dosyasi = ConfigYesNo(default=True)      # ayni klasordeki .srt'yi yukle
cfg.yeniden_ac = ConfigYesNo(default=True)
cfg.iz_secimi = ConfigYesNo(default=True)
cfg.ses_dilleri = ConfigSelection(default="tr,en", choices=[("tr,en", "Türkçe, İngilizce"), ("en,tr", "İngilizce, Türkçe"), ("tr", "Türkçe"), ("en", "İngilizce"), ("", _("Dosyadaki varsayılan"))])
cfg.altyazi_dilleri = ConfigSelection(default="tr", choices=[("tr", _("Türkçe (ses Türkçe değilse)")), ("en", _("İngilizce (ses İngilizce değilse)")), ("", _("Kapalı"))])
cfg.iz_gecikme = ConfigSelection(default="5", choices=[("3", "3 s"), ("5", "5 s"), ("8", "8 s"), ("12", "12 s")])
cfg.durak_siniri = ConfigSelection(default="100", choices=[("50", "50 MB"), ("100", "100 MB"), ("200", "200 MB"), ("0", _("Kapalı"))])
cfg.sarma_adim = ConfigSelection(default="60", choices=[("10", "10 s"), ("15", "15 s"), ("30", "30 s"), ("60", "60 s"), ("120", "2 dk"), ("300", "5 dk")])
cfg.sarma_bekleme = ConfigSelection(default="1200", choices=[("800", "0,8 s"), ("1200", "1,2 s"), ("2000", "2 s"), ("0", _("Yalnızca OK ile"))])
cfg.cubuk_sure = ConfigSelection(default="5", choices=[("3", "3 s"), ("5", "5 s"), ("8", "8 s"), ("10", "10 s"), ("15", "15 s"), ("0", _("OK'e basana kadar açık"))])
cfg.izlendi_yuzde = ConfigSelection(default="90", choices=[("80", "%80"), ("90", "%90"), ("95", "%95")])
cfg.devam = ConfigSelection(default="sor", choices=[("sor", _("Sor")), ("devam", _("Kaldığı yerden devam et")), ("bastan", _("Baştan başla"))])
cfg.opaklik = ConfigSelection(default="90", choices=[(str(x), "%%%d" % x) for x in (100, 90, 80, 70, 60, 50)])
cfg.debug = ConfigYesNo(default=False)
cfg.hata_ayiklama = ConfigYesNo(default=False)

# Renk temalari StalkerTV ile ayni: (ad, zemin, secili satir, vurgu)
TEMALAR = (
    ("gece", _("Gece mavisi"), "111419", "243646", "3aa0a8"),
    ("grafit", _("Grafit"), "141517", "2a2d31", "8ea2b6"),
    ("orman", _("Orman"), "0f1613", "1f3329", "5cb48d"),
    ("murekkep", _("Mürekkep"), "121428", "272b4e", "8089d8"),
    ("bordo", _("Bordo"), "181113", "3a2128", "c4707e"),
    ("kahve", _("Kahve"), "171310", "36291f", "c89b5c"),
    ("siyah", _("Siyah (OLED)"), "000000", "242628", "3aa0a8"),
)
cfg.tema = ConfigSelection(default="gece", choices=[(t[0], t[1]) for t in TEMALAR])


def tema():
    for t in TEMALAR:
        if t[0] == cfg.tema.value:
            return t[2], t[3], t[4]
    return TEMALAR[0][2:]


KIMLIK_DOSYASI = "/etc/enigma2/gdrive.json"   # istemci + yenileme belirteci (0600); pakette yok
VERI_DIZINI = "/data/gdrive"                  # SQLite: kaldigi yer, izlendi, arama (Drive'a YAZILMAZ)
ALTYAZI_DIZINI = "/tmp/gdrive-altyazi"        # indirilen .srt'ler (UTF-8'e cevrilmis; tmpfs)
