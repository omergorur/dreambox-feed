# -*- coding: utf-8 -*-
"""
GDrive -- oynatma (StalkerTV/oynatici.py'den uyarlandi; dersleri aynen gecerli): enigma2'nin kendi oynatma altyapisi (servis 4097 / GStreamer),
ekranlar.py ile ayni gorsel dilde kendi bilgi cubugu.

- Bilgi cubugu (InfoBarShowHide): ekranin altinda koyu seffaf serit; baslik,
  ilerleme cubugu, gecen / toplam sure, kalan dakika, durum (||, >>, <<).
  Temanin MoviePlayer skin'i KULLANILMAZ: ekran adi temada olmayan bir ada
  cekilir ("GDriveOynatici"), boylece gomulu skin gecerli olur.
- Saniyede bir konum/sure okunur (bilgi cubugu); 10 s'de bir kaydet(konum, sure, False).
- Kaldigi yerden devam: ilk gecerli konumda servis alt seviyede duraklatilir, 3 s sonra
  (ses cozucusu kuruldugunda) once devam ettirilip hemen sarilir (0.71/0.87). evStart
  aninda seek henuz hazir degildi (olculdu: sarma hic calismadi).
- Cikis: Exit/Stop/TV tuslari dogrudan _kapat'a gelir (MoviePlayer'in
  "Return to movie list / delete" menusu yok); son konum kapanista yazilir.
- EOF: sure biliniyorsa %97'nin altinda kopma sayilir; cfg.yeniden_ac ile
  ayni konumdan en fazla 3 kez yeniden acilir.

Kapanis sonucu: ("bitti" | "cikti" | "hata", son_konum_sn, sure_sn)
"""
from __future__ import print_function

import time

from Screens.Screen import Screen
from Screens.InfoBarGenerics import (InfoBarShowHide, InfoBarSeek, InfoBarAudioSelection,
                                     InfoBarSubtitleSupport, InfoBarNotifications, InfoBarServiceNotifications)
from Components.ServiceEventTracker import InfoBarBase   # DreamOS'ta burada (InfoBarGenerics'te degil)
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import eServiceReference, iPlayableService, iServiceInformation, getDesktop

try:
    from enigma import (CT_MPEG2, CT_H264, CT_MPEG1, CT_MPEG4_PART2, CT_VC1, CT_VC1_SIMPLE_MAIN, CT_H265,
                        CT_VP8, CT_VP9, CT_MJPEG, CT_UNKNOWN)
    CODEC_ADLARI = {CT_MPEG2: "MPEG2", CT_H264: "H.264/AVC", CT_MPEG1: "MPEG1", CT_MPEG4_PART2: "MPEG4",
                    CT_VC1: "VC1", CT_VC1_SIMPLE_MAIN: "WMV3", CT_H265: "H.265/HEVC", CT_VP8: "VP8",
                    CT_VP9: "VP9", CT_MJPEG: "MJPEG", CT_UNKNOWN: ""}
except ImportError:
    CODEC_ADLARI = {}

try:
    from urllib import quote
except ImportError:
    from urllib.parse import quote

from Components.config import config
from .settings import cfg
from . import arka
from .arka import gunluk

try:        # harici .srt cizici ve altyazi gorunumu ayri eklentide (SubtitleStyle; paket bagimliligi)
    from Plugins.SystemPlugins.SubtitleStyle.cizici import SrtCizici
except ImportError:
    SrtCizici = None

try:
    _
except NameError:
    def _(txt):
        return txt

PTS_SN = 90000
GECIS_BEKLEME = 3.0     # sn: son GStreamer durdurmasi ile yeni playService arasi en az bekleme (0.64; olculdu: 2.4 s aralikta sokum bitmis, RSS -45 MB; 0.17 s'de hic bosalmiyor)
_son_durdurma = [0.0]   # time.time(): bizim son stopService'imiz


def _durduruldu():
    _son_durdurma[0] = time.time()


# ISO 639-2 -> 639-1 (enigma2 cogunlukla 2 harfli verir; dosya etiketi 3 harfli olabilir)
DIL_3TO2 = {"tur": "tr", "eng": "en", "ger": "de", "deu": "de", "fre": "fr", "fra": "fr", "spa": "es", "ita": "it",
            "por": "pt", "jpn": "ja", "pol": "pl", "ara": "ar", "rus": "ru", "dut": "nl", "nld": "nl"}


def _dil2(kod):
    k = (kod or "").strip().lower()
    return DIL_3TO2.get(k, k)


def _dil_eslesir(diller, tercih):
    return any(_dil2(d) == tercih for d in diller)


DURAK_KONTROL_MS = 20000


def _rss_mb():
    """enigma2'nin RSS'i (MB), /proc/self/status."""
    try:
        with open("/proc/self/status") as f:
            for satir in f:
                if satir.startswith("VmRSS:"):
                    return int(satir.split()[1]) // 1024
    except (IOError, OSError, ValueError):
        pass
    return None


def _tv_kancasini_cikar(ekran):
    """PlayerBase.__unRegisterPlayer kapaniste lastservice'i (TV) yeniden acar; cikarilan kanca sayisi.
    Not: cift alt cizgili yontemin __name__'i sinif onekini ALMAZ ("__unRegisterPlayer")."""
    n = 0
    for f in list(ekran.onClose):
        if getattr(f, "__name__", "").endswith("__unRegisterPlayer"):
            ekran.onClose.remove(f)
            n += 1
    return n


_son_tv = [None]        # son bilinen TV (DVB) servisi: EOF cikisindan sonra 'lastservice' olu akis olmasin


def _tv_servisi(ref):
    """PlayerBase kapaniste lastservice'i yeniden acar. ref bir HTTP/GStreamer akisiysa (bizim olu
    akisimiz olabilir) hatirlanan TV servisi; TV servisiyse hatirlanir (olculdu 0.66)."""
    try:
        if ref and ref.valid():
            akis = ref.type >= 4097 or (ref.getPath() or "").startswith("http")
            if not akis:
                _son_tv[0] = ref
                return ref
    except Exception:  # noqa: BLE001
        pass
    return _son_tv[0] or ref


def _b(metin):
    """eLabel.setText py2'de bayt dizgesi ister (unicode -> TypeError, olculdu)."""
    if metin is None:
        return ""
    if isinstance(metin, type(u"")):
        try:
            return metin.encode("utf-8")
        except Exception:  # noqa: BLE001
            return metin
    return metin


def _baglanti_nedeni(e):
    """requests istisnasi -> kisa neden: 'zaman aşımı' (ConnectTimeout/ReadTimeout), 'bağlantı yok'
    (ConnectionError: DNS, reddedildi, kopma); baska bir sey ise sinif adi."""
    ad = type(e).__name__
    if "Timeout" in ad:
        return _("zaman aşımı")
    if "Connection" in ad:
        return _("bağlantı yok")
    return ad


def _u(metin):
    """unicode'a cevir (ses izi adlari bayt gelebilir)."""
    if metin is None:
        return u""
    if isinstance(metin, bytes):
        return metin.decode("utf-8", "replace")
    if not isinstance(metin, type(u"")):
        return u"%s" % metin
    return metin


def _fhd():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:  # noqa: BLE001
        return False


def _o(px):
    return px if _fhd() else int(px * 2 / 3)


def _sure(sn):
    sn = max(0, int(sn or 0))
    if sn >= 3600:
        return "%d:%02d:%02d" % (sn // 3600, (sn % 3600) // 60, sn % 60)
    return "%d:%02d" % (sn // 60, sn % 60)


def servis_ref(adres, baslik, altyazi=None):
    """GStreamer servisi; adres yerel vekil (http://127.0.0.1:8766/f/<id>/<ad>).
    altyazi KULLANILMAZ (0.4): setSuburi ile verilen .srt sarmadan sonra sarma noktasi kadar kayiyor
    (eServiceMP3 hatasi, olculdu); harici altyaziyi SubtitleStyle (SrtCizici) cizer."""
    ref = eServiceReference(int(cfg.oynatici.value), 0, adres)
    try:
        ref.setName(baslik)
    except Exception:  # noqa: BLE001
        pass
    return ref


CIP = {"red": "#00a84a46", "green": "#003d8a5a", "yellow": "#00b0923a", "blue": "#004a6fb3"}
TEMA = ["111419", "243646", "3aa0a8"]     # zemin, secim, vurgu -- ekranlar.tema_uygula() gunceller


def tema_uygula(zemin, secim, vurgu):
    TEMA[:] = [zemin, secim, vurgu]


def _temala(skin):
    """Skin metnindeki 'Gece mavisi' sabitlerini secili temanin renkleriyle degistirir."""
    return skin.replace("111419", TEMA[0]).replace("243646", TEMA[1]).replace("3aa0a8", TEMA[2])


def _skin():
    W = 1920 if _fhd() else 1280
    H = 1080 if _fhd() else 720
    k = _o(60)
    serit_h = _o(290)
    y0 = H - serit_h
    cip_w, cip_h = _o(300), _o(48)
    cip_y = y0 + _o(216)
    cipler = ""
    for i, renk in enumerate(("red", "green", "yellow", "blue")):
        cipler += ('<widget name="key_%s" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="#ffffff" '
                   'backgroundColor="%s" halign="center" valign="center" cornerRadius="%d" />'
                   % (renk, W - k - (4 - i) * cip_w - (3 - i) * _o(20), cip_y, cip_w, cip_h, _o(24), CIP[renk], _o(10)))
    return _temala("""
    <screen name="GDriveOynatici" position="0,0" size="%(W)d,%(H)d" backgroundColor="transparent" flags="wfNoBorder">
        <eLabel position="0,%(y0)d" size="%(W)d,%(serit)d" backgroundColor="#30111419" zPosition="-1" />
        <widget name="baslik" position="%(k)d,%(by)d" size="%(bw)d,%(bh)d" font="Regular;%(bf)d" foregroundColor="#ffffff" backgroundColor="#30111419" transparent="1" valign="center" noWrap="1" />
        <widget source="global.CurrentTime" render="Label" position="%(dx)d,%(by)d" size="%(dw)d,%(bh)d" font="Regular;%(saf)d" foregroundColor="#8a94a0" backgroundColor="#30111419" transparent="1" halign="right" valign="center">
            <convert type="ClockToText">Default</convert>
        </widget>
        <widget name="durum" position="%(fx)d,%(fy)d" size="%(fw)d,%(fh)d" font="Regular;%(df)d" foregroundColor="#3aa0a8" backgroundColor="#30111419" transparent="1" valign="center" />
        <eLabel position="%(k)d,%(cy)d" size="%(cw)d,%(ch)d" backgroundColor="#00243646" cornerRadius="%(cr)d" />
        <widget source="session.CurrentService" render="Progress" position="%(k)d,%(cy)d" size="%(cw)d,%(ch)d" backgroundColor="#00243646" foregroundColor="#3aa0a8" transparent="1" zPosition="1">
            <convert type="ServicePosition">Position</convert>
        </widget>
        <widget name="gecen" position="%(k)d,%(ty)d" size="%(tw)d,%(th)d" font="Regular;%(tf)d" foregroundColor="#e6e9ec" backgroundColor="#30111419" transparent="1" />
        <widget name="kalan" position="%(kx)d,%(ty)d" size="%(kw)d,%(th)d" font="Regular;%(tf)d" foregroundColor="#8a94a0" backgroundColor="#30111419" transparent="1" halign="center" />
        <widget name="toplam" position="%(sx)d,%(ty)d" size="%(tw)d,%(th)d" font="Regular;%(tf)d" foregroundColor="#e6e9ec" backgroundColor="#30111419" transparent="1" halign="right" />
        <widget name="atlama" position="%(ax)d,%(ay)d" size="%(aw)d,%(ah)d" font="Regular;%(af)d" foregroundColor="#e0b84a" backgroundColor="#30111419" transparent="1" halign="center" />
        %(cipler)s
        <widget name="video" position="%(vx)d,%(vy)d" size="%(vw)d,%(vh)d" font="Regular;%(vf)d" foregroundColor="#8a94a0" backgroundColor="#30111419" transparent="1" />
        <widget name="dosya" position="%(fx)d,%(fy)d" size="%(fw)d,%(fh)d" font="Regular;%(vf)d" foregroundColor="#8a94a0" backgroundColor="#30111419" transparent="1" valign="center" />
    </screen>""" % dict(W=W, H=H, y0=y0, serit=serit_h, k=k, cipler=cipler,
                        by=y0 + _o(30), bw=W - 2 * k - _o(340), bh=_o(50), bf=_o(38),
                        dx=W - k - _o(340), dw=_o(340), saf=_o(32), df=_o(26),
                        cy=y0 + _o(104), cw=W - 2 * k, ch=_o(10), cr=_o(5),
                        ty=y0 + _o(132), tw=_o(400), th=_o(40), tf=_o(28),
                        kx=(W - _o(800)) // 2, kw=_o(800), sx=W - k - _o(400),
                        ax=(W - _o(400)) // 2, ay=y0 + _o(28), aw=_o(400), ah=_o(50), af=_o(32),
                        vx=k, vy=y0 + _o(176), vw=_o(1100), vh=_o(36), vf=_o(24),
                        fx=k, fy=cip_y, fw=_o(520), fh=cip_h))


def _sarma_skin():
    W = 1920 if _fhd() else 1280
    H = 1080 if _fhd() else 720
    kw, kh = _o(560), _o(200)
    x, y = (W - kw) // 2, (H - kh) // 2
    return _temala("""
    <screen name="GDriveSarma" position="%d,%d" size="%d,%d" backgroundColor="transparent" flags="wfNoBorder" zPosition="1000">
        <eLabel position="0,0" size="%d,%d" backgroundColor="#00151a20" cornerRadius="%d" />
        <widget name="metin" position="0,%d" size="%d,%d" font="Regular;%d" foregroundColor="#e0b84a" backgroundColor="#00151a20" transparent="1" halign="center" zPosition="1" />
        <widget name="hedef" position="0,%d" size="%d,%d" font="Regular;%d" foregroundColor="#e6e9ec" backgroundColor="#00151a20" transparent="1" halign="center" zPosition="1" />
        <widget name="cubuk" position="%d,%d" size="%d,%d" backgroundColor="#00243646" foregroundColor="#3aa0a8" zPosition="1" />
    </screen>""" % (x, y, kw, kh, kw, kh, _o(16),
                    _o(22), kw, _o(60), _o(44),
                    _o(90), kw, _o(40), _o(26),
                    _o(40), _o(146), kw - _o(80), _o(10)))


def _sys_oku(yol):
    try:
        with open(yol) as f:
            return f.read()
    except (IOError, OSError):
        return ""


def _vdec_durumu():
    """Amlogic cozucu (ilk kanal): {'ad','w','h','fps','kare','dusen','hata','bit'}; vdec yoksa bos."""
    d = {}
    for satir in _sys_oku("/sys/class/vdec/vdec_status").splitlines():
        if ":" not in satir:
            continue
        k, v = satir.split(":", 1)
        k, v = k.strip(), v.strip()
        if k == "device name":
            if "ad" in d:
                break                       # ikinci kanal: ilki yeter
            d["ad"] = v.split("-")[0].replace("ammvdec_", "").replace("amvdec_", "")
        elif k == "frame width":
            d["w"] = v
        elif k == "frame height":
            d["h"] = v
        elif k == "frame rate":
            d["fps"] = v.replace(" fps", "")
        elif k == "frame count":
            try:
                d["kare"] = int(v)
            except ValueError:
                pass
        elif k == "drop count":
            d["dusen"] = v
        elif k == "fra err count":
            d["hata"] = v
        elif k == "bit rate":
            d["bit"] = v
    return d


def _vbuf_yuzde():
    """Cozucu video tamponu doluluk yuzdesi (/sys/class/amstream/bufs, Video-0) ya da None."""
    boyut = seviye = None
    for satir in _sys_oku("/sys/class/amstream/bufs").splitlines():
        s = satir.strip()
        if s.startswith("buf size:") and boyut is None:
            boyut = int(s.split(":")[1].strip(), 16)
        elif s.startswith("buf level:") and seviye is None:
            seviye = int(s.split(":")[1].strip(), 16)
        if boyut is not None and seviye is not None:
            break
    return int(seviye * 100 / boyut) if boyut else None


def _av_fark_ms():
    """Video PTS - PCR (ms); tsync okunamazsa None."""
    try:
        v = int(_sys_oku("/sys/class/tsync/pts_video").strip(), 16)
        p = int(_sys_oku("/sys/class/tsync/pts_pcrscr").strip(), 16)
        if v == 0xffffffff or p == 0xffffffff:
            return None
        return (v - p) // 90
    except ValueError:
        return None


def _is_parcacigi():
    for satir in _sys_oku("/proc/self/status").splitlines():
        if satir.startswith("Threads:"):
            return satir.split()[1]
    return "?"


def _debug_skin():
    W = getDesktop(0).size().width()
    k, h = _o(40), _o(40)
    return """
    <screen name="GDriveHataAyiklama" position="0,0" size="%d,%d" backgroundColor="#30111419" flags="wfNoBorder" zPosition="5">
        <widget name="metin" position="%d,0" size="%d,%d" font="Regular;%d" foregroundColor="#e0b84a" backgroundColor="#30111419" transparent="1" valign="center" noWrap="1" />
    </screen>""" % (W, h, k, W - 2 * k, h, _o(22))


class HataAyiklamaKutusu(Screen):
    """Ust satirda anlik cozucu/tampon bilgisi (Kodi debug OSD'si gibi); bilgi cubugundan BAGIMSIZ diyalog."""

    def __init__(self, session):
        self.skin = _debug_skin()
        Screen.__init__(self, session)
        self["metin"] = Label("")

    def guncelle(self, metin):
        self["metin"].setText(_b(metin))


class SarmaKutusu(Screen):
    """Biriktirmeli sarma gostergesi: bilgi cubugundan BAGIMSIZ diyalog
    (InfoBarShowHide.hide() tum oynatici ekranini gizliyor; kutu ayni ekranda
    olunca cubukla birlikte kayboluyordu -- olculdu)."""

    def __init__(self, session):
        self.skin = _sarma_skin()
        Screen.__init__(self, session)
        self["metin"] = Label("")
        self["hedef"] = Label("")
        self["cubuk"] = ProgressBar()

    def guncelle(self, fark, hedef, sure):
        self["metin"].setText(_b((u"+%s" if fark >= 0 else u"-%s") % _sure(abs(fark))))
        self["hedef"].setText(_b(u"%s  /  %s" % (_sure(hedef), _sure(sure) if sure else u"--:--")))
        if sure:
            self["cubuk"].setValue(int(hedef * 100 / sure))


class DriveOynatici(Screen, InfoBarBase, InfoBarShowHide, InfoBarSeek, InfoBarAudioSelection,
                      InfoBarSubtitleSupport, InfoBarNotifications, InfoBarServiceNotifications):
    """Kapanis: close(sonuc, konum_sn, sure_sn)."""
    # Standby bizim akisi kaydedip uyaninca bastan acmasin; bekleme kipinde akisi biz kapatiriz (_bekleme_kipi)
    ALLOW_SUSPEND = Screen.SUSPEND_NONE

    def __init__(self, session, adres, baslik, kaydet=None, baslangic_sn=0, devral=False, anahtar=None, son_servis=None, devralinan=None, oge=None, adres_al=None, altyazi=None):
        self.altyazi = altyazi    # indirilmis .srt yolu ya da None
        self.oge = oge                # icerik sozlugu (Info: afis ve ozet)
        self.devral = devral          # True: servis zaten oynuyor (arkadan donus), yeniden acma
        self.devralinan = devralinan  # ArkadakiOynatma: son konum/sure/video bilgisi (cubuk bos gelmesin)
        self.anahtar = anahtar        # (tur, icerik_id, sezon, bolum) -- liste ekranlari icin
        self.skin = _skin()
        Screen.__init__(self, session)
        self.skinName = ["GDriveOynatici"]
        self.adres = adres
        self.baslik = baslik
        self.kaydet = kaydet
        self.baslangic_sn = int(baslangic_sn or 0)
        self.son_konum = self.baslangic_sn
        self.son_sure = 0
        self.yeniden_deneme = 0
        self._sarmayi_sifirla()
        self.kapaniyor = False
        self.tik_sayac = 0           # tik() devral yolunda baslat() icinden erken cagrilir
        self.adres_al = adres_al     # is parcaciginda cagrilir: GDrive kullanmaz (None)
        self.eof_sayac = 0           # ilk saniyelerde EOF (yayin acilamadi) sayisi
        self.acilamadi = False
        self.baglanti_uyarisi = False   # cubukta 'sunucu yanit vermiyor' yaziyor (ilk gecerli konumda silinir)

        self["baslik"] = Label(_b(baslik))
        self["durum"] = Label("")
        self["gecen"] = Label("0:00")
        self["kalan"] = Label("")
        self["toplam"] = Label("")
        self["atlama"] = Label("")
        self["video"] = Label("")
        self["dosya"] = Label("")
        self.sarma_hedefi = None          # biriktirilen hedef (sn); None = kutu kapali
        self.sarma_kutusu = session.instantiateDialog(SarmaKutusu)
        self.sarma_kutusu.neverAnimate()
        self.debug_kutusu = session.instantiateDialog(HataAyiklamaKutusu)   # TXT: hata ayiklama satiri (0.99.1)
        self.debug_kutusu.neverAnimate()
        self.debug_acik = False
        # harici .srt: SubtitleStyle cizer (setSuburi sarmadan sonra kayiyordu; GDrive 0.4)
        self.srt = SrtCizici(session, altyazi, self._srt_durum) if (altyazi and SrtCizici) else None
        if self.srt is not None and not self.srt.var():
            self.srt.kapat()
            self.srt = None
        self._vdec_onceki = None          # (kare sayisi, zaman) -> cozulen kare/s
        self.video_bilgisi = ""
        self.dosya_boyutu = 0           # bayt (Range 0-0 ile; 0 = bilinmiyor)
        self.dosya_bilgisi = u""        # "2.79 GB · 9.0 Mbit/s" (cubuk ve servis bilgisi)
        self["key_red"] = Label(_b(_("Baştan")))
        self["key_green"] = Label(_b(_("Yeniden bağlan")))
        self["key_yellow"] = Label(_b(_("Ses")))
        self["key_blue"] = Label(_b(_("Altyazı")))

        for x in (InfoBarBase, InfoBarShowHide, InfoBarSeek, InfoBarAudioSelection,
                  InfoBarSubtitleSupport, InfoBarNotifications, InfoBarServiceNotifications):
            x.__init__(self)
        # PlayerBase (InfoBarSeek'in tabani) kapaniste self.lastservice'i (TV kanali)
        # geri acar. Arkadan donuste ya da baska icerige gecerken o anki servis
        # akisin kendisi olur; TV kanali ilk oynaticidan tasinir.
        if son_servis is not None:
            self.lastservice = son_servis
        self.lastservice = _tv_servisi(self.lastservice)
        try:        # dosya ici (MKV) altyazi: bilgi cubugu acikken cubugun ustune (SubtitleStyle)
            from Plugins.SystemPlugins.SubtitleStyle.kaydir import cubukla_kaydir
            cubukla_kaydir(self, 290)
        except ImportError:
            pass

        self["gd_actions"] = ActionMap(["MoviePlayerActions", "OkCancelActions", "InfobarActions", "ColorActions", "NumberActions", "EPGSelectActions", "MenuActions", "InfobarTeletextActions"], {
            "startTeletext": self.hata_ayiklama_degistir,   # TXT: hata ayiklama satiri ac/kapat
            "info": self.ayrinti,            # Info: afis ve ozet
            "menu": self.menu,               # Menu: secenekler
            "leavePlayer": self.durdur,      # Stop: oynatmayi bitir, listeye don
            "cancel": self.arkada_birak,     # Exit: oynatma arkada surer, listeye don
            "showMovies": self.durdur,
            "showTv": self.durdur,
            "ok": self.ok,                   # OK: sarma bekliyorsa uygula, yoksa cubuk
            "1": lambda: self.biriktir(-15), "3": lambda: self.biriktir(15),
            "4": lambda: self.biriktir(-60), "6": lambda: self.biriktir(60),
            "7": lambda: self.biriktir(-300), "9": lambda: self.biriktir(300),
            "2": lambda: self.biriktir(-30), "8": lambda: self.biriktir(30),
            "5": self.sarma_iptal, "0": self.sarma_iptal,
            "red": self.bastan,
            "green": self.yeniden_baglan,
            "yellow": self.ses_sec,
            "blue": self.altyazi_degistir,
        }, -2)
        self.atlama_zamanlayici, self.atlama_baglanti = arka.zamanlayici(self._atlama_sil)
        self.sarma_zamanlayici, self.sarma_baglanti = arka.zamanlayici(self.sarmayi_uygula)
        self.konum_zamanlayici, self.konum_baglanti = arka.zamanlayici(self.tik)
        self.gecis_zamanlayici, self.gecis_baglanti = arka.zamanlayici(self._ilk_ac)
        # iz secimi (0.67): TrackAutoselect'in erken gecisi yerine akis oturunca biz seceriz
        self.iz_secildi = False
        self._tas_eski = None
        self.iz_zamanlayici, self.iz_baglanti = arka.zamanlayici(self._iz_sec)
        self.durak_zamanlayici, self.durak_baglanti = arka.zamanlayici(self._durak_bosalt)   # duraklatmada bellek korumasi
        self.olaylar = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self._iz_basla,
            iPlayableService.evAudioListChanged: self._iz_planla,
            iPlayableService.evEOF: self.servis_bitti,
            iPlayableService.evUser + 12: self.servis_bitti,
        })
        self.onPlayStateChanged.append(self._oynatma_durumu)
        self.onLayoutFinish.append(self.baslat)
        self.onClose.append(self._temizle)
        _acik_oynatici[0] = self

    # --- yasam dongusu ---
    def _dosya_boyutunu_al(self):
        """Boyut Drive ust verisinden gelir (oge['size']); vekile ek istek yapilmaz."""
        try:
            self.dosya_boyutu = int((self.oge or {}).get("size") or 0)
        except (TypeError, ValueError):
            self.dosya_boyutu = 0
        self._dosya_bilgisini_guncelle()

    def _durum(self, metin):
        """Durum (EOF · 460, duraklatildi, »» 2x, sunucu yanit vermiyor) boyut · bit hizi satirinda;
        doluyken dosya bilgisi gizlenir (EOF'ta zaten bos), silinince geri gelir."""
        self["durum"].setText(metin)
        try:
            (self["dosya"].hide if metin else self["dosya"].show)()
        except Exception:  # noqa: BLE001
            pass

    def _dosya_bilgisini_guncelle(self):
        if not self.dosya_boyutu:
            return
        gb = self.dosya_boyutu / (1024.0 ** 3)
        metin = (u"%.2f GB" % gb) if gb >= 1 else (u"%.0f MB" % (self.dosya_boyutu / (1024.0 ** 2)))
        if self.son_sure > 0:
            metin += u"  \u00b7  %.1f Mbit/s" % (self.dosya_boyutu * 8 / 1000000.0 / self.son_sure)
        if metin != self.dosya_bilgisi:
            self.dosya_bilgisi = metin
            self._video_etiketi()

    def _video_etiketi(self):
        self["video"].setText(_b(self.video_bilgisi or u""))
        self["dosya"].setText(_b(self.dosya_bilgisi or u""))

    # --- iz secimi (ses/altyazi dili) ---
    def _tas_kapat(self):
        """TrackAutoselect'i bizim akis icin kapat (config degeri bellekte, kaydedilmez; kapanista geri).
        Olculdu: akis basladiktan 270 ms sonra yaptigi ses gecisi S3B10'da 5/5 SIGSEGV."""
        if not cfg.iz_secimi.value or self._tas_eski is not None:
            return
        try:
            c = config.plugins.TrackAutoselect.handle_services
            if "servicegst" in c.value:
                self._tas_eski = list(c.value)
                c.value = [x for x in c.value if x != "servicegst"]
                gunluk("TrackAutoselect bizim akista kapatildi (gecici)")
        except Exception:  # noqa: BLE001
            pass

    def _tas_ac(self):
        if self._tas_eski is None:
            return
        try:
            config.plugins.TrackAutoselect.handle_services.value = self._tas_eski
        except Exception:  # noqa: BLE001
            pass
        self._tas_eski = None

    def _iz_basla(self):
        self.iz_secildi = False
        self._iz_konum = None
        self._iz_deneme = 0
        self._iz_planla()

    def _iz_planla(self):
        if not cfg.iz_secimi.value or self.iz_secildi or getattr(self, "kapaniyor", True):
            return
        self.iz_zamanlayici.start(int(cfg.iz_gecikme.value) * 1000, True)

    def _iz_sec(self):
        """Akis oturduktan sonra bir kez: ses izi dil tercihine gore, altyazi ses ilk tercih degilse.
        0.93: yalnizca konum ilerliyorsa (iki ornek, 1 s ara). selectTrack GStreamer akis kilidini bekler;
        kaynak takilmissa (429, sunucu yanit vermiyor) ana dongu sonsuza kadar kilitleniyordu (olculdu,
        bekci yeniden baslatti). Ilerlemiyorsa 1 s sonra yeniden bakilir, 15 denemede vazgecilir."""
        if getattr(self, "kapaniyor", True) or self.iz_secildi or self.acilamadi:
            return
        if self.baglanti_uyarisi:
            self._iz_deneme = getattr(self, "_iz_deneme", 0) + 1
            if self._iz_deneme <= 15:
                self.iz_zamanlayici.start(1000, True)
            return
        konum, _sure_ = self._konum()
        onceki = getattr(self, "_iz_konum", None)
        deneme = getattr(self, "_iz_deneme", 0)
        if konum is None or onceki is None or konum <= onceki:
            self._iz_konum = konum
            self._iz_deneme = deneme + 1
            if self._iz_deneme <= 15:
                self.iz_zamanlayici.start(1000, True)
            else:
                gunluk("ses izi secimi atlandi: akis ilerlemiyor")
                self.iz_secildi = True
            return
        self.iz_secildi = True
        tercihler = [t for t in cfg.ses_dilleri.value.split(",") if t]
        try:
            servis = self.session.nav.getCurrentService()
            izler = servis and servis.audioTracks()
            n = izler and izler.getNumberOfTracks() or 0
            secilen_dil = None
            if n and tercihler:
                simdiki = izler.getCurrentTrack()
                for tercih in tercihler:
                    aday = None
                    for i in range(n):
                        if _dil_eslesir(izler.getTrackInfo(i).getLanguage().split("/"), tercih):
                            aday = i
                            break
                    if aday is not None:
                        secilen_dil = tercih
                        if aday != simdiki:
                            gunluk("ses izi: %d -> %d (%s)" % (simdiki, aday, tercih))
                            izler.selectTrack(aday)
                        break
            elif n:
                try:
                    secilen_dil = _dil2(izler.getTrackInfo(izler.getCurrentTrack()).getLanguage().split("/")[0])
                except Exception:  # noqa: BLE001
                    secilen_dil = None
            alt = cfg.altyazi_dilleri.value
            if alt and secilen_dil != alt:
                subs = self.getCurrentServiceSubtitle()
                m = subs and subs.getNumberOfSubtitleTracks() or 0
                for i in range(m):
                    if _dil_eslesir(subs.getSubtitleTrackInfo(i).getLanguage().split("/"), alt):
                        gunluk("altyazi: %d (%s) acildi" % (i, alt))
                        self.setSelectedSubtitle(i)
                        self.setSubtitlesEnable(True)
                        break
        except Exception as e:  # noqa: BLE001
            gunluk("iz secimi: %s" % e)

    def baslat(self):
        self._tas_kapat()
        if not self.devral:
            bekle = GECIS_BEKLEME - (time.time() - _son_durdurma[0])
            if bekle > 0.05:
                # eski boru hatti sokulurken yeni servis acmak enigma2'yi cokertebiliyor (0.64)
                gunluk("akis gecisi: %.1f sn bekleniyor" % bekle)
                self._durum(_b(_("önceki akış kapatılıyor")))
                self.doShow()
                self.gecis_zamanlayici.start(int(bekle * 1000), True)
            else:
                self._ilk_ac()
        elif self.devralinan is not None:
            # arkadan donus: ekran yeniden kuruldu, etiketler bos; bilinen degerleri hemen bas
            d = self.devralinan
            self.son_konum, self.son_sure, self.video_bilgisi = d.konum_sn, d.sure_sn, d.video_bilgisi
            self.dosya_boyutu = getattr(d, "dosya_boyutu", 0)
            self["gecen"].setText(_b(_sure(self.son_konum)))
            self["toplam"].setText(_b(_sure(self.son_sure) if self.son_sure else ""))
            if self.son_sure:
                self["kalan"].setText(self._kalan_metni(self.son_konum))
            self._dosya_bilgisini_guncelle()
            self._video_etiketi()
            self.tik()
        if not self.dosya_boyutu:
            self._dosya_boyutunu_al()
        self.konum_zamanlayici.start(1000, False)
        if self.srt:
            self.srt.baslat()

    def _ilk_ac(self):
        if getattr(self, "kapaniyor", True):
            return
        self._durum(_b(u""))
        self.session.nav.playService(servis_ref(self.adres, self.baslik, self.altyazi))

    def _temizle(self):
        if _acik_oynatici[0] is self:
            _acik_oynatici[0] = None
        self.konum_zamanlayici.stop()
        self.atlama_zamanlayici.stop()
        self.gecis_zamanlayici.stop()
        self.iz_zamanlayici.stop()
        self.durak_zamanlayici.stop()
        if self.srt:
            self.srt.kapat()
        self._tas_ac()
        for kutu in (self.sarma_kutusu, self.debug_kutusu):
            try:
                self.session.deleteDialog(kutu)
            except Exception:  # noqa: BLE001
                pass

    def _sarmayi_sifirla(self):
        """Yeni (yeniden) acilista: baslangic_sn > 0 ise ilk gecerli konumda sarma yapilacak."""
        self.sarildi = self.baslangic_sn <= 0
        self._sarma_ilk = None

    # --- konum ---
    def _konum(self):
        try:
            servis = self.session.nav.getCurrentService()
            seek = servis and servis.seek()
            if not seek:
                return None, None
            k = seek.getPlayPosition()
            s = seek.getLength()
            konum = k[1] // PTS_SN if (k and not k[0]) else None
            sure = s[1] // PTS_SN if (s and not s[0]) else 0
            if konum is not None and self.srt:
                self.srt.ornek(k[1] // 90)      # altyazi cizici icin ms ornegi (ek sorgu yok)
            return konum, sure
        except Exception:  # noqa: BLE001
            return None, None

    def tik(self):
        """Saniyede bir: bilgi cubugu; 10 sn'de bir kayit; ilk gecerli konumda sarma."""
        konum, sure = self._konum()
        if konum is None:
            return
        self.konum_goruldu = True
        if not self.sarildi and konum >= 0:
            # Kaldigi yere sarma (0.71): ilk gecerli konumda hemen sarmak ses kaybina yol aciyordu
            # (1,2 s'de cozucu kurulmamis), gec sarmak ise bas kismi oynatiyordu. Simdi: ilk konumda
            # servis alt seviyede duraklatilir (bas oynamaz), 3 s sonra sarilir, 1 s sonra devam.
            ilk = getattr(self, "_sarma_ilk", None)
            simdi = time.time()
            if ilk is None:
                self._sarma_ilk = (konum, simdi)
                self._sarma_duraklatildi = self._alt_duraklat()
                return
            if simdi - ilk[1] < 3.0:
                # tamponlama bitince eServiceMP3 PLAYING'e gecip pause'u eziyor: ilerlediyse yeniden duraklat
                if getattr(self, "_sarma_duraklatildi", False) and konum > ilk[0]:
                    self._alt_duraklat()
                return
            self.sarildi = True
            # PAUSED durumda sarip sonra devam edince ses gelmiyor: once devam, hemen ardindan sarma (0.87)
            if getattr(self, "_sarma_duraklatildi", False):
                self._alt_duraklat(devam=True)
            try:
                self.doSeek(self.baslangic_sn * PTS_SN)
                gunluk("kaldigi yere sarildi: %d sn" % self.baslangic_sn)
            except Exception as e:  # noqa: BLE001
                gunluk("sarma basarisiz: %s" % e)
            return
        # duraklatma bekcisi (0.72): UI duraklatilmis ama konum ilerliyorsa (flush'li sarma sonrasi
        # eServiceMP3 tamponlama bitince kendiliginden surduruyor) yeniden duraklat
        if self.seekstate == self.SEEK_STATE_PAUSE:
            onceki = getattr(self, "_durak_konum", None)
            if onceki is not None and konum > onceki:
                gunluk("duraklatma bekcisi: konum ilerledi (%d -> %d), yeniden duraklatildi" % (onceki, konum))
                self._alt_duraklat()
            self._durak_konum = konum
        else:
            self._durak_konum = None
        self.son_konum = konum
        if (self.acilamadi or self.baglanti_uyarisi) and konum > 10:
            self.acilamadi = False
            self.baglanti_uyarisi = False
            self.eof_sayac = 0
            self._durum(_b(""))
        if sure:
            self.son_sure = sure
        self["gecen"].setText(_b(_sure(konum)))
        self["toplam"].setText(_b(_sure(self.son_sure) if self.son_sure else ""))
        if self.son_sure:
            self["kalan"].setText(self._kalan_metni(konum))
        else:
            self["kalan"].setText("")
        if not self.video_bilgisi or self.tik_sayac % 5 == 0:
            self._video_bilgisi()
        if self.dosya_boyutu and (not self.dosya_bilgisi or u"Mbit" not in self.dosya_bilgisi):
            self._dosya_bilgisini_guncelle()
        self.tik_sayac += 1
        if self.debug_acik:
            self._hata_ayiklama_guncelle()
        if self.tik_sayac % 10 == 0 and self.kaydet:
            try:
                self.kaydet(self.son_konum, self.son_sure, False)
            except Exception as e:  # noqa: BLE001
                gunluk("konum kaydi hatasi: %s" % e)

    def _kalan_metni(self, konum):
        """'-23 dk  ·  bitiş 21:40' (bayt)."""
        kalan = max(0, self.son_sure - konum)
        return _b(u"-%d dk  \u00b7  " % (kalan // 60) + _("bitiş %s") % time.strftime("%H:%M", time.localtime(time.time() + kalan)))

    def _video_bilgisi(self):
        """1920x1080@50i gibi; iServiceInformation'dan (henuz yoksa bos)."""
        try:
            servis = self.session.nav.getCurrentService()
            info = servis and servis.info()
            if not info:
                return
            w = info.getInfo(iServiceInformation.sVideoWidth)
            h = info.getInfo(iServiceInformation.sVideoHeight)
            fps = info.getInfo(iServiceInformation.sFrameRate)
            prog = info.getInfo(iServiceInformation.sProgressive)
            if w <= 0 or h <= 0:
                return
            # bicim: 1920x1080p25 [H.264/AVC]
            metin = u"%dx%d" % (w, h)
            metin += u"p" if prog == 1 else (u"i" if prog == 0 else u"")
            if fps > 0:
                hz = fps / 1000.0
                metin += ("%d" % round(hz)) if abs(hz - round(hz)) < 0.05 else ("%.2f" % hz).rstrip("0")
            try:
                codec = CODEC_ADLARI.get(info.getInfo(iServiceInformation.sVideoType), "")
            except Exception:  # noqa: BLE001
                codec = ""
            if codec:
                metin += u" [%s]" % codec
            if metin != self.video_bilgisi:
                self.video_bilgisi = metin
                self._video_etiketi()
        except Exception:  # noqa: BLE001
            pass

    # --- durum metni: InfoBarSeek.onPlayStateChanged kancasi (setSeekState ustune
    # yazilmaz; DreamOS imzasi setSeekState(state, onlyGUI) -- olculdu: 2 parametreli
    # ustune yazma 'takes exactly 2 arguments (3 given)' ile yesil ekran) ---
    def _oynatma_durumu(self, state):
        try:
            if state == self.SEEK_STATE_PAUSE:
                self._durum(_b(u"||  " + _("Duraklatıldı")))
                if int(cfg.durak_siniri.value) > 0:
                    self._durak_rss0 = _rss_mb()
                    self.durak_zamanlayici.start(DURAK_KONTROL_MS, False)
            elif state == self.SEEK_STATE_PLAY:
                self.durak_zamanlayici.stop()
                self._durum(_b(""))
            elif state[1] > 1:
                self._durum(_b(u"\u00bb\u00bb %dx" % state[1]))
            elif state[1] < 0:
                self._durum(_b(u"\u00ab\u00ab %dx" % -state[1]))
            elif state[2] and state[2] > 1:
                self._durum(_b(_("ağır çekim")))
            if state != self.SEEK_STATE_PLAY:
                self.doShow()
        except Exception as e:  # noqa: BLE001
            gunluk("oynatma durumu: %s" % e)

    def _durak_bosalt(self):
        """Duraklatmada 20 s'de bir: RSS duraklatma basindan beri sinirdan fazla buyuduyse ayni konuma
        flush'li sarma (kuyruklar bosalir; coklu izli dosyalarda multiqueue duraklatmada sinirsiz buyur,
        ~28 MB/dk; iyi huylu dosyada hic buyumez, dokunulmaz). Servis acik kalir, kare ekranda."""
        if getattr(self, "kapaniyor", True) or self.seekstate != self.SEEK_STATE_PAUSE:
            self.durak_zamanlayici.stop()
            return
        rss = _rss_mb()
        rss0 = getattr(self, "_durak_rss0", None)
        if rss is None:
            return
        if rss0 is None:
            self._durak_rss0 = rss                # bosaltma sonrasi yeni taban
            return
        if rss - rss0 < int(cfg.durak_siniri.value):
            return
        konum, _sure_ = self._konum()
        if konum is None:
            return
        try:
            self.doSeek(konum * PTS_SN)
            self._alt_duraklat()                  # sarma pipeline'i surdurebiliyor; tik'teki bekci de var
            gunluk("duraklatma: tampon bosaltildi @ %d sn (RSS %d MB, sinir %s MB asildi)" % (konum, rss, cfg.durak_siniri.value))
        except Exception as e:  # noqa: BLE001
            gunluk("duraklatma bosaltma: %s" % e)
        self._durak_rss0 = None                   # taban bir sonraki kontrolde (bosalma sonrasi) olculur

    def _alt_duraklat(self, devam=False):
        """Servisi alt seviyede duraklat / devam ettir (InfoBarSeek durumuna dokunmadan). Basarili -> True."""
        try:
            servis = self.session.nav.getCurrentService()
            p = servis and servis.pause()
            if not p:
                return False
            (p.unpause if devam else p.pause)()
            return True
        except Exception as e:  # noqa: BLE001
            gunluk("alt %s: %s" % ("devam" if devam else "duraklatma", e))
            return False

    # --- bilgi cubugu suresi (InfoBarShowHide.startHideTimer'in yerine) ---
    def startHideTimer(self):
        try:
            sn = int(cfg.cubuk_sure.value)
        except Exception:  # noqa: BLE001
            sn = 5
        self.hideTimer.stop()
        if sn > 0:
            self.hideTimer.start(sn * 1000, True)   # 0: OK'e basana kadar acik (Kodi tarzi)

    # --- ◀◀ / ▶▶ : HTTP akisinda GStreamer hizli sarma (2x..) vermez; InfoBarSeek.seekFwd
    # o zaman temanin "No fast winding possible.. use the number buttons" kutusunu aciyordu
    # (olculdu). Kodi gibi: tuslar ±60 sn biriktirir (kutu, OK ya da 1,2 sn). Akis hizli
    # sarmayi destekliyorsa (isCurrentlySeekable & 2) enigma2'nin hiz basamagi korunur.

    @staticmethod
    def _sarma_adimi():
        try:
            return int(cfg.sarma_adim.value)
        except Exception:  # noqa: BLE001
            return 60

    def _hizli_sarma_var(self):
        try:
            seek = self.getSeek()
            return bool(seek and (seek.isCurrentlySeekable() & 2))
        except Exception:  # noqa: BLE001
            return False

    def seekFwd(self):
        if self._hizli_sarma_var():
            return InfoBarSeek.seekFwd(self)
        self.biriktir(self._sarma_adimi())

    def seekBack(self):
        if self._hizli_sarma_var():
            return InfoBarSeek.seekBack(self)
        self.biriktir(-self._sarma_adimi())

    # --- biriktirmeli sarma (Kodi/AJPanel modeli) ---
    # HTTP akisinda her goreli sarma sunucuyla yeniden baglanti ister; arka
    # arkaya basilan tuslar birbirini eziyor, konum ilerlemiyordu (olculdu:
    # seekdef:6 x4 -> yalnizca Flush). Tuslar hedefi biriktirir, kutu
    # gosterilir, 1,2 sn sessizlikte ya da OK'te TEK mutlak seekTo yapilir.

    def biriktir(self, sn):
        konum, sure = self._konum()
        if konum is None:
            return
        if self.sarma_hedefi is None:
            self.sarma_hedefi = konum
        self.sarma_hedefi = max(0, self.sarma_hedefi + sn)
        if sure:
            self.sarma_hedefi = min(self.sarma_hedefi, max(0, sure - 5))
        fark = self.sarma_hedefi - konum
        self.sarma_kutusu.guncelle(fark, self.sarma_hedefi, sure)
        self.sarma_kutusu.show()
        try:
            bekleme = int(cfg.sarma_bekleme.value)
        except Exception:  # noqa: BLE001
            bekleme = 1200
        self.sarma_zamanlayici.stop()
        if bekleme > 0:
            self.sarma_zamanlayici.start(bekleme, True)   # 0: yalnizca OK ile uygulanir

    def sarmayi_uygula(self):
        self.sarma_zamanlayici.stop()
        hedef = self.sarma_hedefi
        self.sarma_hedefi = None
        self._sarma_kutusunu_gizle()
        if hedef is None:
            return
        try:
            self.doSeek(hedef * PTS_SN)      # mutlak: seekTo
            self.son_konum = hedef
            self["gecen"].setText(_b(_sure(hedef)))
        except Exception as e:  # noqa: BLE001
            gunluk("sarma uygulanamadi: %s" % e)

    def sarma_iptal(self):
        self.sarma_zamanlayici.stop()
        self.sarma_hedefi = None
        self._sarma_kutusunu_gizle()

    def ok(self):
        if self.sarma_hedefi is not None:
            self.sarmayi_uygula()
        else:
            self.toggleShow()

    def _sarma_kutusunu_gizle(self):
        try:
            self.sarma_kutusu.hide()
        except Exception:  # noqa: BLE001
            pass

    # --- atlama bilgisi (manuel sarma / bastan) ---
    def doSeekRelative(self, pts):
        sn = int(pts) // PTS_SN
        self._atlama_goster((u"+%d sn" if sn >= 0 else u"%d sn") % sn if abs(sn) < 60 else
                            (u"+%d dk" if sn >= 0 else u"%d dk") % (sn // 60 if sn >= 0 else -((-sn) // 60)))
        return InfoBarSeek.doSeekRelative(self, pts)

    # --- hata ayiklama satiri (TXT) ---
    def hata_ayiklama_degistir(self):
        if not cfg.hata_ayiklama.value:
            self._atlama_goster(_("Hata ayıklama satırı ayarlardan kapalı"))
            return
        self.debug_acik = not self.debug_acik
        if self.debug_acik:
            self._vdec_onceki = None
            self._hata_ayiklama_guncelle()
            self.debug_kutusu.show()
        else:
            self.debug_kutusu.hide()

    def _hata_ayiklama_guncelle(self):
        """Saniyede bir (tik): cozunurluk · cozucu · kare/s · dusen/hata · tampon · A/V · bit hizi · RSS · is."""
        try:
            v = _vdec_durumu()
            simdi = time.time()
            kps = u""
            if "kare" in v:
                onceki = self._vdec_onceki
                if onceki and simdi > onceki[1] and v["kare"] >= onceki[0]:
                    kps = u"%.1f k/s" % ((v["kare"] - onceki[0]) / (simdi - onceki[1]))
                self._vdec_onceki = (v["kare"], simdi)
            parcalar = []
            if v:
                parcalar.append(u"%sx%s %s %sfps" % (v.get("w", "?"), v.get("h", "?"), v.get("ad", "?"), v.get("fps", "?")))
                if kps:
                    parcalar.append(_u(_("çözülen")) + u" " + kps)
                parcalar.append(_u(_("düşen")) + u" %s " % v.get("dusen", "?") + _u(_("hata")) + u" %s" % v.get("hata", "?"))
            else:
                parcalar.append(_u(_("vdec yok")))
            yuzde = _vbuf_yuzde()
            if yuzde is not None:
                parcalar.append(_u(_("tampon")) + u" %%%d" % yuzde)
            fark = _av_fark_ms()
            if fark is not None:
                parcalar.append(u"A/V %+d ms" % fark)
            if self.dosya_bilgisi:
                parcalar.append(_u(self.dosya_bilgisi))
            rss = _rss_mb()
            parcalar.append(u"RSS %s MB · %s %s" % (rss if rss is not None else u"?", _is_parcacigi(), _u(_("iş"))))
            self.debug_kutusu.guncelle(u"  \u00b7  ".join(parcalar))
        except Exception as e:  # noqa: BLE001
            self.debug_kutusu.guncelle(u"debug: %s" % _u(u"%s" % e))

    def _atlama_goster(self, metin):
        self["atlama"].setText(_b(metin))
        self.doShow()
        self.atlama_zamanlayici.start(2000, True)

    def _atlama_sil(self):
        self["atlama"].setText("")

    # --- harici altyazi (SubtitleStyle) ---
    def doSeek(self, pts):
        """Her mutlak sarma (kaldigi yer, biriktirmeli, bastan) buradan: altyazi ornegi silinir."""
        if getattr(self, "srt", None):
            self.srt.sifirla()
        return InfoBarSeek.doSeek(self, pts)

    def _srt_durum(self):
        """SrtCizici icin: (duraklatildi, cubuk_acik) -- boru hattina sorgu yok."""
        return (self.seekstate == self.SEEK_STATE_PAUSE,
                getattr(self, "_InfoBarShowHide__state", None) == self.STATE_SHOWN)

    def altyazi_gorunumu(self):
        """SubtitleStyle'in canli onizlemeli ekrani; kendi altyazimiz o sirada gizlenir."""
        try:
            from Plugins.SystemPlugins.SubtitleStyle.ekran import AltyaziStiliAyarlari
        except ImportError:
            self._atlama_goster(_("Altyazı stili eklentisi kurulu değil"))
            return
        if self.srt:
            self.srt.gizle()
        self.session.openWithCallback(self._gorunum_kapandi, AltyaziStiliAyarlari)

    def _gorunum_kapandi(self, *a):
        if getattr(self, "kapaniyor", True):
            return
        if self.srt:
            self.srt.goster()

    def altyazi_degistir(self):
        """Mavi: harici altyazi varsa ac/kapat; yoksa enigma2'nin altyazi secimi (gomulu izler)."""
        if not self.srt:
            return self.altyazi_sec()
        self._atlama_goster(_("Altyazı: açık") if self.srt.degistir() else _("Altyazı: kapalı"))

    def ayrinti(self):
        self.servis_bilgisi()

    # --- Menu: secenekler ---
    def menu(self):
        from .ekranlar import Secenekler
        liste = [(_("Servis bilgisi"), "servis", _("Info")), (_("Ses"), "ses", _("Sarı")),
                 (_("Altyazı"), "altyazi", _("Mavi")), (_("Altyazı görünümü"), "gorunum", u""),
                 (_("Yeniden bağlan"), "yeniden", _("Yeşil")), (_("Baştan başla"), "bastan", _("Kırmızı"))]
        liste.append((_("Durdur"), "durdur", _("Stop")))
        self.session.openWithCallback(self._menu, Secenekler, _("Oynatıcı"), liste)

    def _menu(self, a):
        if a == "servis":
            self.servis_bilgisi()
        elif a == "ayrinti":
            self.ayrinti()
        elif a == "ses":
            self.ses_sec()
        elif a == "altyazi":
            self.altyazi_degistir()
        elif a == "gorunum":
            self.altyazi_gorunumu()
        elif a == "yeniden":
            self.yeniden_baglan()
        elif a == "bastan":
            self.bastan()
        elif a == "siradaki":
            self._kapat("siradaki")
        elif a == "durdur":
            self.durdur()

    def servis_bilgisi(self):
        from .ekranlar import ServisBilgisi
        o = self.oge or {}
        satirlar = [(_("Başlık"), self.baslik), (_("Dosya"), o.get("name") or u"-"), (_("Drive kimliği"), o.get("id") or u"-"),
                    (_("Tür"), o.get("mimeType") or u"-"), (_("Değiştirilme"), (o.get("modifiedTime") or u"-")[:16].replace(u"T", u" ")),
                    (_("Altyazı dosyası"), self.altyazi or _("yok"))]
        satirlar.append((_("Adres"), self.adres))
        konum, sure = self._konum()
        satirlar.append((_("Konum"), u"%s / %s" % (_sure(konum or 0), _sure(sure or 0))))
        satirlar.append((_("Video"), self.video_bilgisi or "-"))
        satirlar.append((_("Boyut · ortalama bit hızı"), self.dosya_bilgisi or _("hesaplanıyor...")))
        try:
            servis = self.session.nav.getCurrentService()
            info = servis and servis.info()
            if info:
                satirlar.append((_("Servis referansı"), info.getInfoString(iServiceInformation.sServiceref)))
            izler = servis and servis.audioTracks()
            n = izler.getNumberOfTracks() if izler else 0
            sec = izler.getCurrentTrack() if izler else -1
            for i in range(n):
                t = izler.getTrackInfo(i)
                satirlar.append((_("Ses %d%s") % (i + 1, u" *" if i == sec else u""), u"%s  %s" % (_u(t.getDescription()), _u(t.getLanguage()))))
        except Exception as e:  # noqa: BLE001
            satirlar.append((_("Ses izleri"), u"okunamadı: %s" % e))
        ekran = self.session.open(ServisBilgisi, self.baslik, satirlar)
        if not self.dosya_bilgisi:
            # henuz gelmediyse bir kez daha dene ve satiri guncelle
            from . import arka

            def bekle():
                import time as _t
                for _i in range(20):
                    if self.dosya_bilgisi:
                        return self.dosya_bilgisi
                    _t.sleep(0.3)
                return u""

            def geldi(metin):
                try:
                    ekran.satir_guncelle(_("Boyut · ortalama bit hızı"), metin or _("bilinmiyor (sunucu boyut vermiyor)"))
                except Exception:  # noqa: BLE001
                    pass
            arka.gonder(bekle, (), geldi, lambda h: None)

    # --- renkli tuslar ---
    def bastan(self):
        try:
            self.doSeek(0)
            self.setSeekState(self.SEEK_STATE_PLAY)
            self._atlama_goster(_("Baştan"))
        except Exception as e:  # noqa: BLE001
            gunluk("bastan sarma: %s" % e)

    def yeniden_baglan(self):
        """Yesil: ayni vekil adresi ayni konumdan yeniden acilir (vekil belirteci kendisi yeniler).
        Yayin donduysa ya da EOF ile acilamadiysa toparlar."""
        self.durak_zamanlayici.stop()
        simdi = time.time()
        if simdi - getattr(self, "_son_yeniden", 0) < 3:
            return
        self._son_yeniden = simdi
        # 0.96: boru hattina ek sorgu yok -- son_konum tik'ten (1 s) zaten guncel
        gunluk("yeniden baglan: baslangic, son_konum=%d" % self.son_konum)
        self.baslangic_sn = max(0, self.son_konum - 2) if self.son_konum > 30 else 0
        self._sarmayi_sifirla()
        self._atlama_goster(_("Yeniden bağlanıyor"))
        gunluk("yeniden baglan: gosterildi, adres isteniyor")
        self._yeniden_ac()

    def _baglanti_uyar(self, neden):
        """Akis sunucusuna baglanilamadi (boyut sorgusu) ve oynatma baslamadiysa cubukta goster;
        GStreamer'in kendi zaman asimi daha uzun, kullanici bos ekrana bakmasin."""
        if getattr(self, "kapaniyor", True) or self.acilamadi or getattr(self, "konum_goruldu", False) or self.son_sure > 0 or not neden:
            return
        self.baglanti_uyarisi = True
        self._durum(_b(u"%s  \u00b7  %s" % (_u(_("sunucu yanıt vermiyor")), _u(neden))))
        self.doShow()

    def _eof_kodunu_al(self):
        """Sunucunun HTTP durum kodu cubukta ('EOF · 460'): ayni adrese tek Range istegi (STB ajani).
        GStreamer 'Could not open resource' derken kodu disari vermiyor (gst gunlugunde var)."""
        from . import arka
        adres = self.adres

        def geldi(kod, neden):
            if getattr(self, "kapaniyor", True) or not self.acilamadi or self.adres != adres:
                return
            if kod and kod >= 400:
                self._durum(_b(u"EOF  \u00b7  %d" % kod))
            elif neden:
                self._durum(_b(u"EOF  \u00b7  %s" % _u(neden)))

        def kos():
            kod = None
            neden = ""
            try:
                import requests
                r = requests.get(adres, headers={"Range": "bytes=0-0"},
                                 timeout=10, stream=True, allow_redirects=False)
                kod = r.status_code
                r.close()
            except Exception as e:  # noqa: BLE001
                gunluk("EOF kodu alinamadi: %s" % e)
                neden = _baglanti_nedeni(e)
            gunluk("EOF sonrasi HTTP %s %s" % (kod, neden))
            arka._ana_donguye(geldi, kod, neden)
        import threading
        t = threading.Thread(target=kos, name="gdrive_eofkod")
        t.daemon = True
        t.start()

    def _yeniden_ac(self):
        """adres_al varsa yeni adres (yeni belirtec) kendi is parcaciginda alinir, sonra servis acilir."""
        if not self.adres_al:
            self.session.nav.playService(servis_ref(self.adres, self.baslik, self.altyazi))
            return
        from . import arka

        def geldi(yeni):
            if getattr(self, "kapaniyor", True):
                return
            gunluk("yeniden baglan: adres geldi (%s), servis aciliyor" % ("yeni" if (yeni and yeni != self.adres) else "ayni/eski"))
            if yeni:
                if yeni != self.adres:
                    gunluk("yeni oynatma adresi alindi (belirtec yenilendi)")
                self.adres = yeni
                self.dosya_boyutu = 0
                self.dosya_bilgisi = u""
                self._dosya_boyutunu_al()        # 0.95: yeni adres icin boyut/bit hizi yeniden
            else:
                gunluk("yeni adres alinamadi; eski adresle deneniyor")
            self.session.nav.playService(servis_ref(self.adres, self.baslik, self.altyazi))
            gunluk("yeniden baglan: playService dondu")

        def hata(m):
            gunluk("yeni adres: %s" % m)
            geldi(None)

        def al():
            gunluk("yeniden baglan: adres alma basladi (oynatma kuyrugu)")
            return self.adres_al()
        arka.gonder_oynatma(al, (), geldi, hata)     # 0.95: ayri thread yerine oynatma kuyrugu

    def ses_sec(self):
        try:
            self.audioSelection()
        except Exception as e:  # noqa: BLE001
            gunluk("ses secimi: %s" % e)

    def altyazi_sec(self):
        try:
            from Screens.AudioSelection import SubtitleSelection
            self.session.open(SubtitleSelection, self)
        except Exception as e:  # noqa: BLE001
            gunluk("altyazi secimi: %s" % e)

    # --- bitis / cikis ---
    def servis_bitti(self):
        if self.kapaniyor:
            return
        konum, sure = self._konum()
        if konum is not None:
            self.son_konum = konum
        if sure:
            self.son_sure = sure
        erken = self.son_sure > 0 and self.son_konum < self.son_sure * 97 // 100
        if (self.son_sure <= 0 and self.son_konum < 30) or not getattr(self, "konum_goruldu", False):
            # kaldigi yerden acilista son_konum baslangic_sn ile baslar (0.83): akis hic baslamadiysa
            # (gecerli konum gorulmedi) bu da 'yayin acilamadi'dir, 'bitti' degil
            # sure ogrenilemeden ilk saniyelerde EOF: yayin acilamadi (sunucuda dosya yok ya da
            # belirtec gecersiz). Oynatici ACIK kalir, cubukta 'EOF'; devam Yesil ile elle (0.46).
            # 'bitti' sayilmaz, kayit yazilmaz.
            self.eof_sayac += 1
            self.acilamadi = True
            gunluk("EOF %d. sn, sure bilinmiyor: yayin acilamadi (%d. kez)" % (self.son_konum, self.eof_sayac))
            self._durum(_b(u"EOF"))
            self._eof_kodunu_al()
            self.doShow()
            # otomatik deneme yok (kullanici istegi, 0.46): devami Yesil ile elle
            try:
                self.hideTimer.stop()
            except Exception:  # noqa: BLE001
                pass
            return
        if erken and cfg.yeniden_ac.value and self.yeniden_deneme < 3:
            self.yeniden_deneme += 1
            gunluk("oynatma erken bitti (%d/%d sn), %d. kez yeniden aciliyor" % (self.son_konum, self.son_sure, self.yeniden_deneme))
            self.baslangic_sn = max(0, self.son_konum - 2)
            self._sarmayi_sifirla()
            self._yeniden_ac()
            return
        self._kapat("bitti" if not erken else "hata")

    def durdur(self):
        self._kapat("cikti")

    def arkada_birak(self):
        """Exit: ekran kapanir, oynatma SURER (kullanici listede gezinir).
        Liste ekranlari bunu arkadaki_oynatma() ile gorur; Stop ya da baska bir
        icerik acilinca bitirilir."""
        if self.kapaniyor:
            return
        if self.acilamadi:
            # EOF (yayin acilamadi): akis yok, arkada birakacak bir sey yok -> sessiz kapanis
            gunluk("EOF durumunda Exit: arkada birakilmadi")
            self._kapat("cikti")
            return
        self.kapaniyor = True
        self.konum_zamanlayici.stop()
        self.atlama_zamanlayici.stop()
        self.sarma_zamanlayici.stop()
        konum, sure = self._konum()
        if konum is not None and self.sarildi:     # sarma yapilmadan cikildiysa (0 sn) kaldigi yer ezilmesin
            self.son_konum = konum
        if sure:
            self.son_sure = sure
        if self.kaydet:
            try:
                self.kaydet(self.son_konum, self.son_sure, False)
            except Exception as e:  # noqa: BLE001
                gunluk("arkada birakirken kayit: %s" % e)
        # PlayerBase.__unRegisterPlayer kapaniste lastservice'i (TV) yeniden acar
        # (olculdu: Exit -> 'playing 1:0:1:...'); arkada birakirken bu kanca cikarilir,
        # oyuncu kaydi elle geri alinir.
        # Not: cift alt cizgili yontemin __name__'i sinif onekini ALMAZ
        # ("__unRegisterPlayer"); "_PlayerBase__unRegisterPlayer" ile karsilastirma
        # hic eslesmiyordu (olculdu 0.13: Exit yine TV'ye dustu).
        cikan = _tv_kancasini_cikar(self)
        gunluk("arkada birakiliyor: %s @ %d sn (PlayerBase kancasi cikarildi: %d)" % (self.baslik, self.son_konum, cikan))
        try:
            self.session.current_player = getattr(self, "prev_player", None)
        except Exception:  # noqa: BLE001
            pass
        a = ArkadakiOynatma(self.adres, self.baslik, self.kaydet, self.son_konum, self.anahtar, self.lastservice, self.oge)
        a.sure_sn = self.son_sure
        a.video_bilgisi = self.video_bilgisi
        a.dosya_boyutu = self.dosya_boyutu
        a.adres_al = self.adres_al
        a.altyazi = self.altyazi
        _arkadaki[0] = a
        _infobar_kancasi_kur(self.session)
        self.close("arkada", self.son_konum, self.son_sure)

    def _kapat(self, sonuc):
        if self.kapaniyor:
            return
        self.kapaniyor = True
        try:
            ls = self.lastservice
            if ls and (ls.type >= 4097 or (ls.getPath() or "").startswith("http")):
                # TV'ye donus kancasi ayni akisi hemen yeniden acardi (stop->play ortusmesi, SIGSEGV 23:49)
                _tv_kancasini_cikar(self)
                gunluk("kapanis: lastservice akis, TV'ye donus kancasi cikarildi")
        except Exception:  # noqa: BLE001
            pass
        _arkadaki[0] = None
        self.konum_zamanlayici.stop()
        self.atlama_zamanlayici.stop()
        self.sarma_zamanlayici.stop()
        konum, sure = self._konum()
        if konum is not None and self.sarildi:     # sarma yapilmadan cikildiysa (0 sn) kaldigi yer ezilmesin
            self.son_konum = konum
        if sure:
            self.son_sure = sure
        if self.kaydet and not (self.son_sure <= 0 and self.son_konum < 30):
            try:
                self.kaydet(self.son_konum, self.son_sure, sonuc == "bitti")
            except Exception as e:  # noqa: BLE001
                gunluk("son konum kaydi hatasi: %s" % e)
        self.gecis_zamanlayici.stop()
        try:
            self.session.nav.stopService()
            _durduruldu()
        except Exception:  # noqa: BLE001
            pass
        self.close(sonuc, self.son_konum, self.son_sure)


class ArkadakiOynatma(object):
    """Exit ile arkada birakilan oynatma: adres, baslik, kaydet ve son konum;
    arkada oynarken de 10 sn'de bir konum kaydi."""

    def __init__(self, adres, baslik, kaydet, konum_sn, anahtar=None, son_servis=None, oge=None):
        self.adres, self.baslik, self.kaydet, self.konum_sn = adres, baslik, kaydet, konum_sn
        self.anahtar = anahtar
        self.oge = oge
        self.son_servis = son_servis      # arkadan once oynayan TV kanali
        self.sure_sn = 0
        self.video_bilgisi = ""
        self.duran_tik = 0                # konum ilerlemeyen ardisik tik sayisi (3 = bitti/koptu)
        self.zamanlayici, self.baglanti = arka.zamanlayici(self.tik)
        self.zamanlayici.start(10000, False)

    def tik(self):
        try:
            import NavigationInstance
            nav = NavigationInstance.instance
            ref = nav and nav.getCurrentlyPlayingServiceReference()
            if not ref or not self._bizim_mi(ref):
                self._bitti(nav, "oynayan servis degisti")
                return
            servis = nav.getCurrentService()
            seek = servis and servis.seek()
            if not seek:
                return
            k = seek.getPlayPosition()
            s = seek.getLength()
            if k and not k[0]:
                konum = k[1] // PTS_SN
                self.duran_tik = 0 if konum != self.konum_sn else self.duran_tik + 1
                self.konum_sn = konum
                sure = s[1] // PTS_SN if (s and not s[0]) else 0
                self.sure_sn = sure or self.sure_sn
                if self.duran_tik >= 3:
                    # 30 s'dir ilerlemiyor: akis bitti ya da koptu (arkada duraklatma yok)
                    self._bitti(nav, "konum %d sn'de durdu" % konum)
                    return
                if self.kaydet:
                    self.kaydet(self.konum_sn, self.sure_sn, False)
        except Exception as e:  # noqa: BLE001
            gunluk("arkadaki konum kaydi: %s" % e)

    def _bizim_mi(self, ref):
        """Oynayan servis bizim akis mi? servis_ref yolu quote()'ludur ve '#User-Agent=' eki alabilir."""
        try:
            yol = ref.getPath() or ""
        except Exception:  # noqa: BLE001
            return False
        return yol == self.adres or yol.startswith(quote(self.adres, safe=":/?&=%+,"))

    def _bitti(self, nav, neden):
        """Arkadaki akis artik yok: kaydi dusur, servisi kapat, TV'ye don (ipucu yalan soylemesin)."""
        gunluk("arkadaki oynatma bitti (%s): %s" % (neden, self.baslik))
        self.zamanlayici.stop()
        if _arkadaki[0] is self:
            _arkadaki[0] = None
        try:
            ref = nav and nav.getCurrentlyPlayingServiceReference()
            if ref and self._bizim_mi(ref):
                nav.stopService()
                _durduruldu()
                if self.son_servis:
                    nav.playService(self.son_servis)
        except Exception as e:  # noqa: BLE001
            gunluk("arkadaki kapatma: %s" % e)

    def durdur(self, session, tv_ye_don=True):
        self.zamanlayici.stop()
        try:
            session.nav.stopService()
            _durduruldu()
            if tv_ye_don and self.son_servis:
                session.nav.playService(self.son_servis)
        except Exception as e:  # noqa: BLE001
            gunluk("arkadaki durdurma: %s" % e)


_arkadaki = [None]
_acik_oynatici = [None]     # acik DriveOynatici (bekleme kipinde kapatmak icin)


def _bekleme_kipi(deger=None):
    """enigma2 bekleme kipine girince (config.misc.standbyCounter) GDrive akisini durdur: bekleme
    kipinde video cikisi kapali, oynatici en ustte degilse boru hatti calismaya devam eder, video
    kuyrugu tikanir, bellek ~28 MB/dk sisip bekci enigma2'yi oldurur (olculdu 2026-10-07 04:09-04:37)."""
    o = _acik_oynatici[0]
    if o is not None and not getattr(o, "kapaniyor", True):
        gunluk("bekleme kipi: oynatici kapatiliyor @ %d sn" % o.son_konum)
        _tv_kancasini_cikar(o)                  # bekleme kipinde TV acilmasin
        try:
            o._kapat("cikti")
        except Exception as e:  # noqa: BLE001
            gunluk("bekleme kipi kapatma: %s" % e)
    a = _arkadaki[0]
    if a is not None:
        gunluk("bekleme kipi: arkadaki oynatma durduruluyor (%s)" % a.baslik)
        _arkadaki[0] = None
        a.zamanlayici.stop()
        try:
            import NavigationInstance
            NavigationInstance.instance.stopService()
            _durduruldu()
        except Exception as e:  # noqa: BLE001
            gunluk("bekleme kipi arkadaki: %s" % e)


try:
    config.misc.standbyCounter.addNotifier(_bekleme_kipi, initial_call=False)
except Exception as _e:  # noqa: BLE001
    print("[GDrive] standbyCounter bildirimi kurulamadi: %s" % _e)
def _infobar_kancasi_kur(session):
    """enigma2'nin ana InfoBar'ina (TV) bir kez tus haritasi ekler: GDrive akisi
    arkada oynarken OK/Info -> oynaticiya don, Stop -> akisi bitir. Arkada oynatma
    yokken isleyiciler 0 dondurur (tus InfoBar'a gecer). Bilesen InfoBar'in
    onExecBegin'inde eklenir: execBegin bilesenleri o callback'lerden SONRA baslatir."""
    try:
        from Screens.InfoBar import InfoBar
        from Components.ActionMap import ActionMap
    except ImportError:
        return
    ib = InfoBar.instance
    if ib is None or getattr(ib, "_gd_kanca", False):
        return
    ib._gd_kanca = True

    def ac():
        if not _arkadaki[0]:
            return 0
        arkadakine_don(ib.session)
        return 1

    def durdur():
        if not _arkadaki[0]:
            return 0
        arkadakini_durdur(ib.session)
        return 1

    def kur():
        if "gd_arka" in ib:
            return
        ib["gd_arka"] = ActionMap(["OkCancelActions", "InfobarShowHideActions", "MoviePlayerActions", "InfobarActions"],
                                   {"ok": ac, "toggleShow": ac, "showMovies": ac, "leavePlayer": durdur}, -10)
    ib.onExecBegin.append(kur)
    kur()                     # execing degilse bir sonraki execBegin'de kendiliginden baslar
    if ib.execing:
        try:
            ib["gd_arka"].execBegin()
            ib.active_components.append(ib["gd_arka"])
        except Exception as e:  # noqa: BLE001
            gunluk("infobar kancasi: %s" % e)


def arkadaki_oynatma():
    """Arkada suren GDrive oynatmasi (ArkadakiOynatma) ya da None."""
    return _arkadaki[0]


def arkadakini_durdur(session, tv_ye_don=True):
    a = _arkadaki[0]
    _arkadaki[0] = None
    if a:
        a.durdur(session, tv_ye_don)


def arkadakine_don(session, geri=None):
    """Arkada suren oynatmanin ekranini yeniden acar (servis yeniden ACILMAZ)."""
    a = _arkadaki[0]
    if not a:
        return False
    _arkadaki[0] = None
    a.zamanlayici.stop()
    if geri:
        session.openWithCallback(geri, DriveOynatici, a.adres, a.baslik, a.kaydet, 0, True, a.anahtar, a.son_servis, a, a.oge, adres_al=getattr(a, "adres_al", None), altyazi=getattr(a, "altyazi", None))
    else:
        session.open(DriveOynatici, a.adres, a.baslik, a.kaydet, 0, True, a.anahtar, a.son_servis, a, a.oge, adres_al=getattr(a, "adres_al", None), altyazi=getattr(a, "altyazi", None))
    return True


def oynat(session, adres, baslik, kaydet=None, baslangic_sn=0, geri=None, anahtar=None, oge=None, adres_al=None, altyazi=None):
    """Oynaticiyi acar; kapaninca geri(sonuc, konum_sn, sure_sn). Arkada baska bir
    oynatma varsa once durdurulur."""
    a = _arkadaki[0]
    son_servis = a.son_servis if a else None
    arkadakini_durdur(session, tv_ye_don=False)   # yeni akis hemen basliyor; TV'ye donme
    if geri:
        session.openWithCallback(geri, DriveOynatici, adres, baslik, kaydet, baslangic_sn, False, anahtar, son_servis, None, oge, adres_al=adres_al, altyazi=altyazi)
    else:
        session.open(DriveOynatici, adres, baslik, kaydet, baslangic_sn, False, anahtar, son_servis, None, oge, adres_al=adres_al, altyazi=altyazi)
