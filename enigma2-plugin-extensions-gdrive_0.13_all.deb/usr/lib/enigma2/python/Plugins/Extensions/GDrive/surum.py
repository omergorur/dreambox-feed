# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_gdrive.py); depoda yok.
SURUM = "0.13"
COMMIT = "d1fc11f"
