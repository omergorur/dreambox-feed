# -*- coding: utf-8 -*-
"""
GDrive -- Google girisi icin kutudaki kucuk web formu.

Yalnizca giris ekrani aciksken calisir (http://<kutu>:8790/). Telefonda/PC'de:
  1. Cloud Console'daki istemci JSON'u (ya da kimlik + sir) yapistirilir.
  2. "Google ile giris" -> Google'in izin sayfasi (PKCE baglantisi burada uretilir).
  3. Google 127.0.0.1:8765'e yonlendirir; sayfa acilmaz, adres cubugundaki adres
     forma yapistirilir -> belirtec alinir, /etc/enigma2/gdrive.json'a yazilir.

Kendi is parcaciginda calisir. Ekrana yalnizca verilen durum(metin, bitti)
geri cagrisiyla haber verir; cagiran bunu ana donguye tasir (callFromThread).
Formun POST'lari kutunun kendisine gider, Drive'a degil (Drive salt okunur).
"""
from __future__ import print_function

import socket
import threading

try:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import parse_qs
except ImportError:  # Python 3
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import parse_qs

from .drive import DriveHatasi, hata_metni

PORT = 8790

_SAYFA = u"""<!doctype html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>GDrive giriş</title>
<style>body{font-family:sans-serif;background:#111419;color:#e8eaed;margin:0;padding:16px;max-width:640px}
h1{font-size:20px}h2{font-size:16px;margin-top:28px;color:#3aa0a8}textarea,input{width:100%%;box-sizing:border-box;
background:#1c2129;color:#e8eaed;border:1px solid #3a4250;border-radius:6px;padding:10px;font-size:14px}
button,a.btn{display:inline-block;margin-top:10px;background:#3aa0a8;color:#000;border:0;border-radius:6px;
padding:12px 18px;font-size:15px;text-decoration:none}.not{color:#9aa0a6;font-size:13px}
.msg{padding:10px;border-radius:6px;background:#243646;margin:12px 0}.hata{background:#5a2328}</style></head><body>
<h1>GDrive — Google Drive girişi</h1>%(mesaj)s
<p class="not">Eklenti Drive'a yalnızca <b>okuma</b> izniyle bağlanır (drive.readonly); dosya yazamaz, silemez, değiştiremez.</p>
<h2>1. OAuth istemcisi</h2><p class="not">%(istemci)s</p>
<form method="post" action="/istemci"><textarea name="json" rows="4"
placeholder="client_secret_....json dosyasının içeriği (ya da aşağıdaki iki alan)"></textarea>
<input name="client_id" placeholder="İstemci kimliği (....apps.googleusercontent.com)" style="margin-top:8px">
<input name="client_secret" placeholder="İstemci sırrı" style="margin-top:8px">
<button type="submit">Kaydet</button></form>
<h2>2. Google ile giriş</h2>%(git)s
<h2>3. Yönlendirme adresini yapıştır</h2>
<p class="not">Girişten sonra tarayıcı <b>127.0.0.1:8765</b> adresine gider ve “bağlanılamıyor” der. Bu normal:
adres çubuğundaki adresin tamamını kopyalayıp buraya yapıştırın.</p>
<form method="post" action="/kod"><textarea name="adres" rows="3" placeholder="http://127.0.0.1:8765/?code=..."></textarea>
<button type="submit">Girişi tamamla</button></form></body></html>"""


def _kac(s):
    return (s or u"").replace(u"&", u"&amp;").replace(u"<", u"&lt;").replace(u">", u"&gt;").replace(u'"', u"&quot;")


def _u(s):
    return s.decode("utf-8", "replace") if isinstance(s, bytes) else s


class _Sunucu(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _Isleyici(BaseHTTPRequestHandler):
    def log_message(self, bicim, *args):
        pass

    def _yaz(self, html, kod=200):
        veri = html.encode("utf-8")
        self.send_response(kod)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(veri)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(veri)

    def _sayfa(self, mesaj=u"", hata=False):
        d = self.server.form.drive
        if d.giris_var():
            istemci = u"Kayıtlı: %s<br>Giriş yapılmış: <b>%s</b>" % (_kac(d.kimlik["client_id"][:24]) + u"…", _kac(d.eposta()))
        elif d.istemci_var():
            istemci = u"Kayıtlı: %s" % (_kac(d.kimlik["client_id"][:24]) + u"…")
        else:
            istemci = u"Henüz kayıtlı değil."
        git = (u'<a class="btn" href="/git" target="_blank" rel="noopener">Google ile giriş yap</a>'
               if d.istemci_var() else u'<p class="not">Önce 1. adımı tamamlayın.</p>')
        if mesaj:
            mesaj = u'<div class="msg%s">%s</div>' % (u" hata" if hata else u"", _kac(mesaj))
        self._yaz(_SAYFA % {"mesaj": mesaj, "istemci": istemci, "git": git})

    def _form(self):
        n = int(self.headers.get("Content-Length") or 0)
        govde = self.rfile.read(min(n, 64 * 1024)) if n else b""
        q = parse_qs(_u(govde))
        return dict((k, _u(v[0]).strip()) for k, v in q.items())

    def do_GET(self):
        form = self.server.form
        if self.path == "/git":
            try:
                adres = form.drive.giris_adresi()
            except DriveHatasi as e:
                self._sayfa(hata_metni(e), hata=True)
                return
            form.durum(u"Telefonda Google girişi açıldı…", False)
            self.send_response(302)
            self.send_header("Location", adres)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if self.path not in ("/", "/index.html"):
            self.send_error(404)
            return
        form.durum(u"Form açıldı: %s" % self.client_address[0], False)
        self._sayfa()

    def do_POST(self):
        form, d = self.server.form, self.server.form.drive
        alanlar = self._form()
        try:
            if self.path == "/istemci":
                if alanlar.get("json"):
                    d.istemci_json(alanlar["json"])
                else:
                    d.istemci_ayarla(alanlar.get("client_id"), alanlar.get("client_secret"))
                form.durum(u"OAuth istemcisi kaydedildi", False)
                self._sayfa(u"İstemci kaydedildi. Şimdi 2. adım: Google ile giriş.")
            elif self.path == "/kod":
                form.durum(u"Belirteç alınıyor…", False)
                eposta = d.giris_tamamla(alanlar.get("adres"))
                form.durum(u"Giriş yapıldı: %s" % eposta, True)
                self._sayfa(u"Tamam! %s hesabına bağlanıldı. Bu sayfayı kapatabilirsiniz." % eposta)
            else:
                self.send_error(404)
        except DriveHatasi as e:
            form.durum(u"Hata: %s" % hata_metni(e), False)
            self._sayfa(hata_metni(e), hata=True)
        except Exception as e:  # noqa: BLE001 -- beklenmeyen: sayfada goster, yutma
            form.durum(u"Beklenmeyen hata: %s" % hata_metni(e), False)
            self._sayfa(u"Beklenmeyen hata: %s" % hata_metni(e), hata=True)


def yerel_ip():
    """Kutunun LAN adresi (yonlendirme tablosundan; paket gondermez)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except socket.error:
        return "127.0.0.1"
    finally:
        s.close()


class GirisFormu(object):
    def __init__(self, drive, durum, port=PORT):
        self.drive = drive
        self.durum = durum
        self.port = port
        self._sunucu = None

    def baslat(self):
        s = _Sunucu(("0.0.0.0", self.port), _Isleyici)
        s.form = self
        t = threading.Thread(target=s.serve_forever, name="gdrive_giris")
        t.daemon = True
        t.start()
        self._sunucu = s
        return "http://%s:%d/" % (yerel_ip(), self.port)

    def durdur(self):
        if self._sunucu:
            self._sunucu.shutdown()
            self._sunucu.server_close()
            self._sunucu = None
