# -*- coding: utf-8 -*-
"""
GDrive -- arka plan isleri (StalkerTV/arka.py'den).

Is parcacigi + kuyruk. Ag ve disk islemleri burada calisir; sonuc twisted
reactor.callFromThread ile ANA DONGUDE verilen geri cagriya iletilir. Ekrana,
zamanlayiciya ya da session'a is parcacigindan ASLA dokunulmaz.

    arka.gonder(fnc, (arg1, arg2), geri=self.sonuc, hata=self.hata)
"""
from __future__ import print_function

import threading
import time
import traceback

from .drive import hata_metni

try:
    import Queue as queue
except ImportError:
    import queue


def gunluk(m):
    """Unicode ya da bayt; py2'de utf-8 bayta cevrilip yazilir (enigma2 stdout ascii olabilir)."""
    if not isinstance(m, str):
        try:
            m = m.encode("utf-8") if str is bytes else m.decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            m = repr(m)
    print("[GDrive] " + m)


def zamanlayici(geri):
    """eTimer + geri cagri; (zamanlayici, baglanti). DreamOS'ta timeout.connect bir baglanti nesnesi
    dondurur ve bu nesne yasatilmalidir; eski API'de callback listesi."""
    from enigma import eTimer
    z = eTimer()
    try:
        b = z.timeout.connect(geri)
    except AttributeError:
        z.callback.append(geri)
        b = None
    return z, b


def _ana_donguye(fnc, *args):
    try:
        from twisted.internet import reactor
        reactor.callFromThread(fnc, *args)
    except Exception:  # noqa: BLE001 -- reactor yoksa (PC testi) dogrudan
        fnc(*args)


class _Is(object):
    __slots__ = ("fnc", "args", "geri", "hata", "iptal")

    def __init__(self, fnc, args, geri, hata):
        self.fnc, self.args, self.geri, self.hata = fnc, args, geri, hata
        self.iptal = False

    def iptal_et(self):
        self.iptal = True


class Isci(threading.Thread):
    def __init__(self, ad="gdrive_isci"):
        threading.Thread.__init__(self, name=ad)
        self.daemon = True
        self.kuyruk = queue.Queue()
        self.start()

    def run(self):
        while True:
            is_ = self.kuyruk.get()
            if is_ is None:
                return
            if is_.iptal:
                continue
            t0 = time.time()
            try:
                sonuc = is_.fnc(*is_.args)
            except Exception as e:  # noqa: BLE001
                gunluk(u"arka is hatasi: %s" % hata_metni(e))
                gunluk(traceback.format_exc())
                if is_.hata and not is_.iptal:
                    _ana_donguye(is_.hata, hata_metni(e))
                continue
            finally:
                dt = time.time() - t0
                if dt > 3:
                    gunluk("%s: %s %.1f s surdu (kuyrukta %d is)" % (self.name, getattr(is_.fnc, "__name__", "?"), dt, self.kuyruk.qsize()))
            if is_.geri and not is_.iptal:
                _ana_donguye(is_.geri, sonuc)


_isci = [None]
_oynatma_isci = [None]


def gonder(fnc, args=(), geri=None, hata=None):
    """Liste isleri. Iptal icin kullanilabilecek nesneyi dondurur."""
    if _isci[0] is None or not _isci[0].is_alive():
        _isci[0] = Isci()
    is_ = _Is(fnc, args, geri, hata)
    _isci[0].kuyruk.put(is_)
    return is_


def gonder_oynatma(fnc, args=(), geri=None, hata=None):
    """Oynatma hazirligi (altyazi bulma/indirme): AYRI kuyruk, liste sayfalarinin arkasinda beklemesin."""
    if _oynatma_isci[0] is None or not _oynatma_isci[0].is_alive():
        _oynatma_isci[0] = Isci("gdrive_oynatma")
    is_ = _Is(fnc, args, geri, hata)
    _oynatma_isci[0].kuyruk.put(is_)
    return is_
