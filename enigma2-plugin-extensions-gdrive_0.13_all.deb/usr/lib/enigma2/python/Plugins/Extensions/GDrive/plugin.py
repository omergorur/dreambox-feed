# -*- coding: utf-8 -*-
"""
GDrive -- Google Drive videolari (DreamOS). YALNIZCA OKUMA (drive.readonly).

Plan: _build/gdrive/PLAN.md. Katmanlar:
    drive.py     Drive API + OAuth (saf Python)   vekil.py     yerel oynatma vekili (GET/HEAD)
    giris.py     telefonla giris formu (8790)     veri.py      SQLite kaldigi yer / arama
    arka.py      arka plan isleri                ekranlar.py  ekranlar
    oynatici.py  oynatma (StalkerTV'den)          settings.py  ayarlar
"""
from __future__ import print_function

from Plugins.Plugin import PluginDescriptor

from .settings import cfg

try:
    _
except NameError:
    def _(txt):
        return txt


def ac(session, **kwargs):
    from .ekranlar import AnaMenu
    session.open(AnaMenu)


def ana_menu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(_("Google Drive"), ac, "gdrive", 47)]
    return []


def Plugins(**kwargs):
    aciklama = _("Google Drive videoları (yalnızca okuma)")
    girdiler = [
        PluginDescriptor(name=_("Google Drive"), description=aciklama,
                         where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png",
                         needsRestart=False, fnc=ac),
    ]
    if cfg.eklentiler_menu.value:
        girdiler.append(PluginDescriptor(name=_("Google Drive"), description=aciklama,
                                         where=PluginDescriptor.WHERE_EXTENSIONSMENU, needsRestart=False, fnc=ac))
    if cfg.ana_menu.value:
        girdiler.append(PluginDescriptor(name=_("Google Drive"), where=PluginDescriptor.WHERE_MENU,
                                         needsRestart=False, fnc=ana_menu))
    return girdiler
