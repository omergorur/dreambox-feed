# -*- coding: utf-8 -*-
# Kodi 21'i (kodi21-hwdec) enigma2 icinden baslatir. KodiHwdec (Kodi 19)
# eklentisinin kopyasidir; yalnizca baslatici ve adlar farkli.
#
# Kutunun kendi "Kodi MediaCenter" eklentisi (XBMCMediaCenter) yerinde kalir;
# bu ayri bir menu girisidir. Iskelet oradan alinmistir, farklari:
#
#   * /usr/bin/kodi21-hwdec calistirilir (stok /usr/bin/xbmc-start degil)
#   * ALSA HDMI aygiti KAPATILIR: enigma2 hw:0,0'i acik tutuyor ve Kodi'nin
#     hdmidmix (dmix) aygiti ona baglanamiyor -> Kodi'de ses cikmiyordu
#     ("CAESinkALSA - Unable to open device hdmidmix for playback").
#     Cikista ServiceStopScreen servisi geri baslattiginda enigma2 aygiti
#     yeniden aciyor.

from enigma import eConsoleAppContainer, fbClass, eRCInput

from Components.Language import language
from Components.Sources.StaticText import StaticText

from Screens.Screen import Screen
from Screens.ServiceStopScreen import ServiceStopScreen

from Tools.Directories import resolveFilename, SCOPE_PLUGINS

from skin import loadSkin

loadSkin(resolveFilename(SCOPE_PLUGINS, "Extensions/Kodi21Hwdec/skin.xml"))

LAUNCHER = "/usr/bin/kodi21-hwdec"


class Kodi21HwdecSummary(Screen):
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent=parent)
		self.skinName = ["Kodi21HwdecSummary"]


class Kodi21Hwdec(Screen, ServiceStopScreen):
	def __init__(self, session):
		Screen.__init__(self, session)
		ServiceStopScreen.__init__(self)
		self.skinName = ["Kodi21Hwdec"]
		self["title"] = StaticText("Kodi 21")
		self["lcdinfo"] = StaticText()
		self.__container = eConsoleAppContainer()
		self.__appClosed_conn = self.__container.appClosed.connect(self.__runFinished)
		self.stopService()
		self.__run()

	def __run(self):
		print "[Kodi21Hwdec] baslatiliyor"
		try:
			from enigma import eAlsaOutput
			eAlsaOutput.getInstance(eAlsaOutput.HDMI).close()
			print "[Kodi21Hwdec] ALSA HDMI kapatildi"
		except Exception, e:
			print "[Kodi21Hwdec] ALSA kapatilamadi:", e
		eRCInput.getInstance().lock()
		fbClass.getInstance().lock()
		com = "export LANG=" + language.getLanguage() + ".UTF-8;"
		com += LAUNCHER + ";"
		self.__container.execute(com)

	def __runFinished(self, retval):
		print "[Kodi21Hwdec] cikildi, kod =", retval
		fbClass.getInstance().unlock()
		eRCInput.getInstance().unlock()
		self.close()

	def createSummary(self):
		return Kodi21HwdecSummary
