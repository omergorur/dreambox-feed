# -*- coding: utf-8 -*-
#
# RadioVideo - ayar, durum ve dosya seçme ekranları
#
# Not: liste widget'larına (config, filelist) skin'de font/itemHeight
# VERİLMEZ -- DreamOS'ta eListbox'ta setFont yoktur, skin.py
# applySingleAttribute AttributeError fırlatır ve ekran yeşile döner.
#
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.FileList import FileList
from Components.config import getConfigListEntry, configfile

from enigma import getDesktop

import os

from .settings import cfg
from .player import player, scanPath, VIDEO_EXTENSIONS


def _hd():
    try:
        return getDesktop(0).size().width() >= 1920
    except Exception:
        return False


# --------------------------------------------------------------- dosya seçici

_MATCHING = "^.*\\.(%s)$" % "|".join(e.lstrip(".") for e in VIDEO_EXTENSIONS)


def _browserSkin():
    if _hd():
        return """
        <screen name="RadioVideoBrowser" position="center,center" size="1200,860" title="Video seç">
            <widget name="path" position="30,20" size="1140,40" font="Regular;26" />
            <widget name="filelist" position="30,70" size="1140,690" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="30,780" size="360,45" font="Regular;28" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="400,780" size="380,45" font="Regular;28" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="790,780" size="380,45" font="Regular;28" foregroundColor="yellow" halign="left" />
        </screen>"""
    return """
    <screen name="RadioVideoBrowser" position="center,center" size="800,560" title="Video seç">
        <widget name="path" position="20,15" size="760,28" font="Regular;20" />
        <widget name="filelist" position="20,50" size="760,430" scrollbarMode="showOnDemand" />
        <widget source="key_red" render="Label" position="20,500" size="240,30" font="Regular;20" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="270,500" size="250,30" font="Regular;20" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="530,500" size="250,30" font="Regular;20" foregroundColor="yellow" halign="left" />
    </screen>"""


class RadioVideoBrowser(Screen):
    """OK: klasöre gir / dosyayı seç.  Yeşil: içinde bulunulan klasörü seç."""

    def __init__(self, session, current):
        self.skin = _browserSkin()
        Screen.__init__(self, session)
        self.setTitle(_("Video seç"))

        start = current if current and os.path.isdir(current) \
            else os.path.dirname(current or "") or "/media"
        if not os.path.isdir(start):
            start = "/media"

        self["filelist"] = FileList(start, matchingPattern=_MATCHING,
                                    showMountpoints=True, showDirectories=True,
                                    showFiles=True)
        self["path"] = Label(start)
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Bu klasörü seç"))
        self["key_yellow"] = StaticText(_("Tüm dosyaları göster"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.ok,
                "cancel": self.cancel,
                "red": self.cancel,
                "green": self.selectDirectory,
                "yellow": self.toggleFilter,
            }, -1)

        self.filtered = True
        self.onLayoutFinish.append(self.updatePath)

    def updatePath(self):
        try:
            self["path"].setText(self["filelist"].getCurrentDirectory() or "")
        except Exception:
            pass

    def ok(self):
        filelist = self["filelist"]
        if filelist.canDescent():
            filelist.descent()
            self.updatePath()
        else:
            name = filelist.getFilename()
            if name and os.path.isfile(name):
                self.close(name)

    def selectDirectory(self):
        directory = self["filelist"].getCurrentDirectory()
        if directory:
            self.close(directory.rstrip("/") or "/")

    def toggleFilter(self):
        """Uzantısı listede olmayan videolar için filtreyi kaldırabilmek."""
        self.filtered = not self.filtered
        directory = self["filelist"].getCurrentDirectory() or "/media"
        self["filelist"].matchingPattern = _MATCHING if self.filtered else None
        self["filelist"].changeDir(directory)
        self["key_yellow"].setText(_("Tüm dosyaları göster") if self.filtered
                                   else _("Yalnızca videolar"))

    def cancel(self):
        self.close(None)


# ------------------------------------------------------------- ayar + durum

def _setupSkin():
    if _hd():
        return """
        <screen name="RadioVideoSetup" position="center,center" size="1400,900" title="Radyo Kanalında Video">
            <widget name="config" position="30,20" size="1340,340" scrollbarMode="showOnDemand" />
            <widget name="status" position="30,375" size="1340,435" font="Regular;24" />
            <widget source="key_red" render="Label" position="30,830" size="330,45" font="Regular;28" foregroundColor="red" halign="left" />
            <widget source="key_green" render="Label" position="370,830" size="330,45" font="Regular;28" foregroundColor="green" halign="left" />
            <widget source="key_yellow" render="Label" position="710,830" size="330,45" font="Regular;28" foregroundColor="yellow" halign="left" />
            <widget source="key_blue" render="Label" position="1040,830" size="330,45" font="Regular;28" foregroundColor="blue" halign="left" />
        </screen>"""
    return """
    <screen name="RadioVideoSetup" position="center,center" size="900,620" title="Radyo Kanalında Video">
        <widget name="config" position="20,15" size="860,230" scrollbarMode="showOnDemand" />
        <widget name="status" position="20,255" size="860,300" font="Regular;18" />
        <widget source="key_red" render="Label" position="20,570" size="210,30" font="Regular;20" foregroundColor="red" halign="left" />
        <widget source="key_green" render="Label" position="235,570" size="210,30" font="Regular;20" foregroundColor="green" halign="left" />
        <widget source="key_yellow" render="Label" position="450,570" size="210,30" font="Regular;20" foregroundColor="yellow" halign="left" />
        <widget source="key_blue" render="Label" position="665,570" size="210,30" font="Regular;20" foregroundColor="blue" halign="left" />
    </screen>"""


class RadioVideoSetup(Screen, ConfigListScreen):
    def __init__(self, session):
        self.skin = _setupSkin()
        Screen.__init__(self, session)
        self.setTitle(_("Radyo Kanalında Video"))

        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_yellow"] = StaticText(_("Video seç"))
        self["key_blue"] = StaticText(_("Şimdi başlat/durdur"))
        self["status"] = Label("")

        ConfigListScreen.__init__(self, self._entries(), session=session)

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "cancel": self.keyCancel,
                "save": self.keySave,
                "red": self.keyCancel,
                "green": self.keySave,
                "yellow": self.browse,
                "blue": self.toggleNow,
            }, -1)

        self.onLayoutFinish.append(self.updateStatus)

    def _entries(self):
        return [
            getConfigListEntry(_("Eklenti etkin"), cfg.enabled),
            getConfigListEntry(_("Hangi kanallarda"), cfg.trigger),
            getConfigListEntry(_("Video dosyası veya klasörü"), cfg.path),
            getConfigListEntry(_("Alt klasörleri de tara"), cfg.recursive),
            getConfigListEntry(_("Oynatma sırası"), cfg.order),
            getConfigListEntry(_("Video yokken ekran"), cfg.fallback),
            getConfigListEntry(_("Başlama gecikmesi"), cfg.start_delay),
            getConfigListEntry(_("TV'ye geçince kanalı tazele"), cfg.refresh_on_stop),
            getConfigListEntry(_("Standby'da durdur"), cfg.stop_in_standby),
            getConfigListEntry(_("Video çıkışı (sink)"), cfg.video_sink),
            getConfigListEntry(_("gstreamer yolu"), cfg.gst_binary),
            getConfigListEntry(_("LD_PRELOAD kancalarını temizle"), cfg.clear_preload),
            getConfigListEntry(_("Devralınan dosya tanıtıcılarını kapat"), cfg.close_fds),
            getConfigListEntry(_("Açılışta artık süreçleri temizle"), cfg.cleanup_on_start),
            getConfigListEntry(_("Günlüğe ayrıntı yaz"), cfg.debug),
        ]

    # ------------------------------------------------------------ eylemler

    def browse(self):
        self.session.openWithCallback(self.browsed, RadioVideoBrowser,
                                      cfg.path.value)

    def browsed(self, path):
        if path:
            cfg.path.value = path
            self["config"].setList(self._entries())
            player.playlist = []
            player.broken.clear()
            player.file_failures.clear()
            self.updateStatus()

    def toggleNow(self):
        enabled = player.toggle()
        self["status"].setText(
            (_("Elle başlatıldı.") if enabled else _("Elle durduruldu."))
            + "\n\n" + self._statusText())

    # -------------------------------------------------------------- durum

    def _statusText(self):
        st = player.status()
        lines = []
        lines.append("%-22s: %s" % (_("Eklenti"),
                                    _("etkin") if cfg.enabled.value else _("kapalı")))
        lines.append("%-22s: %s" % (_("Olay dinleme"),
                                    _("bağlı") if st["attached"] else _("bağlı değil")))
        lines.append("%-22s: %s" % (_("Zap olayları"),
                                    _("geliyor") if st["listening"]
                                    else _("GELMİYOR")))
        lines.append("%-22s: %s" % (_("Denetim zamanlayıcı"),
                                    _("açık") if st["watchdog"] else _("kapalı")))
        lines.append("%-22s: %s" % (_("Çalan servis"),
                                    _("radyo") if st["radio"] else _("radyo değil")))
        vpid = st["vpid"]
        lines.append("%-22s: %s" % (
            _("Kanalın video PID'i"),
            _("bilinmiyor") if vpid is None
            else (_("yok") if vpid <= 0 else "0x%04X" % vpid)))
        lines.append("%-22s: %s" % (_("Karar"), {
            "play": _("oynat"),
            "stop": _("durdur"),
            "wait": _("bekle (kararsız an)"),
        }.get(st["decision"], st["decision"])))
        lines.append("%-22s: %s" % (_("Oynatıcı"),
                                    _("çalışıyor") if st["running"] else _("duruyor")))
        if st["paused"]:
            lines.append("%-22s: %s" % (_("Durum"), _("elle durduruldu")))
        if st["file"]:
            lines.append("%-22s: %s" % (_("Şu an"), os.path.basename(st["file"])))

        path = cfg.path.value
        lines.append("")
        lines.append("%-22s: %s" % (_("Kaynak"), path))
        if os.path.isfile(path):
            lines.append("%-22s: %s" % (_("Tür"), _("tek dosya")))
        elif os.path.isdir(path):
            found = scanPath(path, cfg.recursive.value)
            lines.append("%-22s: %s" % (_("Tür"), _("klasör")))
            lines.append("%-22s: %d" % (_("Bulunan video"), len(found)))
            for name in found[:5]:
                lines.append("    " + os.path.basename(name))
            if len(found) > 5:
                lines.append("    ... (+%d)" % (len(found) - 5))
        else:
            lines.append("%-22s: %s" % (_("Tür"), _("BULUNAMADI")))

        if st["error"]:
            lines.append("")
            lines.append("%s: %s" % (_("Son hata"), st["error"]))
        if st["failures"]:
            lines.append("%s: %d" % (_("Başarısız deneme"), st["failures"]))

        lines.append("")
        lines.append(_("Ses radyo kanalından gelir; video sessiz oynatılır."))
        return "\n".join(lines)

    def updateStatus(self):
        self["status"].setText(self._statusText())

    # -------------------------------------------------------------- kayıt

    def keySave(self):
        self.saveAll()
        configfile.save()
        player.playlist = []
        player.broken.clear()
        player.file_failures.clear()
        player.attach()                  # kapalıyken açıldıysa izlemeyi kur
        player.applyRadioPic()           # "video yokken ekran" ayarını uygula
        player.evaluate(reset_failures=True)
        self.close()


def openSetup(session, **kwargs):
    # Eklenti kapalı başlatılmışsa ya da olay yolu kurulamamışsa burada kurulur
    player.attach()
    session.open(RadioVideoSetup)
