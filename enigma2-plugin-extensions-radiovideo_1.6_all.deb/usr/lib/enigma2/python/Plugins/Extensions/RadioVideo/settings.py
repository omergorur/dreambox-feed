# -*- coding: utf-8 -*-
#
# RadioVideo - ayarlar
#
from Components.config import (config, ConfigSubsection, ConfigYesNo,
                               ConfigSelection, ConfigText)

try:                      # enigma2 gettext'i "_" adını builtin olarak kurar;
    _                     # test/stub ortamında kurmamış olabilir
except NameError:
    def _(txt):
        return txt

config.plugins.radiovideo = ConfigSubsection()
cfg = config.plugins.radiovideo

# Paketle birlikte kurulan varsayılan video. Tek dosya seçiliyken bittiğinde
# başa sarılır (döngü).
DEFAULT_VIDEO = "/usr/share/enigma2/RadioVideo/radio.mp4"

# Eklenti tümüyle etkin mi
cfg.enabled = ConfigYesNo(default=True)

# Oynatılacak video: tek dosya ya da klasör
cfg.path = ConfigText(default=DEFAULT_VIDEO, fixed_size=False)

# Hangi kanallarda devreye girsin
#   radio_novideo : radyo kanalı VE kanalın kendi görüntüsü yok (varsayılan)
#                   -- Digitürk'ün video PID'i olan radyo kanallarında devreye
#                      girmez, onların kendi görüntüsü zaten var
#   novideo       : görüntü akışı olmayan her kanalda
#   radio         : servis tipi radyo olan her kanalda (video PID'ine bakmaz)
cfg.trigger = ConfigSelection(default="radio_novideo", choices=[
    ("radio_novideo", _("Görüntüsü olmayan radyo kanalları")),
    ("novideo", _("Görüntüsü olmayan her kanal")),
    ("radio", _("Tüm radyo kanalları")),
])

# Video oynatılmadığı anlarda (zap ile video başlayana kadar, ya da hiç
# oynatılamıyorsa) ekranda ne görünsün:
#   mvi   : enigma2'nin radyo görseli (config.misc.radiopic) -- stok davranış
#   black : düz siyah -- TV'nin local dimming'i devreye girer
# "black" seçilince eklenti config.misc.radiopic'i geçici olarak boşaltır ve
# kapanırken kullanıcının değerini geri koyar.
cfg.fallback = ConfigSelection(default="mvi", choices=[
    ("mvi", _("Radyo görseli")),
    ("black", _("Siyah ekran")),
])

# Klasör verildiyse alt klasörler de taransın mı
cfg.recursive = ConfigYesNo(default=True)

# Klasördeki dosyaların oynatma sırası
cfg.order = ConfigSelection(default="sequential", choices=[
    ("sequential", _("Sırayla")),
    ("random", _("Rastgele")),
    ("first", _("Hep ilk dosya")),
])

# Radyo kanalına geçtikten kaç ms sonra video başlasın.
# enigma2 zap sırasında radyo resmini (radio.mvi) decoder'a basar; hemen
# başlarsak onun altında kalırız.
cfg.start_delay = ConfigSelection(default="1500", choices=[
    ("500", "0,5 s"), ("1000", "1 s"), ("1500", "1,5 s"),
    ("2500", "2,5 s"), ("4000", "4 s"),
])

# Radyodan TV kanalına geçerken decoder devir teslimi bazen aksıyor: enigma2
# görüntüyü açamıyor, ekran siyah kalıyor (ses gelir). Oynatıcı kapandıktan
# sonra kanalı bir kez tazelemek bunu düzeltir.
cfg.refresh_on_stop = ConfigYesNo(default=True)

# Standby'da radyo çalmaya devam ederse videoyu da sürdürmek boşuna
# disk/CPU tüketir
cfg.stop_in_standby = ConfigYesNo(default=True)

# --- gelişmiş -------------------------------------------------------------

cfg.gst_binary = ConfigText(default="/usr/bin/gst-launch-1.0", fixed_size=False)

# Bu kutuda (Dreambox Two) doğrulanan sink. Başka bir kutuda dvbvideosink
# olabilir.
cfg.video_sink = ConfigText(default="dreamvideosink", fixed_size=False)

# enigma2 ortamındaki LD_PRELOAD kancalarını (libopen.so, libpagecache.so)
# oynatıcı sürecinden temizle. Kancalar çocuk süreçlere miras kalıyor ve
# decoder yazmalarını bozabiliyor:
# "write on file descriptor: Invalid argument".
cfg.clear_preload = ConfigYesNo(default=True)

# enigma2'nin açık tuttuğu dosya tanıtıcıları exec ile çocuk sürece geçiyor
# (/dev/ion, /dev/ge2d, /dev/mali0, /dev/fb*). Bunlar oynatıcıda kalınca
# HDR/10-bit dosyalarda decoder yazması EINVAL veriyor.
cfg.close_fds = ConfigYesNo(default=True)

# enigma2 çökmüşse arkada kalan kendi oynatıcımızı başlangıçta temizle
cfg.cleanup_on_start = ConfigYesNo(default=True)

cfg.debug = ConfigYesNo(default=False)
