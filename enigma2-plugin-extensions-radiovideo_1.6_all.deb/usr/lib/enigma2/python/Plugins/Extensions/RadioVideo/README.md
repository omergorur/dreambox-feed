# RadioVideo

Görüntüsü olmayan radyo kanallarında ekranda yalnızca sabit bir resim görünür
(temanın `radio.mvi` dosyası — `mytest.py:145`, `config.misc.radiopic`). Bu
eklenti o resmin yerine sabit diskteki bir videoyu oynatır. **Ses radyo
kanalından gelmeye devam eder.**

Digitürk'ün kendi görüntüsü (timelapse) olan radyo kanallarındaki davranışı,
görüntüsü olmayan tüm radyo kanallarına yaymak için yazıldı.

## Nasıl çalışıyor

Bu kutuda (Dreambox Two) tek video decoder var:

```
/dev/dvb/adapter0/video0        # video1 yok
```

`Components/SystemInfo.py:8` decoder sayısını bu dosyaları sayarak bulur ve
`Screens/InfoBarGenerics.py:1618` PiP'i yalnızca ikiden fazlası varsa açar.
Yani enigma2'nin ikinci servis yolu (`Screens/PictureInPicture.py:56`,
`setTarget(1)`) burada kullanılamaz.

Ama radyo çalarken video decoder boştadır. Eklenti bu boşluğu kullanır ve
videoyu enigma2'nin servis mekanizmasından bağımsız, ayrı bir gstreamer
süreciyle doğrudan decoder'a bastırır:

```sh
gst-launch-1.0 playbin name=radiovideo uri=file:///... \
               video-sink=dreamvideosink audio-sink=fakesink
```

`audio-sink=fakesink` kritik: video sesi hiçbir yere gitmez, ses yolu ana
servise (radyo kanalına) ait kalır.

## Hangi kanalda devreye girer

Ölçüt servis tipi değil, **kanalın kendi görüntüsünün olup olmadığıdır**
(`iServiceInformation.sVideoPID`). Böylece Digitürk'ün video PID'i olan radyo
kanallarına karışmaz — onların zaten kendi görüntüsü vardır.

Ayardaki üç kip:

| Kip | Devreye girdiği yer |
|---|---|
| `Görüntüsü olmayan radyo kanalları` (varsayılan) | radyo servisi **ve** video PID yok |
| `Görüntüsü olmayan her kanal` | video PID'i olmayan her servis |
| `Tüm radyo kanalları` | radyo servis tipi (video PID'ine bakmaz) |

Karar üç değerlidir: `play`, `stop` ve `wait`. **`wait`**, zap'in ortası
(servis referansı henüz geçersiz) ya da PMT gelmediği için video PID'inin
bilinmediği andır; bu durumda oynatıcıya dokunulmaz. Radyo kanalları arasında
gezerken videonun baştan başlamamasının sebebi budur — süreç hiç kesilmez.

## Davranış

| Olay | Yapılan |
|---|---|
| Görüntüsüz radyo kanalına zap | ayarlanan gecikmeden sonra video başlar |
| Radyodan radyoya zap | **hiçbir şey** — video kaldığı yerden sürer |
| Video biter | başa sarılır (klasör seçiliyse sıradaki dosya) |
| Görüntülü kanala zap (TV veya video PID'li radyo) | oynatıcı durdurulur, kanal bir kez tazelenir |
| Standby | durdurulur (ayardan kapatılabilir) |
| enigma2 kapanır | oynatıcı öldürülür — yoksa decoder'ı tutar |
| Zap olayları hiç gelmezse | 5 saniyelik denetim zamanlayıcısı devreye girer |
| Üst üste 3 hatalı deneme | pes edilir, günlüğe yazılır |

Zap sonrası gecikme (varsayılan 1,5 s) enigma2'nin radyo resmini decoder'a
basmasını bekler; hemen başlarsak o resmin altında kalırız.

## Döngüdeki siyah kare — bilinen sınır

Video bitip başa sararken kısa bir siyah kare görünür. Sebebi mimari: her
tekrar **yeni bir gst-launch süreci** demek, süreç ölünce decoder boşalıyor.

Kesintisiz döngü için gereken gstreamer parçaları bu imajda yok — denendi:

- `multifilesrc` (loop=true) — **kurulu değil**
- `mpegtsmux` (TS'ye çevirip döndürme) — **kurulu değil** (yalnızca
  `avmux_mpegts` var)
- `concat` — kurulu, ama zincir beslenmedi: ilk dosya bitince EOS geldi
- Süreci EOS yerine SIGKILL ile kesmek (son karenin donmasını ummak) — ekran
  yine siyaha düşüyor

Pratik çözüm: **uzun video kullanmak.** Tek uzun dosya seçilirse sonsuza dek
döner ve kesinti saatte bir olur. Birden fazla uzun videoyu bir klasöre koyup
*Oynatma sırası: Rastgele* seçmek de iyi çalışır.

## Decoder devir teslimi

Radyodan TV kanalına geçerken ilk denemede görüntü gelmeyip yalnızca sesin
duyulması mümkün: bizim gstreamer sürecimiz decoder'ı bir an fazla tutunca
enigma2 görüntüyü açamıyor (ses ayrı yoldan geldiği için duyuluyor). İki önlem
var:

1. Durdurma hızlandırıldı — SIGINT'ten sonra SIGKILL'e kadar bekleme 250 ms
2. Oynatıcı kapandıktan 700 ms sonra kanal bir kez tazeleniyor
   (`playService(ref, forceRestart=True)`) — elle kanal değiştirip geri
   dönmenin otomatiği

İkincisi *TV'ye geçince kanalı tazele* ayarıyla kapatılabilir. Tazeleme
yalnızca gerçekten bir oynatıcı kapatıldığında, görüntülü bir servise
geçildiyse ve standby'da değilken yapılır.

## Ayarlar

**Menü > Eklentiler > Radyo Kanalında Video**

- **Hangi kanallarda** — yukarıdaki üç kip
- **Video dosyası veya klasörü** — sarı tuşla dosya seçici açılır
- **Oynatma sırası** — sırayla / rastgele / hep ilk dosya. Rastgele kip tur
  bazlıdır: her video turda bir kez oynar, tur bitince sıra yeniden çekilir
  (aynı video üst üste gelmez).
- **Video yokken ekran** — `Radyo görseli` (stok davranış) veya `Siyah ekran`.
  Siyah seçilirse eklenti çalışırken `config.misc.radiopic` geçici olarak
  boşaltılır (kullanıcının değeri saklanır, eklenti kapanınca geri konur):
  zap sonrası ve video oynatılamadığında ekran düz siyah kalır, TV'nin local
  dimming'i devreye girer. Etkisi bir sonraki zap'te görünür.
- **Başlama gecikmesi** — video geç görünüyorsa azaltın, radyo resmi üste
  biniyorsa artırın
- **TV'ye geçince kanalı tazele** — yukarıdaki decoder devir teslimi
- **Standby'da durdur**
- **Video çıkışı (sink)** — bu kutuda `dreamvideosink`. Başka kutularda
  `dvbvideosink` olabilir.
- **Günlüğe ayrıntı yaz** — gstreamer çıktısını enigma2 günlüğüne aktarır

Uzantılar menüsündeki **Radyo videosu aç/kapat** girdisi videoyu kalıcı ayarı
değiştirmeden geçici olarak durdurur.

Pakette varsayılan bir video gelir: `/usr/share/enigma2/RadioVideo/radio.mp4`

## Durum ekranı

Ayar ekranının alt yarısı canlı teşhis gösterir; kutuya telnet'le girmeden
sorunun yerini söyler:

- **Zap olayları: geliyor / GELMİYOR** — `GELMİYOR` ise olay dinleyicisi
  kurulamamış, işi denetim zamanlayıcısı yürütüyor demektir
- **Kanalın video PID'i** — `yok` ise burada devreye gireriz, dolu ise
  kanalın kendi görüntüsü vardır
- **Karar** — `oynat` / `durdur` / `bekle (kararsız an)`
- Bulunan video sayısı, şu an oynayan dosya, son hata

## Sorun giderme

```sh
sh /usr/lib/enigma2/python/Plugins/Extensions/RadioVideo/tools/probe.sh
journalctl -u enigma2 --no-pager | grep RadioVideo | tail -20
```

`probe.sh` decoder sayısını, gstreamer ve sink varlığını, arkada kalmış
oynatıcıyı ve dosyayı kontrol eder, sonra 15 saniyelik bir test oynatması
yapar.

**Video görünmüyor:** başlama gecikmesini artırın; `probe.sh` ile sink'i
doğrulayın.

**Ses kesiliyor:** komutta `audio-sink=fakesink` olmalı. Ayarlarda günlüğü
açıp `[RadioVideo] komut:` satırına bakın.

**Kanal değiştirdikten sonra görüntü gelmiyor:** arkada kalmış bir oynatıcı
decoder'ı tutuyor olabilir:

```sh
pkill -f 'playbin name=radiovideo'
```

Eklenti açılışta ve kaldırılırken bunu kendisi de yapar.

**Belirli bir video oynamıyor:** kodek/çözünürlük decoder'a uymuyor olabilir.
`probe.sh <dosya>` ile tek tek deneyin. (Bu kutuda 2160p webm sorunsuz
oynuyor; 1080p50 h264 bir dosya oynamadı.)

## Dosyalar

```
plugin.py     PluginDescriptor'lar, sessionstart/stop
settings.py   config.plugins.radiovideo
player.py     çekirdek: karar mantığı, süreç yönetimi, döngü
ui.py         ayar + durum ekranı, dosya seçici
tools/probe.sh  kutuda teşhis
```

Geliştirme makinesinde test: `python _tools/test_radiovideo.py`
