#!/bin/sh
#
# RadioVideo tesghis betigi -- kutuda calistirilir:
#
#   sh /usr/lib/enigma2/python/Plugins/Extensions/RadioVideo/tools/probe.sh
#   sh .../probe.sh /media/hdd/film.mp4     # verilen dosyayi 15 s test eder
#
# Eklenti calismiyorsa once bunu calistirin: sorunun hangi katmanda oldugunu
# (decoder, gstreamer, sink, dosya) tek seferde gosterir.
#
VIDEO="${1:-/usr/share/enigma2/RadioVideo/radio.mp4}"
GST="${GST:-/usr/bin/gst-launch-1.0}"
SINK="${SINK:-dreamvideosink}"

echo "== kutu =="
cat /proc/stb/info/model 2>/dev/null || cat /proc/stb/info/boxtype 2>/dev/null || echo "model bilinmiyor"

echo
echo "== video decoder sayisi =="
ls /dev/dvb/adapter0/video* 2>/dev/null || echo "video decoder aygiti yok!"
COUNT=$(ls /dev/dvb/adapter0/video* 2>/dev/null | wc -l)
echo "adet: $COUNT  (1 ise PiP yolu kapali, bu eklenti zaten PiP kullanmaz)"

echo
echo "== gstreamer =="
if [ -x "$GST" ]; then
    echo "$GST var"
    "$GST" --version 2>/dev/null | head -1
else
    echo "YOK: $GST"
fi
if gst-inspect-1.0 "$SINK" >/dev/null 2>&1; then
    echo "$SINK kullanilabilir"
else
    echo "YOK: $SINK -- ayarlardan baska bir sink deneyin (or. dvbvideosink)"
fi

echo
echo "== calan servis =="
if [ -e /tmp/.e2settings.pkl ] || pgrep enigma2 >/dev/null 2>&1; then
    echo "enigma2 calisiyor"
else
    echo "enigma2 CALISMIYOR -- video decoder bos olmayabilir"
fi

echo
echo "== arkada kalan oynatici =="
if pgrep -f 'playbin name=radiovideo' >/dev/null 2>&1; then
    echo "VAR (decoder'i tutuyor olabilir):"
    pgrep -af 'playbin name=radiovideo' 2>/dev/null || pgrep -f 'playbin name=radiovideo'
    echo "temizlemek icin: pkill -f 'playbin name=radiovideo'"
else
    echo "yok"
fi

echo
echo "== video dosyasi =="
if [ -f "$VIDEO" ]; then
    ls -l "$VIDEO"
else
    echo "YOK: $VIDEO"
    exit 1
fi

echo
echo "== 15 saniyelik oynatma testi =="
echo "RADYO KANALI ACIKKEN calistirin: ekranda video gorunmeli, ses kesilmemeli."
echo "komut: $GST playbin name=radiovideo uri=file://... video-sink=$SINK audio-sink=fakesink"
URI=$(python3 -c "import pathlib,sys;print(pathlib.Path(sys.argv[1]).absolute().as_uri())" "$VIDEO" 2>/dev/null \
   || python -c "import pathlib,sys;print(pathlib.Path(sys.argv[1]).absolute().as_uri())" "$VIDEO" 2>/dev/null)
if [ -z "$URI" ]; then
    echo "URI uretilemedi (python yok); dosya yolunda bosluk varsa test atlanir"
    exit 1
fi
"$GST" playbin name=radiovideo uri="$URI" video-sink="$SINK" audio-sink=fakesink &
PID=$!
sleep 15
kill -INT $PID 2>/dev/null
wait $PID 2>/dev/null
echo "test bitti (cikis kodu: $?)"
