# -*- coding: utf-8 -*-
#
# RadioVideo - çekirdek
#
# Radyo kanalı çalarken video decoder boştadır (bu kutuda yalnızca
# /dev/dvb/adapter0/video0 var, yani PiP yolu kapalı). Bu yüzden videoyu
# enigma2'nin servis mekanizmasıyla değil, ayrı bir gstreamer süreciyle
# doğrudan decoder'a basıyoruz:
#
#   gst-launch-1.0 playbin name=radiovideo uri=file://... \
#                  video-sink=dreamvideosink audio-sink=fakesink
#
# audio-sink=fakesink kritik: sesi biz üretmiyoruz, ses ana servisten
# (radyo kanalından) gelmeye devam ediyor.
#
from __future__ import print_function

import os
import random
import time

from enigma import (eConsoleAppContainer, eTimer, iPlayableService,
                    iServiceInformation)

import NavigationInstance

from .settings import cfg

# Radyo servis tipleri: 2 = digital radio sound, 10 = advanced codec radio
# (stok kaynakta da bu ikili kullanılıyor, örn. Components/Converter/ServiceName2.py)
RADIO_SERVICE_TYPES = (2, 10)

VIDEO_EXTENSIONS = (".mkv", ".mp4", ".avi", ".ts", ".m2ts", ".mov", ".m4v",
                    ".mpg", ".mpeg", ".vob", ".wmv", ".flv", ".webm",
                    ".divx", ".mts", ".m2v", ".3gp")

# playbin'e verdiğimiz ad; artık süreçleri bununla ayırt edip temizliyoruz
PIPELINE_NAME = "radiovideo"

MAX_SCAN_DEPTH = 4          # klasör tarama derinliği
MAX_FILES = 2000            # oynatma listesi üst sınırı
MIN_PLAY_SECONDS = 5        # bundan kısa süren oynatma "başarısız" sayılır
MAX_FAILURES = 3            # üst üste bu kadar başarısızlıkta pes et
KILL_GRACE_MS = 1500        # SIGINT sonrası son çare SIGKILL; temiz kapanışa
                            # zaman tanı: SIGKILL decoder'ı kirli bırakabilir
REFRESH_DELAY_MS = 400      # oynatıcı öldükten sonra tazelemeye kadar
REPLAY_DELAY_MS = 300       # stopService ile playService arası
LOOP_RESTART_MS = 50        # dosya bitince başa sarma gecikmesi
WATCHDOG_MS = 5000          # olay yolu sessiz kalırsa devreye giren denetim
ATTACH_RETRY_MS = 3000      # NavigationInstance hazır değilse tekrar deneme
MAX_ATTACH_RETRIES = 10
MAX_ERROR_LINES = 25        # gstreamer ciktisindan tamponlanan satir sayisi
ERROR_LINES_ON_FAIL = 6     # hata durumunda gunluge dokulen son satir sayisi
FILE_MAX_FAILURES = 2       # bir dosya kac denemeden sonra atlanir


def log(msg):
    print("[RadioVideo] %s" % msg)


def debug(msg):
    if cfg.debug.value:
        log(msg)


def shellQuote(text):
    """eConsoleAppContainer.execute(tek_string) komutu /bin/sh -c ile
    çalıştırır; boşluk ve parantez içeren yolları bu yüzden tırnaklıyoruz."""
    return "'" + text.replace("'", "'\\''") + "'"


def fileToUri(path):
    """Yerel yolu file:// URI'sine çevirir (boşluk, parantez, Türkçe harf).

    pathname2url kullanmıyoruz: platforma göre farklı sonuç veriyor
    (Windows'taki geliştirme makinesinde yolun başına fazladan '/' ekliyor).
    quote her yerde aynı çıktıyı verir."""
    try:
        from urllib.parse import quote                   # Python 3
    except ImportError:
        from urllib import quote                         # Python 2
    if str is bytes and not isinstance(path, bytes):     # Python 2 unicode
        path = path.encode("utf-8")
    return "file://" + quote(path)


def isVideoFile(name):
    return name.lower().endswith(VIDEO_EXTENSIONS)


def isRadioReference(ref):
    """Çalan servis bir radyo kanalı mı?"""
    if ref is None or not ref.valid():
        return False
    try:
        # 4097 vb. dosya/stream servisleri radyo sayılmaz
        if ref.getPath():
            return False
        return ref.getData(0) in RADIO_SERVICE_TYPES
    except Exception as e:
        debug("servis tipi okunamadı: %s" % e)
        return False


def currentVideoPid():
    """Çalan servisin video PID'i.

    -1/0 -> görüntü yok (bizim videomuzun yeri).
    None -> henüz bilinmiyor (PMT gelmedi); karar ertelenir.

    Digitürk'ün radyo kanalları gibi kendi görüntüsü olan servislerde bu
    değer dolu gelir ve biz devreye girmeyiz.
    """
    nav = NavigationInstance.instance
    if nav is None:
        return None
    try:
        service = nav.getCurrentService()
        info = service and service.info()
        if info is None:
            return None
        return info.getInfo(iServiceInformation.sVideoPID)
    except Exception as e:
        debug("video PID okunamadı: %s" % e)
        return None


def scanPath(path, recursive, limit=MAX_FILES):
    """Verilen yoldan oynatma listesi üretir. Dosya verildiyse tek elemanlı."""
    if not path:
        return []
    if os.path.isfile(path):
        return [path]
    if not os.path.isdir(path):
        return []

    found = []
    base_depth = path.rstrip("/").count("/")
    for root, dirs, files in os.walk(path):
        dirs.sort()
        if not recursive:
            del dirs[:]
        elif root.rstrip("/").count("/") - base_depth >= MAX_SCAN_DEPTH:
            del dirs[:]
        for name in sorted(files):
            if isVideoFile(name):
                found.append(os.path.join(root, name))
                if len(found) >= limit:
                    return found
    return found


class RadioVideoPlayer(object):
    def __init__(self):
        self.container = None
        self.conns = []                 # sigc++ bağlantıları -- tutulmazsa kopar
        self.cleanup_container = None
        self.playlist = []
        self.index = 0
        self.current_file = None
        self.last_played = None         # rastgele kipte tekrarı önlemek için
        self.started_at = 0
        self.failures = 0
        self.last_error = ""
        self.attached = False
        self.paused_by_user = False     # eklenti menüsünden elle durdurma
        self.attach_retries = 0
        self.last_ref = None            # servis degisimini anlamak icin
        self.refresh_pending = False    # durdurmadan sonra kanal tazelensin mi
        self.replay_ref = None          # tazelemede yeniden açılacak servis
        self.error_lines = []           # son gstreamer çıktısı (teşhis için)
        self.file_failures = {}         # dosya -> üst üste başarısız deneme
        self.broken = set()             # oynatılamadığı anlaşılan dosyalar
        self.saved_radiopic = None      # kullanıcının radyo görseli ayarı

        self.start_timer = eTimer()
        self.start_timer_conn = self.start_timer.timeout.connect(self._startNow)
        self.kill_timer = eTimer()
        self.kill_timer_conn = self.kill_timer.timeout.connect(self._forceKill)
        self.attach_timer = eTimer()
        self.attach_timer_conn = self.attach_timer.timeout.connect(self.attach)
        # Olay yolu herhangi bir sebeple sessiz kalırsa eklenti yine de
        # çalışsın diye düzenli bir kontrol
        self.watchdog = eTimer()
        self.watchdog_conn = self.watchdog.timeout.connect(self._onWatchdog)
        self.refresh_timer = eTimer()
        self.refresh_timer_conn = self.refresh_timer.timeout.connect(
            self._refreshService)
        self.replay_timer = eTimer()
        self.replay_timer_conn = self.replay_timer.timeout.connect(
            self._replayService)

    # -------------------------------------------------------------- bağlanma

    def attach(self):
        if self.attached:
            return
        nav = NavigationInstance.instance
        if nav is None:
            # WHERE_SESSIONSTART anında Navigation hazır olmayabilir
            self.attach_retries += 1
            if self.attach_retries <= MAX_ATTACH_RETRIES:
                log("NavigationInstance henüz yok, %d. deneme %d ms sonra"
                    % (self.attach_retries, ATTACH_RETRY_MS))
                self.attach_timer.start(ATTACH_RETRY_MS, True)
            else:
                log("NavigationInstance hiç gelmedi, izleme kurulamadı")
            return
        if self._onServiceEvent not in nav.event:
            nav.event.append(self._onServiceEvent)
        try:
            from Components.config import config
            config.misc.standbyCounter.addNotifier(self._onStandby,
                                                   initial_call=False)
        except Exception as e:
            log("standby bildirimi kurulamadı: %s" % e)
        self.attached = True
        if cfg.cleanup_on_start.value:
            self.cleanupStaleProcesses()
        self.watchdog.start(WATCHDOG_MS, False)
        self.applyRadioPic()
        log("izleme başladı (olay dinleyici: %d)" % len(nav.event))
        self.evaluate(reset_failures=True)

    def detach(self):
        """enigma2 kapanırken çağrılır. Süreç geride kalırsa decoder'ı tutar
        ve yeniden başlayan enigma2'de görüntü gelmez."""
        self.stop(immediate=True)
        self.restoreRadioPic()
        self.watchdog.stop()
        self.attach_timer.stop()
        self.refresh_timer.stop()
        self.replay_timer.stop()
        nav = NavigationInstance.instance
        if nav is not None:
            try:
                nav.event.remove(self._onServiceEvent)
            except ValueError:
                pass
        self.attached = False

    def applyRadioPic(self):
        """"Video yokken ekran" ayarını enigma2'ye uygular.

        enigma2 radyo kanalına geçerken config.misc.radiopic'teki görseli
        (radio.mvi) decoder'a basar. "Siyah ekran" seçildiğinde bu değeri
        geçici olarak boşaltıyoruz; kullanıcının değeri saklanır ve eklenti
        kapanırken geri konur. Ayar dosyasına yazmıyoruz.

        Etkisi bir sonraki zap'te görünür -- enigma2 görseli zap anında basar.
        """
        try:
            from Components.config import config
            pic = config.misc.radiopic
        except Exception as e:
            debug("radyo görseli ayarına erişilemedi: %s" % e)
            return
        if cfg.fallback.value == "black":
            if self.saved_radiopic is None:
                self.saved_radiopic = pic.value
            if pic.value:
                pic.value = ""
                log("radyo görseli kapatıldı (siyah ekran)")
        elif self.saved_radiopic is not None:
            pic.value = self.saved_radiopic
            self.saved_radiopic = None
            log("radyo görseli geri açıldı")

    def restoreRadioPic(self):
        """Kullanıcının radyo görseli ayarını koşulsuz geri koyar."""
        if self.saved_radiopic is None:
            return
        try:
            from Components.config import config
            config.misc.radiopic.value = self.saved_radiopic
            log("radyo görseli geri açıldı")
        except Exception as e:
            debug("radyo görseli geri konamadı: %s" % e)
        self.saved_radiopic = None

    def cleanupStaleProcesses(self):
        """Önceki oturumdan kalmış kendi oynatıcımızı öldürür. Yalnızca
        playbin name=radiovideo kalıbını hedefler, başka gstreamer işlerine
        dokunmaz."""
        try:
            container = eConsoleAppContainer()
            self.cleanup_container = container       # süreç bitene kadar tut
            container.execute("pkill -f 'playbin name=%s' >/dev/null 2>&1"
                              % PIPELINE_NAME)
        except Exception as e:
            debug("artık süreç temizliği başarısız: %s" % e)

    # --------------------------------------------------------------- olaylar

    def _onServiceEvent(self, what):
        if what not in (iPlayableService.evStart, iPlayableService.evEnd,
                        iPlayableService.evUpdatedInfo):
            return
        changed = self._serviceChanged()
        if changed:
            debug("servis değişti: %s" % self.last_ref)
        self.evaluate(reset_failures=changed)

    def _serviceChanged(self):
        """Son bakıştan bu yana başka bir servise mi geçildi?"""
        nav = NavigationInstance.instance
        ref = nav.getCurrentlyPlayingServiceReference() if nav else None
        try:
            current = ref.toString() if ref is not None and ref.valid() else None
        except Exception:
            current = None
        changed = current != self.last_ref
        self.last_ref = current
        return changed

    def _onWatchdog(self):
        """Olay yolu herhangi bir sebeple sessiz kalsa bile radyodayken video
        çalışsın; radyodan çıkıldıysa kalan oynatıcıyı kapat."""
        if self.shouldPlay():
            if (not self.isRunning() and not self.start_timer.isActive()
                    and self.failures < MAX_FAILURES):
                log("olay gelmedi, oynatıcı denetimden başlatılıyor")
                self._scheduleStart()
        elif self.decide() == "stop" and self.isRunning():
            debug("denetim: oynatma koşulu yok, durduruluyor")
            self.stop(refresh=True)

    def _onStandby(self, configElement):
        if not cfg.stop_in_standby.value:
            return
        debug("standby'a girildi")
        self.stop()
        try:
            from Screens.Standby import inStandby
            if inStandby is not None:
                inStandby.onClose.append(self._onLeaveStandby)
        except Exception as e:
            debug("standby çıkışı dinlenemedi: %s" % e)

    def _onLeaveStandby(self):
        debug("standby'dan çıkıldı")
        self.evaluate()

    # ----------------------------------------------------------------- karar

    def decide(self):
        """Ne yapılmalı: "play", "stop" ya da "wait".

        "wait" kararsız anı temsil eder: zap'in ortası (servis referansı henüz
        geçersiz) ya da PMT gelmediği için video PID'inin bilinmediği an. Bu
        durumda oynatıcıya DOKUNULMAZ -- radyo kanalları arasında gezerken
        videonun baştan başlamamasının sebebi budur.
        """
        if not cfg.enabled.value or self.paused_by_user:
            return "stop"
        if cfg.stop_in_standby.value:
            try:
                from Screens.Standby import inStandby
                if inStandby is not None:
                    return "stop"
            except Exception:
                pass

        nav = NavigationInstance.instance
        if nav is None:
            return "wait"
        ref = nav.getCurrentlyPlayingServiceReference()
        if ref is None or not ref.valid():
            return "wait"                    # zap arası
        try:
            if ref.getPath():                # dosya/stream oynatılıyor
                return "stop"
        except Exception:
            pass

        is_radio = isRadioReference(ref)
        mode = cfg.trigger.value
        if mode != "novideo" and not is_radio:
            return "stop"                    # TV kanalı: hemen bırak
        if mode == "radio":
            return "play"                    # video PID'ine bakma (eski davranış)

        pid = currentVideoPid()
        if pid is None:
            # Bilgi henüz yok: radyodaysak bekle, değilsek karışma
            return "wait" if is_radio else "stop"
        if pid > 0:
            return "stop"                    # kanalın kendi görüntüsü var
        return "play"

    def shouldPlay(self):
        return self.decide() == "play"

    def evaluate(self, reset_failures=False):
        if reset_failures:
            self.failures = 0
        decision = self.decide()
        if decision == "play":
            if not self.isRunning() and not self.start_timer.isActive():
                self._scheduleStart()
        elif decision == "stop":
            # Görüntülü bir kanala geçiliyorsa decoder'ı hızla bırak ve
            # gerekirse kanalı tazele (bkz. _refreshService)
            self.stop(refresh=True)
        # "wait": çalan varsa çalmaya devam etsin, yoksa beklesin

    def _scheduleStart(self):
        try:
            delay = int(cfg.start_delay.value)
        except ValueError:
            delay = 1500
        debug("video %d ms sonra başlayacak" % delay)
        self.start_timer.start(delay, True)

    # --------------------------------------------------------------- oynatma

    def isRunning(self):
        return self.container is not None and self.container.running()

    def _nextFile(self):
        if not self.playlist:
            found = scanPath(cfg.path.value, cfg.recursive.value)
            # Oynatılamadığı anlaşılan dosyalar listeye geri alınmaz
            self.playlist = [p for p in found if p not in self.broken]
            self.index = 0
            if not self.playlist:
                return None
            if cfg.order.value == "random":
                self._shuffle()
        order = cfg.order.value
        if order == "first":
            return self.playlist[0]
        if self.index >= len(self.playlist):
            # Tur bitti: rastgele kipte yeni bir sıra çek
            self.index = 0
            if order == "random":
                self._shuffle()
        path = self.playlist[self.index]
        self.index += 1
        return path

    def _shuffle(self):
        """Listeyi karıştırır.

        Rastgele kip 'her seferinde bağımsız seçim' değildir: her video turda
        bir kez oynar, tur bitince sıra yeniden çekilir. Aksi halde aynı video
        üst üste gelebiliyor. Yeni turun ilki, biten turun sonuncusu olmasın
        diye ek bir kontrol var.
        """
        random.shuffle(self.playlist)
        if len(self.playlist) > 1 and self.playlist[0] == self.last_played:
            self.playlist[0], self.playlist[-1] = \
                self.playlist[-1], self.playlist[0]

    def _buildCommand(self, path):
        """Oynatıcıyı enigma2'den olabildiğince arındırılmış halde başlatır.

        Aynı komut kabuktan sorunsuz çalışırken eklentiden çalıştırıldığında
        HDR/10-bit dosyalarda "write on file descriptor: Invalid argument"
        veriyordu. Ortam değişkenleri, cgroup ve LD_PRELOAD elendi; geriye
        enigma2'nin açık tuttuğu ve exec ile çocuğa geçen fd'ler kaldı
        (/dev/ion, /dev/ge2d, /dev/mali0, /dev/fb0-3 -- Amlogic'in bellek ve
        grafik aygıtları). Bunları kapatarak başlıyoruz.

        exec kullanmak ayrıca sh'i gst-launch ile değiştirir: eConsoleAppContainer
        böylece doğrudan oynatıcının PID'ini tutar, sendCtrlC/kill araya bir
        kabuk girmeden hedefine ulaşır.
        """
        parts = []
        if cfg.clear_preload.value:
            parts.append("unset LD_PRELOAD;")
        if cfg.close_fds.value:
            parts.append('for f in /proc/self/fd/[0-9]*; do n=${f##*/}; '
                         '[ "$n" -gt 2 ] 2>/dev/null && '
                         'eval "exec $n>&-" 2>/dev/null; done;')
        parts.append(
            "exec %s playbin name=%s uri=%s video-sink=%s audio-sink=fakesink"
            % (shellQuote(cfg.gst_binary.value),
               PIPELINE_NAME,
               shellQuote(fileToUri(path)),
               shellQuote(cfg.video_sink.value)))
        return " ".join(parts)

    def _startNow(self):
        if not self.shouldPlay():
            return
        if self.isRunning():
            return
        if self.failures >= MAX_FAILURES:
            log("üst üste %d başarısız deneme, duruyorum" % self.failures)
            return

        path = self._nextFile()
        if path is None:
            message = "oynatılacak video bulunamadı: %s" % cfg.path.value
            if message != self.last_error:          # her denemede tekrarlama
                log(message)
            self.last_error = message
            # Hepsi kırıksa ya da klasör boşsa denetim zamanlayıcısı her 5
            # saniyede bir buraya düşer; sayacı artırıp pes ediyoruz
            self.failures += 1
            return
        if not os.path.exists(path):
            self.last_error = "dosya kayıp: %s" % path
            log(self.last_error)
            self.playlist = []
            self.failures += 1
            return

        cmd = self._buildCommand(path)
        debug("komut: %s" % cmd)

        container = eConsoleAppContainer()
        self.conns = [
            container.appClosed.connect(self._onAppClosed),
            container.dataAvail.connect(self._onData),
        ]
        retval = container.execute(cmd)
        if retval:
            self.last_error = "gstreamer başlatılamadı (retval=%s)" % retval
            log(self.last_error)
            self.conns = []
            self.failures += 1
            return

        self.container = container
        self.current_file = path
        self.last_played = path
        self.started_at = time.time()
        self.error_lines = []
        self.last_error = ""
        log("oynatılıyor: %s" % path)

    def _onData(self, data):
        """gstreamer çıktısı. Son satırlar her zaman tamponlanır: bir dosya
        oynamadığında sebebi günlükte görebilmek için debug'ın açık olmasını
        beklemek teşhisi bir tur geciktiriyor."""
        try:
            if not isinstance(data, str):
                data = data.decode("utf-8", "replace")
        except Exception:
            return
        for line in data.splitlines():
            line = line.strip()
            if not line:
                continue
            self.error_lines.append(line)
            if len(self.error_lines) > MAX_ERROR_LINES:
                del self.error_lines[0]
            if cfg.debug.value:
                log("gst: %s" % line)

    def _onAppClosed(self, retval):
        played = time.time() - self.started_at
        failed_file = self.last_played
        debug("oynatıcı kapandı (retval=%s, %.1f s)" % (retval, played))
        self.container = None
        self.conns = []
        self.current_file = None
        self.kill_timer.stop()
        # SIGINT'e yanıt veren süreç burada ölür; SIGKILL zamanlayıcısı hiç
        # çalışmaz. Tazeleme planı bu yüzden İKİ yolda da yapılmalı --
        # yalnızca _forceKill içinde olsaydı hiç tetiklenmezdi.
        self._scheduleRefresh()

        if played < MIN_PLAY_SECONDS and retval != 0:
            self.failures += 1
            self.last_error = ("oynatma %.1f s sonra hata ile bitti "
                               "(retval=%s)" % (played, retval))
            log(self.last_error)
            if not cfg.debug.value:
                for line in self.error_lines[-ERROR_LINES_ON_FAIL:]:
                    log("gst: %s" % line)
            self._noteFileFailure(failed_file)
        else:
            self.failures = 0
            self.file_failures.pop(failed_file, None)

        # Video bitti; hâlâ radyodaysak sıradakine geç
        if self.shouldPlay() and self.failures < MAX_FAILURES:
            self.start_timer.start(LOOP_RESTART_MS, True)

    def _noteFileFailure(self, path):
        """Belirli bir dosya oynatılamıyorsa onu atla, tüm eklentiyi durdurma.

        Klasörde tek bir bozuk/desteklenmeyen video varsa eskiden üç denemeden
        sonra her şey duruyordu; artık yalnızca o dosya listeden düşer.
        """
        if not path:
            return
        count = self.file_failures.get(path, 0) + 1
        self.file_failures[path] = count
        if count < FILE_MAX_FAILURES:
            return
        self.broken.add(path)
        log("bu dosya oynatılamıyor, atlanıyor: %s" % path)
        # Liste yeniden kurulsun ki kırık dosyalar elensin
        self.playlist = []
        self.index = 0
        self.failures = 0            # sıradaki dosyaya şans ver

    # -------------------------------------------------------------- durdurma

    def stop(self, immediate=False, refresh=False):
        self.start_timer.stop()
        if self.container is None:
            return
        # Kanalı tazeleme yalnızca gerçekten bir oynatıcı kapattığımızda
        # anlamlı; aşağıdaki erken dönüşlerden sonra planlanmaz.
        self.refresh_pending = refresh
        if immediate:
            self._forceKill()
            return
        try:
            # SIGINT ile gst-launch decoder'ı DÜZGÜN bırakır; SIGKILL'de
            # dreamvideosink temizlik yapamaz ve decoder kirli kalabilir.
            # Bu yüzden temiz kapanışa bolca zaman tanıyoruz; SIGKILL yalnızca
            # süreç takıldığında, son çare olarak.
            self.container.sendCtrlC()
            self.kill_timer.start(KILL_GRACE_MS, True)
            debug("oynatıcıya durma sinyali gönderildi")
        except Exception as e:
            debug("sendCtrlC başarısız: %s" % e)
            self._forceKill()

    def _forceKill(self):
        self.kill_timer.stop()
        if self.container is None:
            self._scheduleRefresh()
            return
        try:
            if self.container.running():
                self.container.kill()
                log("oynatıcı temiz kapanmadı, zorla kapatıldı")
        except Exception as e:
            debug("kill başarısız: %s" % e)
        self.container = None
        self.conns = []
        self.current_file = None
        self._scheduleRefresh()

    def _scheduleRefresh(self):
        if not self.refresh_pending:
            return
        self.refresh_pending = False
        if cfg.refresh_on_stop.value:
            debug("kanal tazeleme %d ms sonra" % REFRESH_DELAY_MS)
            self.refresh_timer.start(REFRESH_DELAY_MS, True)

    def _refreshService(self):
        """Oynatıcı kapandıktan sonra kanalı bir kez tazeler.

        Radyodan TV'ye zap ederken decoder'ı biz tutuyor olabiliyoruz; enigma2
        o anda görüntüyü açamıyor ve ekran siyah kalıyor (ses ayrı yoldan
        geldiği için duyuluyor). Elle kanal değiştirip geri dönmek düzeltiyordu;
        burada aynı şey bir kez otomatik yapılıyor.
        """
        if self.isRunning():
            return                       # bu arada yeniden başlamışız
        nav = NavigationInstance.instance
        if nav is None:
            return
        try:
            from Screens.Standby import inStandby
            if inStandby is not None:
                return
        except Exception:
            pass
        if self.decide() == "play":
            return                       # radyoya geri dönülmüş
        ref = nav.getCurrentlyPlayingServiceReference()
        if ref is None or not ref.valid():
            return
        pid = currentVideoPid()
        if pid is None or pid <= 0:
            return                       # görüntüsüz servis: tazelemek anlamsız

        # forceRestart tek başına yetmiyor: Navigation.playService yalnızca
        # pnav.playService çağırıyor, decoder'ı kapatıp açmıyor. Önce servisi
        # gerçekten durduruyoruz, sonra yeniden başlatıyoruz -- elle kanal
        # değiştirip geri dönmenin yaptığı da bu.
        self.replay_ref = ref
        log("görüntü gelsin diye kanal tazeleniyor")
        try:
            nav.stopService()
        except Exception as e:
            log("servis durdurulamadı: %s" % e)
            self.replay_ref = None
            return
        self.replay_timer.start(REPLAY_DELAY_MS, True)

    def _replayService(self):
        nav = NavigationInstance.instance
        ref, self.replay_ref = self.replay_ref, None
        if nav is None or ref is None:
            return
        try:
            nav.playService(ref, forceRestart=True)
        except TypeError:                # imza farklıysa
            try:
                nav.playService(ref)
            except Exception as e:
                log("kanal tazelenemedi: %s" % e)
        except Exception as e:
            log("kanal tazelenemedi: %s" % e)

    # ------------------------------------------------------------------ durum

    def status(self):
        radio = False
        listening = False
        nav = NavigationInstance.instance
        if nav is not None:
            radio = isRadioReference(nav.getCurrentlyPlayingServiceReference())
            # Gerçekten zap olaylarını alıyor muyuz? "otomatik başlamıyor"
            # şikayetinde ilk bakılacak yer burasıdır.
            listening = self._onServiceEvent in nav.event
        return {
            "attached": self.attached,
            "listening": listening,
            "watchdog": self.watchdog.isActive(),
            "service": self.last_ref,
            "decision": self.decide(),
            "vpid": currentVideoPid(),
            "running": self.isRunning(),
            "file": self.current_file,
            "playlist": len(self.playlist),
            "failures": self.failures,
            "error": self.last_error,
            "broken": len(self.broken),
            "paused": self.paused_by_user,
            "radio": radio,
        }

    def toggle(self):
        """Eklenti menüsünden elle aç/kapat. Dönen değer: artık etkin mi."""
        self.paused_by_user = not self.paused_by_user
        self.playlist = []
        # Elle açıldığında önceki hatalar yüzünden pes edilmiş olmasın
        self.attach()                       # olay yolu kurulmadıysa şimdi kur
        self.evaluate(reset_failures=True)
        return not self.paused_by_user


player = RadioVideoPlayer()
