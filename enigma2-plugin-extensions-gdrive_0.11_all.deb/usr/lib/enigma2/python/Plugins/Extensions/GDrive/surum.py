# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_gdrive.py); depoda yok.
SURUM = "0.11"
COMMIT = "463f6df"
