# -*- coding: utf-8 -*-
# Derleme aninda uretilir (build_deb_subtitlestyle.py); depoda yok.
SURUM = "1.8"
COMMIT = "1148782"
