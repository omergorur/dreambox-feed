# -*- coding: utf-8 -*-
"""
SubtitleStyle -- altyazi gorunumu (DreamOS).

  * Harici .srt: cizici.SrtCizici (GDrive kullanir; StalkerTV de kullanabilir) -- font, boyut, stil, renk,
    konum, zamanlama.
  * Dosya icindeki (MKV) metin altyazilari: fontconfig ile font ve boyut -- kutudaki TUM oynaticilar
    (GDrive, StalkerTV, MoviePlayer) icin; enigma2 yeniden baslayinca gecerli.

Paket ayrica /etc/fonts/conf.d/60-subtitlestyle.conf kurar (font dizini + /etc/enigma2/subtitlestyle-fontconfig.conf).
"""
from __future__ import print_function

from Plugins.Plugin import PluginDescriptor

try:
    _
except NameError:
    def _(txt):
        return txt


def ac(session, **kwargs):
    from .ekran import AltyaziStiliAyarlari
    session.open(AltyaziStiliAyarlari)


def sistem_menusu(menuid, **kwargs):
    if menuid == "system":
        return [(_("Altyazı stili"), ac, "subtitlestyle", 50)]
    return []


def oturum_basi(reason, **kwargs):
    """Canli altyazi kancasi: GStreamer servislerinde dosya ici metin altyazilari OSD'de cizilir (canli.py)."""
    if reason == 0:
        try:
            from .canli import kur
            kur()
        except Exception as e:  # noqa: BLE001
            print("[SubtitleStyle] canli altyazi kancasi: %s" % e)


def Plugins(**kwargs):
    try:        # secim dosyasi yoksa (ilk kurulum) yaz; fontconfig ilk kullanimda okur
        from .ayarlar import fontconfig_yaz
        fontconfig_yaz()
    except Exception as e:  # noqa: BLE001
        print("[SubtitleStyle] fontconfig: %s" % e)
    return [
        PluginDescriptor(name="SubtitleStyle", where=PluginDescriptor.WHERE_SESSIONSTART, needsRestart=False, fnc=oturum_basi),
        PluginDescriptor(name=_("Altyazı stili"), description=_("Altyazı fontu, boyutu ve görünümü"),
                         where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", needsRestart=False, fnc=ac),
        PluginDescriptor(name=_("Altyazı stili"), where=PluginDescriptor.WHERE_MENU, needsRestart=False, fnc=sistem_menusu),
    ]
