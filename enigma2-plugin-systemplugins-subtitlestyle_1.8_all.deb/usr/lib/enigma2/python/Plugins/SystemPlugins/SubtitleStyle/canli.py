# -*- coding: utf-8 -*-
"""
SubtitleStyle -- canli altyazi: dosya icindeki (MKV/MP4) metin altyazilarini enigma2 OSD'sinde cizer.

GStreamer (gst124) tarafinda 'dreamcues' ogesi playsink'in subtitleoverlay zincirinde textoverlay'in yerini alir:
videoya dokunmaz, her altyazi satirini akis zamaniyla /tmp/dreamcues.txt dosyasina yazar. Burasi dosyayi 200 ms'de
bir okuyup oynatma konumuna gore SrtCizici kutusuyla gosterir. Boylece dreamvideosink'in overlay yolu (duraklatmada
kuyruk silme, sarma sonrasi zehirlenme, decoder_time) hic kullanilmaz; duraklatinca yazi kalir, sarinca aninda
eslesir, font/renk/kontur/konum SubtitleStyle ayarlarindan gelir, {\\an8} ustte gosterilir.

Kanca (kur): InfoBarSubtitleSupport.setSubtitlesEnable sarilir (ve 'subtitles_enabled' ozelligi yeniden kurulur;
ozellik sinif tanimindaki islevi tuttugu icin yalniz nitelik degistirmek yetmez). GStreamer (4097) servisinde
altyazi acilinca CanliCizici baslar; kapaninca, servis degisince ya da enigma2 izi kendisi sifirlayinca durur.

Dosya bicimi (dreamcues): 'S' yeni akis, 'F<TAB>segment_ms' yeni segment (ikisi de listeyi sifirlar),
'C<TAB>bas_ms<TAB>bit_ms<TAB>metin' (metinde \\n = satir sonu, \\\\ = ters bolu; bit_ms -1 = suresiz).
"""
from __future__ import print_function

import bisect
import io
import os
import re
import time

from .ayarlar import cfg, gunluk
from .cizici import SrtCizici, AltyaziKutusu, srt_bul, _SRT_ETIKET, KESTIRIM_SINIRI_MS

DOSYA = os.environ.get("DREAMCUES_DOSYA", "/tmp/dreamcues.txt")
GST_TIPLERI = (4097, 5001, 5002)
ESKI_DOSYA_SN = 5           # baslarken dosya bundan eskiyse icerigi gecmis oturumdan sayilir
SURESIZ_MS = 10000
_BLOK = re.compile(u"\\{\\\\[^}]*\\}")
_UST = re.compile(u"\\{\\\\an[789]\\}")
_VARLIK = {u"&amp;": u"&", u"&lt;": u"<", u"&gt;": u">", u"&apos;": u"'", u"&quot;": u'"', u"&#39;": u"'"}
USTTE = u"\x01"             # metnin basinda: ekranin ustunde goster


def _metin_temizle(ham):
    """pango-markup/ASS kalintilarini temizler; (metin, ustte)."""
    ustte = bool(_UST.search(ham))
    m = _BLOK.sub(u"", ham)
    m = _SRT_ETIKET.sub(u"", m)
    for k, v in _VARLIK.items():
        m = m.replace(k, v)
    m = m.replace(u"♪", u"~").replace(u"♫", u"~")
    return u"\n".join(s.strip() for s in m.split(u"\n") if s.strip()), ustte


def _kacis_coz(m):
    return m.replace(u"\\\\", u"\x00").replace(u"\\n", u"\n").replace(u"\x00", u"\\")


def _gst_servisi(session):
    try:
        ref = session.nav.getCurrentlyPlayingServiceReference()
        return ref is not None and ref.type in GST_TIPLERI
    except Exception:  # noqa: BLE001
        return False


class CanliCizici(SrtCizici):
    """dreamcues dosyasini canli okuyan SrtCizici; konumu servisten kendisi alir, kendini kapatir."""

    def __init__(self, session, infobar):
        SrtCizici.__init__(self, session, None, self._durum)
        self.infobar = infobar
        self.acik = True
        self.ofset = 0
        try:
            self.servis_ref = session.nav.getCurrentlyPlayingServiceReference().toString()
        except Exception:  # noqa: BLE001
            self.servis_ref = None
        try:        # eski oturumdan kalan dosya: icerigini atla (dreamcues yeni akista 'S' yazar)
            if time.time() - os.path.getmtime(DOSYA) > ESKI_DOSYA_SN:
                self.ofset = os.path.getsize(DOSYA)
        except OSError:
            pass
        self.kutu = session.instantiateDialog(AltyaziKutusu)
        self.kutu.neverAnimate()
        gunluk("canli altyazi basladi (%s)" % DOSYA)

    # --- durum ---
    def _durum(self):
        ib = self.infobar
        duraklatildi = getattr(ib, "seekstate", None) == getattr(ib, "SEEK_STATE_PAUSE", object())
        cubuk = getattr(ib, "_InfoBarShowHide__state", None) == getattr(ib, "STATE_SHOWN", object())
        return duraklatildi, cubuk

    def _konum_ms(self):
        try:
            s = self.session.nav.getCurrentService()
            seek = s and s.seek()
            if not seek:
                return None
            k = seek.getPlayPosition()
            if k and not k[0]:
                return k[1] // 90
        except Exception:  # noqa: BLE001
            pass
        return None

    def _bitmeli(self):
        try:
            if not self.infobar.subtitles_enabled:
                return True
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            return ref is None or ref.toString() != self.servis_ref
        except Exception:  # noqa: BLE001
            return True

    # --- dosya ---
    def _temizle(self):
        self.srt = []
        self.baslar = []

    def _oku(self):
        try:
            boyut = os.path.getsize(DOSYA)
        except OSError:
            return
        if boyut < self.ofset:
            self.ofset = 0
            self._temizle()
        if boyut == self.ofset:
            return
        try:
            with io.open(DOSYA, "rb") as f:
                f.seek(self.ofset)
                veri = f.read()
        except (IOError, OSError) as e:
            gunluk("canli altyazi okunamadi: %s" % e)
            return
        son = veri.rfind(b"\n")
        if son < 0:
            return
        self.ofset += son + 1
        for satir in veri[:son].decode("utf-8", "replace").split(u"\n"):
            if not satir:
                continue
            k = satir[0]
            if k in (u"S", u"F"):
                self._temizle()
                continue
            if k != u"C":
                continue
            parca = satir.split(u"\t", 3)
            if len(parca) < 4:
                continue
            try:
                bas, bit = int(parca[1]), int(parca[2])
            except ValueError:
                continue
            if bas < 0:
                continue
            if bit <= bas:
                bit = bas + SURESIZ_MS
            metin, ustte = _metin_temizle(_kacis_coz(parca[3]))
            if not metin:
                continue
            if ustte:
                metin = USTTE + metin
            i = bisect.bisect_right(self.baslar, bas)
            self.srt.insert(i, (bas, bit, metin))
            self.baslar.insert(i, bas)

    # --- cizim (200 ms) ---
    def _ciz(self):
        if not self.kutu:
            return
        if self._bitmeli():
            gunluk("canli altyazi bitti (iz kapandi / servis degisti)")
            self.kapat()
            return
        self._oku()
        konum = self._konum_ms()
        if konum is not None:
            self.ornek(konum)
        duraklatildi, cubuk_acik = self._durum()
        metin = u""
        ornek = self._ornek
        if ornek is not None and self.srt:
            gecen = 0 if duraklatildi else int((time.time() - ornek[1]) * 1000)
            t = ornek[0] + max(0, min(gecen, KESTIRIM_SINIRI_MS)) - int(cfg.gecikme.value)
            metin = srt_bul(self.srt, self.baslar, t)
        ustte = USTTE in metin
        self.kutu.goster(metin.replace(USTTE, u""), cubuk_acik, ustte)


# --- kanca ---
def _guncelle(infobar, enable):
    c = getattr(infobar, "_substyle_canli", None)
    if enable and getattr(infobar, "subtitles_enabled", False) and _gst_servisi(infobar.session):
        if c is None or not c.kutu:
            c = CanliCizici(infobar.session, infobar)
            infobar._substyle_canli = c
            c.baslat()
    elif c is not None:
        c.kapat()
        infobar._substyle_canli = None


def kur():
    """InfoBarSubtitleSupport.setSubtitlesEnable sarmalayicisi; bir kez."""
    from Screens.InfoBarGenerics import InfoBarSubtitleSupport as S
    if getattr(S, "_substyle_canli_kuruldu", False):
        return
    asil = S.setSubtitlesEnable

    def setSubtitlesEnable(self, enable=True):
        asil(self, enable)
        try:
            _guncelle(self, enable)
        except Exception as e:  # noqa: BLE001
            gunluk("canli altyazi kancasi: %s" % e)

    S.setSubtitlesEnable = setSubtitlesEnable
    S.subtitles_enabled = property(lambda self: self._InfoBarSubtitleSupport__subtitles_enabled, setSubtitlesEnable)
    S._substyle_canli_kuruldu = True
    gunluk("canli altyazi kancasi kuruldu")
