# -*- coding: utf-8 -*-
#
# RadioVideo
#
# Radyo kanallarında ekranda yalnızca sabit bir resim (skin'in radio.mvi
# dosyası, bkz. mytest.py: config.misc.radiopic) görünür. Bu eklenti o resmin
# yerine sabit diskteki bir videoyu oynatır; ses radyo kanalından gelmeye
# devam eder.
#
# Nasıl çalışır
# -------------
# Bu kutuda (Dreambox Two) tek video decoder var -- /dev/dvb/adapter0/video0 --
# yani enigma2'nin PiP yolu (Screens/PictureInPicture.py, setTarget(1)) kapalı.
# Ancak radyo çalarken video decoder boştadır. Eklenti bu boşluğu kullanır ve
# videoyu ayrı bir gstreamer süreciyle doğrudan decoder'a bastırır:
#
#     gst-launch-1.0 playbin name=radiovideo uri=file://... \
#                    video-sink=dreamvideosink audio-sink=fakesink
#
# Ses tarafına hiç dokunulmadığı için radyo sesi kesilmez.
#
# Kurulum:
#   /usr/lib/enigma2/python/Plugins/Extensions/RadioVideo/
#   ardından enigma2 yeniden başlatılır.
#
# Ayarlar: Menü > Eklentiler > Radyo Kanalında Video
#
VERSION = "1.5"

from Plugins.Plugin import PluginDescriptor

from .settings import cfg
from .player import player
from .ui import openSetup


def _log(msg):
    print("[RadioVideo] %s" % msg)


def sessionstart(reason, session=None, **kwargs):
    if reason == 0:
        if not cfg.enabled.value:
            _log("eklenti kapalı")
            return
        player.attach()
        _log("v%s başlatıldı" % VERSION)
    elif reason == 1:
        # enigma2 kapanıyor: oynatıcı geride kalırsa decoder'ı tutar ve
        # yeniden başlayan enigma2'de görüntü gelmez
        player.detach()


def toggleFromExtensions(session, **kwargs):
    enabled = player.toggle()
    text = (_("Radyo videosu açıldı") if enabled
            else _("Radyo videosu durduruldu"))
    try:
        session.toastManager.showToast(text)
    except Exception:
        _log(text)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="RadioVideo",
            description="Radyo kanallarında sabit resim yerine video oynat",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            needsRestart=False,
            fnc=sessionstart),
        PluginDescriptor(
            name=_("Radyo Kanalında Video"),
            description=_("Radyo dinlerken sabit resim yerine video oynat"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            needsRestart=False,
            fnc=openSetup),
        PluginDescriptor(
            name=_("Radyo videosu aç/kapat"),
            description=_("Radyo videosunu geçici olarak durdur veya başlat"),
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            needsRestart=False,
            fnc=toggleFromExtensions),
    ]
